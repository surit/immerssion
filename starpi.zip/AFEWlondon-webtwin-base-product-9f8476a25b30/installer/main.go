package main

import (
	"encoding/gob"
	"fmt"
	"net/http"

	"github.com/gorilla/sessions"
	"github.com/spf13/viper"

	_ "github.com/go-sql-driver/mysql"
)

type Credentials struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	Mode     string `json:"mode"`
}

var (
	// key must be 16, 24 or 32 bytes long (AES-128, AES-192 or AES-256)
	sessionKey          = []byte(viper.GetString("App.SessionKey"))
	sessionStore        = sessions.NewCookieStore(sessionKey)
	directusSessionName = "webtwin-installer-session"
	directusCookieKey   = "rawCookie"
)

func main() {
	// Load in environment variables
	viper.AddConfigPath(".")
	err := viper.ReadInConfig()
	if err != nil {
		panic(fmt.Errorf("Fatal error loading config file: %s", err))
	}

	// Register the auth user response struct so a decoded user response can be
	// retrieved/saved as a session value
	gob.Register(&AuthUserResponse{})

	// Serve assets
	http.HandleFunc("/favicon.ico", func(w http.ResponseWriter, r *http.Request) {})
	http.HandleFunc("/robots.txt", func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, "robots.txt")
	})
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("assets"))))

	// Handle routes
	http.Handle("/", authorize(indexHandler))
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/logout", logoutHandler)

	// Start server
	fmt.Printf("Listening on http://localhost:%v", viper.GetString("App.Port"))
	if err := http.ListenAndServe(fmt.Sprintf(":%v", viper.GetString("App.Port")), nil); err != nil {
		panic(fmt.Errorf("Fatal error starting server: %s", err))
	}
}
