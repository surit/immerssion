package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"
)

type ErrorResponse struct {
	Error ErrorData `json:"error"`
}

type ErrorData struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

type Header struct {
	Key   string
	Value string
}

func Get(w http.ResponseWriter, r *http.Request, url string) ([]byte, error) {
	// Set headers
	session, _ := sessionStore.Get(r, directusSessionName)
	rawCookie, ok := session.Values[directusCookieKey].(string)
	if !ok {

		return nil, errors.New("Couldn't get session cookie")
	}

	headers := []*Header{}
	headers = append(headers, &Header{
		Key:   "Cookie",
		Value: rawCookie,
	})

	// Make the user request
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}

	// Add headers to request
	for _, header := range headers {
		req.Header.Add(header.Key, header.Value)
	}

	// Create an HTTP client
	client := &http.Client{
		Timeout: time.Duration(5 * time.Second),
	}

	// Perform the request
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// If there are any errors, generate a response
	errorResponse := ErrorResponse{}
	if resp.StatusCode >= 400 && resp.StatusCode < 500 {
		json.NewDecoder(resp.Body).Decode(&errorResponse)
		if errorResponse.Error.Code == "" {
			errorResponse.Error.Code = "0000"
		}

		return nil, fmt.Errorf("%s: %s", errorResponse.Error.Code, errorResponse.Error.Message)
	}
	if resp.StatusCode >= 500 {
		errorResponse.Error = ErrorData{
			Code:    "0000",
			Message: "Server error",
		}

		json.NewDecoder(resp.Body).Decode(&errorResponse)
		return nil, fmt.Errorf("%s: %s", errorResponse.Error.Code, errorResponse.Error.Message)
	}

	return ioutil.ReadAll(resp.Body)
}

func Post(w http.ResponseWriter, r *http.Request, url string, body []byte) ([]byte, error) {
	// Set headers
	session, _ := sessionStore.Get(r, directusSessionName)
	rawCookie, ok := session.Values[directusCookieKey].(string)
	if !ok {
		return nil, errors.New("Couldn't get session cookie")
	}

	headers := []*Header{}
	headers = append(headers, &Header{
		Key:   "Cookie",
		Value: rawCookie,
	})
	headers = append(headers, &Header{
		Key:   "Content-Type",
		Value: "application/json",
	})

	// Make the user request
	req, err := http.NewRequest("POST", url, bytes.NewBuffer([]byte(body)))
	if err != nil {
		return nil, err
	}

	// Add headers to request
	for _, header := range headers {
		req.Header.Set(header.Key, header.Value)
	}

	// Create an HTTP client
	client := &http.Client{
		Timeout: time.Duration(5 * time.Second),
	}

	// Perform the request
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// If there are any errors, generate a response
	errorResponse := ErrorResponse{}
	if resp.StatusCode >= 400 && resp.StatusCode < 500 {
		json.NewDecoder(resp.Body).Decode(&errorResponse)
		if errorResponse.Error.Code == "" {
			errorResponse.Error.Code = "0000"
		}

		return nil, fmt.Errorf("%s: %s", errorResponse.Error.Code, errorResponse.Error.Message)
	}
	if resp.StatusCode >= 500 {
		errorResponse.Error = ErrorData{
			Code:    "9999",
			Message: "Server error",
		}

		json.NewDecoder(resp.Body).Decode(&errorResponse)
		return nil, fmt.Errorf("%s: %s", errorResponse.Error.Code, errorResponse.Error.Message)
	}

	return ioutil.ReadAll(resp.Body)
}
