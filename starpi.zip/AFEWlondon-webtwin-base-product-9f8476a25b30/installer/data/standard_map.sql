# ************************************************************
# Sequel Ace SQL dump
# Version 2104
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 5.7.32-0ubuntu0.18.04.1)
# Database: laval_virtual
# Generation Time: 2020-12-03 17:55:58 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table cta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cta`;

CREATE TABLE `cta` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `cta_type` varchar(255) DEFAULT NULL,
  `top` int(11) DEFAULT '50',
  `left` int(11) DEFAULT '50',
  `width` int(11) DEFAULT '30' COMMENT 'the width of the hit are in percent (1-100)',
  `height` int(11) DEFAULT '30' COMMENT 'the heigh of the hit are in percent (1-100)',
  `info_panel` int(10) unsigned DEFAULT NULL,
  `video_modal` int(10) unsigned DEFAULT NULL,
  `info_modal` int(10) unsigned DEFAULT NULL,
  `link_url` varchar(200) DEFAULT NULL COMMENT 'the url of the site you want to link starting with http:// or https://',
  `cta_style` varchar(255) DEFAULT 'Button' COMMENT 'To configure on Overlay, please contact your Immersionn admin. ',
  `admin_title` varchar(200) NOT NULL COMMENT 'A useful name for the CTA for use in the CMS only. This will not be displayed to the end user',
  `show_hit_area` tinyint(3) unsigned DEFAULT NULL,
  `unity_scene` int(10) unsigned DEFAULT NULL COMMENT 'The category that will be open when the user click on the CTAs',
  `gtm_uid` varchar(200) DEFAULT NULL COMMENT 'The unique Google Analytic name under which clicking on this link will be reported',
  `gtm_tag_type` varchar(100) DEFAULT NULL COMMENT 'The Level at which clicking on this link will be reported ',
  `cta_background_image` int(10) unsigned DEFAULT NULL,
  `skew` int(11) DEFAULT NULL COMMENT 'Overlay CTA skew (degrees)',
  `cta_appearance` varchar(100) DEFAULT 'default' COMMENT 'Select alternate if you want to apply a 2ndary CTA style that you have defined in your theme.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table cta_topic_panels
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cta_topic_panels`;

CREATE TABLE `cta_topic_panels` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `cta` int(11) DEFAULT NULL,
  `panel` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table cta_translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cta_translations`;

CREATE TABLE `cta_translations` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `cta_text` varchar(200) DEFAULT NULL,
  `cta_description` varchar(200) DEFAULT NULL,
  `cta` int(11) DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table directus_collection_presets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_collection_presets`;

CREATE TABLE `directus_collection_presets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `user` int(11) unsigned DEFAULT NULL,
  `role` int(11) unsigned DEFAULT NULL,
  `collection` varchar(64) NOT NULL,
  `search_query` varchar(100) DEFAULT NULL,
  `filters` text,
  `view_type` varchar(100) NOT NULL DEFAULT 'tabular',
  `view_query` text,
  `view_options` text,
  `translation` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_collection_title` (`user`,`collection`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_collection_presets` WRITE;
/*!40000 ALTER TABLE `directus_collection_presets` DISABLE KEYS */;

INSERT INTO `directus_collection_presets` (`id`, `title`, `user`, `role`, `collection`, `search_query`, `filters`, `view_type`, `view_query`, `view_options`, `translation`)
VALUES
	(1,NULL,NULL,NULL,'directus_activity',NULL,NULL,'timeline','{\"timeline\":{\"sort\":\"-action_on\"}}','{\"timeline\":{\"date\":\"action_on\",\"title\":\"{{ action }} by {{ action_by.first_name }} {{ action_by.last_name }} (#{{ item }})\",\"content\":\"collection\",\"color\":\"action\"}}',NULL),
	(2,NULL,NULL,NULL,'directus_files',NULL,NULL,'cards',NULL,'{\"cards\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"}}',NULL),
	(3,NULL,NULL,NULL,'directus_users',NULL,NULL,'cards',NULL,'{\"cards\":{\"title\":\"first_name\",\"subtitle\":\"last_name\",\"content\":\"title\",\"src\":\"avatar\",\"icon\":\"person\"}}',NULL),
	(4,NULL,NULL,NULL,'directus_webhooks',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,http_action,url,collection,directus_action\"}}','{\"tabular\":{\"widths\":{\"status\":32,\"http_action\":72,\"url\":200,\"collection\":200,\"directus_action\":200}}}',NULL),
	(5,NULL,3,NULL,'maps',NULL,NULL,'tabular','{\"tabular\":{\"sort\":\"-map_name\",\"fields\":\"status,map_name,uid,unity_scenes\"}}','{\"tabular\":{\"widths\":{\"status\":99,\"map_name\":159,\"uid\":200,\"unity_scenes\":200}}}',NULL),
	(7,NULL,1,NULL,'info_modals',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":80,\"title\":475,\"infographic\":135,\"top\":200}}}',NULL),
	(8,NULL,3,NULL,'cta',NULL,NULL,'tabular','{\"tabular\":{\"sort\":\"-cta_type\",\"fields\":\"status,admin_title,cta_type\"}}','{\"tabular\":{\"widths\":{\"status\":103,\"admin_title\":221,\"cta_type\":182,\"admin_tags\":200}}}',NULL),
	(9,NULL,3,NULL,'unity_scenes',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,scene_name,scene_url\"}}','{\"tabular\":{\"widths\":{\"status\":121,\"scene_name\":200,\"scene_url\":200,\"scene_id\":200}}}',NULL),
	(10,NULL,1,NULL,'info_panels',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":86,\"title\":458,\"sponsors\":200}}}',NULL),
	(11,NULL,1,NULL,'video_modals',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":74,\"title\":200}}}',NULL),
	(12,NULL,1,NULL,'unity_scenes',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,scene_name,admin_tags,scene_url,is_landing_scene\",\"sort\":\"scene_url\"}}','{\"tabular\":{\"widths\":{\"status\":107,\"scene_name\":339,\"scene_url\":200,\"scene_id\":200}}}',NULL),
	(13,NULL,1,NULL,'maps',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"map_name,uid,unity_data,status\"}}','{\"tabular\":{\"widths\":{\"status\":91,\"map_name\":200,\"uid\":200,\"unity_scenes\":200}}}',NULL),
	(14,NULL,3,NULL,'video_modals',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"divider_status\":175,\"status\":200,\"title\":200}}}',NULL),
	(15,NULL,3,NULL,'info_modals',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":119,\"title\":200}}}',NULL),
	(16,NULL,3,NULL,'map_themes',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,theme_name\"}}',NULL,NULL),
	(18,NULL,2,NULL,'cta','rev',NULL,'tabular','{\"tabular\":{\"sort\":\"cta_type\",\"fields\":\"admin_title,cta_type,cta_style,status,unity_scene\"}}','{\"tabular\":{\"widths\":{\"admin_title\":254,\"cta_type\":200,\"cta_style\":200,\"status\":200,\"unity_scene\":200}}}',NULL),
	(19,NULL,2,NULL,'info_modals',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"title,status\"}}',NULL,NULL),
	(20,NULL,2,NULL,'sponsors',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"logo,link,name,status\"}}',NULL,NULL),
	(21,NULL,2,NULL,'info_panels',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":200,\"title\":381,\"sponsors\":200}}}',NULL),
	(22,NULL,1,NULL,'map_themes',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,theme_name\"}}',NULL,NULL),
	(23,NULL,1,NULL,'directus_files','modifi',NULL,'tabular','{\"tabular\":{\"fields\":\"filename_disk,type,storage,id,filename_download,uploaded_on,filesize\",\"sort\":\"-uploaded_on\"}}','{\"cards\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\",\"fit\":\"crop\"},\"tabular\":{\"widths\":{\"filename_disk\":458,\"storage\":200,\"id\":200,\"filename_download\":200}}}',NULL),
	(24,NULL,3,NULL,'directus_files',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"private_hash,title,filename_disk,filename_download,uploaded_on\"}}','{\"cards\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"}}',NULL),
	(25,NULL,1,NULL,'cta','laval',NULL,'tabular','{\"tabular\":{\"fields\":\"admin_title,status,cta_type,info_panel,video_modal,info_modal,unity_scene,description,name_and_description\",\"sort\":\"-cta_type\"}}','{\"tabular\":{\"spacing\":\"compact\"}}',NULL),
	(26,NULL,5,NULL,'maps',NULL,NULL,'tabular','{\"tabular\":{\"sort\":\"status\"}}','{\"tabular\":{\"widths\":{\"about_this_page\":200,\"status\":200,\"map_name\":200,\"default_language_code\":200}}}',NULL),
	(27,NULL,10,NULL,'maps',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,map_name\"}}',NULL,NULL),
	(28,NULL,10,NULL,'unity_scenes',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,scene_url\"}}',NULL,NULL),
	(29,NULL,10,NULL,'cta',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,admin_title,cta_type\"}}','{\"tabular\":{\"widths\":{\"status\":119,\"admin_title\":200,\"cta_type\":200}}}',NULL),
	(30,NULL,2,NULL,'maps',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,initial_scene_id,uid,map_name\"}}',NULL,NULL),
	(31,NULL,2,NULL,'directus_files',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"private_hash,filename_disk,filename_download,title,storage,id,uploaded_on,uploaded_by\",\"sort\":\"-uploaded_on\"}}','{\"cards\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"tabular\":{\"widths\":{\"private_hash\":200,\"filename_disk\":541,\"filename_download\":200,\"title\":200,\"storage\":200,\"id\":200}}}',NULL),
	(32,NULL,4,NULL,'cta',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"admin_title,status,cta_type,left\"}}',NULL,NULL),
	(33,NULL,5,NULL,'cta',NULL,NULL,'tabular','{\"tabular\":{\"fields\":\"status,admin_title,cta_type,cta_style\"}}',NULL,NULL),
	(34,NULL,11,NULL,'sponsors',NULL,NULL,'tabular',NULL,'{\"tabular\":{\"widths\":{\"status\":104,\"name\":200,\"logo\":200,\"link\":200}}}',NULL);

/*!40000 ALTER TABLE `directus_collection_presets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table directus_collections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_collections`;

CREATE TABLE `directus_collections` (
  `collection` varchar(64) NOT NULL,
  `managed` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `single` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `icon` varchar(30) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `translation` text,
  PRIMARY KEY (`collection`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_collections` WRITE;
/*!40000 ALTER TABLE `directus_collections` DISABLE KEYS */;

INSERT INTO `directus_collections` (`collection`, `managed`, `hidden`, `single`, `icon`, `note`, `translation`)
VALUES
	('cta',1,0,0,'touch_app',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"5. Call to Action\"}]'),
	('cta_topic_panels',1,1,0,NULL,NULL,NULL),
	('cta_translations',1,1,0,NULL,NULL,NULL),
	('industries',1,0,0,NULL,NULL,NULL),
	('info_modals',1,0,0,'insert_chart',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"2. Media - Pictures\"}]'),
	('info_modal_translations',1,1,0,'assessment',NULL,NULL),
	('info_panels',1,0,0,'chrome_reader_mode',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"3. Product Panel\"}]'),
	('info_panel_sponsors',1,1,0,NULL,NULL,NULL),
	('info_panel_translations',1,1,0,'chrome_reader_mode',NULL,NULL),
	('maps',1,0,0,'map','Configure what appear on the page','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"0. WebTwin\"}]'),
	('map_ctas',1,1,0,'touch_app',NULL,NULL),
	('map_scenes',1,1,0,NULL,NULL,NULL),
	('map_themes',1,0,0,'format_paint',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"7. Themes\"}]'),
	('map_translations',1,1,0,NULL,NULL,NULL),
	('scene_ctas',1,1,0,NULL,NULL,NULL),
	('sponsors',1,0,0,'stars',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"4. Suppliers\"}]'),
	('supplier_industries',1,1,0,NULL,NULL,NULL),
	('supplier_topics',1,1,0,NULL,NULL,NULL),
	('topics',1,0,0,NULL,NULL,NULL),
	('unity_scenes',1,0,0,'image',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"6. Category\"}]'),
	('unity_scene_sponsors',1,1,0,NULL,NULL,NULL),
	('video_modals',1,0,0,'videocam',NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"1. Media - Videos\"}]'),
	('video_modal_translations',1,1,0,'videocam',NULL,NULL);

/*!40000 ALTER TABLE `directus_collections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table directus_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_fields`;

CREATE TABLE `directus_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `collection` varchar(64) NOT NULL,
  `field` varchar(64) NOT NULL,
  `type` varchar(64) NOT NULL,
  `interface` varchar(64) DEFAULT NULL,
  `options` text,
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `validation` varchar(500) DEFAULT NULL,
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readonly` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hidden_detail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hidden_browse` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned DEFAULT NULL,
  `width` varchar(50) DEFAULT 'full',
  `group` int(11) unsigned DEFAULT NULL,
  `note` varchar(1024) DEFAULT NULL,
  `translation` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_collection_field` (`collection`,`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_fields` WRITE;
/*!40000 ALTER TABLE `directus_fields` DISABLE KEYS */;

INSERT INTO `directus_fields` (`id`, `collection`, `field`, `type`, `interface`, `options`, `locked`, `validation`, `required`, `readonly`, `hidden_detail`, `hidden_browse`, `sort`, `width`, `group`, `note`, `translation`)
VALUES
	(1,'directus_fields','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(2,'directus_fields','collection','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(3,'directus_fields','field','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(4,'directus_fields','type','string','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(5,'directus_fields','interface','string','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(6,'directus_fields','options','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(7,'directus_fields','locked','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(8,'directus_fields','translation','json','repeater','{\n                    \"fields\": [\n                        {\n                            \"field\": \"locale\",\n                            \"type\": \"string\",\n                            \"interface\": \"language\",\n                            \"options\": {\n                                \"limit\": true\n                            },\n                            \"width\": \"half\"\n                        },\n                        {\n                            \"field\": \"translation\",\n                            \"type\": \"string\",\n                            \"interface\": \"text-input\",\n                            \"width\": \"half\"\n                        }\n                    ]\n                }',1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(9,'directus_fields','readonly','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(10,'directus_fields','validation','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(11,'directus_fields','required','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(12,'directus_fields','sort','sort','sort',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(13,'directus_fields','note','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(14,'directus_fields','hidden_detail','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(15,'directus_fields','hidden_browse','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(16,'directus_fields','width','integer','numeric',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(17,'directus_fields','group','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(18,'directus_fields','auth_token_ttl','integer','numeric',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(19,'directus_activity','id','integer','primary-key',NULL,1,NULL,1,1,1,0,NULL,'full',NULL,NULL,NULL),
	(20,'directus_activity','action','string','text-input','{\"iconRight\":\"change_history\"}',1,NULL,0,1,0,0,1,'full',NULL,NULL,NULL),
	(21,'directus_activity','collection','string','collections','{\"iconRight\":\"list_alt\",\"include_system\":true}',1,NULL,0,1,0,0,2,'half',NULL,NULL,NULL),
	(22,'directus_activity','item','string','text-input','{\"iconRight\":\"link\"}',1,NULL,0,1,0,0,3,'half',NULL,NULL,NULL),
	(23,'directus_activity','action_by','integer','user','{\"iconRight\":\"account_circle\"}',1,NULL,0,1,0,0,4,'half',NULL,NULL,NULL),
	(24,'directus_activity','action_on','datetime','datetime','{\"showRelative\":true,\"iconRight\":\"calendar_today\"}',1,NULL,0,1,0,0,5,'half',NULL,NULL,NULL),
	(25,'directus_activity','edited_on','datetime','datetime','{\"showRelative\":true,\"iconRight\":\"edit\"}',1,NULL,0,1,0,0,6,'half',NULL,NULL,NULL),
	(26,'directus_activity','comment_deleted_on','datetime','datetime','{\"showRelative\":true,\"iconRight\":\"delete_outline\"}',1,NULL,0,1,0,0,7,'half',NULL,NULL,NULL),
	(27,'directus_activity','ip','string','text-input','{\"iconRight\":\"my_location\"}',1,NULL,0,1,0,0,8,'half',NULL,NULL,NULL),
	(28,'directus_activity','user_agent','string','text-input','{\"iconRight\":\"devices_other\"}',1,NULL,0,1,0,0,9,'half',NULL,NULL,NULL),
	(29,'directus_activity','comment','string','textarea',NULL,1,NULL,0,1,0,0,10,'full',NULL,NULL,NULL),
	(30,'directus_collection_presets','id','integer','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(31,'directus_collection_presets','title','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(32,'directus_collection_presets','user','integer','user',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(33,'directus_collection_presets','role','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(34,'directus_collection_presets','collection','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(35,'directus_collection_presets','search_query','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(36,'directus_collection_presets','filters','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(37,'directus_collection_presets','view_options','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(38,'directus_collection_presets','view_type','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(39,'directus_collection_presets','view_query','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(40,'directus_collections','fields','o2m','one-to-many',NULL,1,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(41,'directus_collections','collection','string','primary-key',NULL,1,NULL,1,1,0,0,2,'half',NULL,NULL,NULL),
	(42,'directus_collections','note','string','text-input',NULL,1,NULL,0,0,0,0,3,'half',NULL,'An internal description.',NULL),
	(43,'directus_collections','managed','boolean','switch',NULL,1,NULL,0,0,1,0,4,'half',NULL,'[Learn More](https://docs.directus.io/guides/collections.html#managing-collections).',NULL),
	(44,'directus_collections','hidden','boolean','switch',NULL,1,NULL,0,0,0,0,5,'half',NULL,'[Learn More](https://docs.directus.io/guides/collections.html#hidden).',NULL),
	(45,'directus_collections','single','boolean','switch',NULL,1,NULL,0,0,0,0,6,'half',NULL,'[Learn More](https://docs.directus.io/guides/collections.html#single).',NULL),
	(46,'directus_collections','translation','json','repeater','{\n                    \"fields\": [\n                        {\n                            \"field\": \"locale\",\n                            \"type\": \"string\",\n                            \"interface\": \"language\",\n                            \"options\": {\n                                \"limit\": true\n                            },\n                            \"width\": \"half\"\n                        },\n                        {\n                            \"field\": \"translation\",\n                            \"type\": \"string\",\n                            \"interface\": \"text-input\",\n                            \"width\": \"half\"\n                        }\n                    ]\n                }',1,NULL,0,0,0,0,7,'full',NULL,NULL,NULL),
	(47,'directus_collections','icon','string','icon',NULL,1,NULL,0,0,0,0,8,'full',NULL,'The icon shown in the App\'s navigation sidebar.',NULL),
	(48,'directus_files','preview','alias','file-preview',NULL,1,NULL,0,0,0,0,1,'full',NULL,NULL,NULL),
	(49,'directus_files','title','string','text-input','{\"placeholder\":\"Enter a descriptive title...\",\"iconRight\":\"title\"}',1,NULL,0,0,0,0,2,'full',NULL,NULL,NULL),
	(50,'directus_files','tags','array','tags','{\"placeholder\":\"Enter a keyword then hit enter...\"}',1,NULL,0,0,0,0,3,'half',NULL,NULL,NULL),
	(51,'directus_files','location','string','text-input','{\"placeholder\":\"Enter a location...\",\"iconRight\":\"place\"}',1,NULL,0,0,0,0,4,'half',NULL,NULL,NULL),
	(52,'directus_files','description','string','wysiwyg','{\"toolbar\":[\"bold\",\"italic\",\"underline\",\"link\",\"code\"]}',1,NULL,0,0,0,0,5,'full',NULL,NULL,NULL),
	(53,'directus_files','filename_download','string','text-input','{\"monospace\":true,\"iconRight\":\"get_app\"}',1,NULL,0,0,0,0,6,'full',NULL,NULL,NULL),
	(54,'directus_files','filename_disk','string','text-input','{\"placeholder\":\"Enter a unique file name...\",\"iconRight\":\"insert_drive_file\"}',1,NULL,0,0,0,0,7,'full',NULL,NULL,NULL),
	(55,'directus_files','private_hash','string','slug','{\"iconRight\":\"lock\"}',1,NULL,0,0,0,0,8,'half',NULL,NULL,NULL),
	(56,'directus_files','checksum','string','text-input','{\"iconRight\":\"check\",\"monospace\":true}',1,NULL,0,1,0,0,9,'half',NULL,NULL,NULL),
	(57,'directus_files','uploaded_on','datetime','datetime','{\"iconRight\":\"today\"}',1,NULL,1,1,0,0,10,'half',NULL,NULL,NULL),
	(58,'directus_files','uploaded_by','owner','owner',NULL,1,NULL,1,1,0,0,11,'half',NULL,NULL,NULL),
	(59,'directus_files','width','integer','numeric','{\"iconRight\":\"straighten\"}',1,NULL,0,1,0,0,12,'half',NULL,NULL,NULL),
	(60,'directus_files','height','integer','numeric','{\"iconRight\":\"straighten\"}',1,NULL,0,1,0,0,13,'half',NULL,NULL,NULL),
	(61,'directus_files','duration','integer','numeric','{\"iconRight\":\"timer\"}',1,NULL,0,1,0,0,14,'half',NULL,NULL,NULL),
	(62,'directus_files','filesize','integer','file-size','{\"iconRight\":\"storage\"}',1,NULL,0,1,0,0,15,'half',NULL,NULL,NULL),
	(63,'directus_files','metadata','json','key-value','{\"keyInterface\":\"text-input\",\"keyDataType\":\"string\",\"keyOptions\":{\"monospace\":true,\"placeholder\":\"Key\"},\"valueInterface\":\"text-input\",\"valueDataType\":\"string\",\"valueOptions\":{\"monospace\":true,\"placeholder\":\"Value\"}}',1,NULL,0,0,0,0,15,'full',NULL,NULL,NULL),
	(64,'directus_files','data','alias','file',NULL,1,NULL,0,0,1,0,NULL,'full',NULL,NULL,NULL),
	(65,'directus_files','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(66,'directus_files','type','string','text-input',NULL,1,NULL,0,1,1,0,NULL,'full',NULL,NULL,NULL),
	(67,'directus_files','charset','string','text-input',NULL,1,NULL,0,1,1,1,NULL,'full',NULL,NULL,NULL),
	(68,'directus_files','embed','string','text-input',NULL,1,NULL,0,1,1,0,NULL,'full',NULL,NULL,NULL),
	(69,'directus_files','folder','m2o','many-to-one',NULL,1,NULL,0,0,1,0,NULL,'full',NULL,NULL,NULL),
	(70,'directus_files','storage','string','text-input',NULL,1,NULL,0,0,1,1,NULL,'full',NULL,NULL,NULL),
	(71,'directus_folders','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(72,'directus_folders','name','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(73,'directus_folders','parent_folder','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(74,'directus_roles','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(75,'directus_roles','external_id','string','text-input',NULL,1,NULL,0,1,1,1,NULL,'full',NULL,NULL,NULL),
	(76,'directus_roles','name','string','text-input',NULL,1,NULL,1,0,0,0,1,'half',NULL,NULL,NULL),
	(77,'directus_roles','description','string','text-input',NULL,1,NULL,0,0,0,0,2,'half',NULL,NULL,NULL),
	(78,'directus_roles','ip_whitelist','array','tags','{\"\":\"Add an IP address...\"}',1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(79,'directus_roles','enforce_2fa','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(80,'directus_roles','users','o2m','one-to-many','{\"fields\":\"first_name,last_name\"}',1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(81,'directus_roles','module_listing','json','repeater','{\"template\":\"{{ name }}\",\"createItemText\":\"Add Module\",\"fields\":[{\"field\":\"name\",\"interface\":\"text-input\",\"type\":\"string\",\"width\":\"half\"},{\"field\":\"link\",\"interface\":\"text-input\",\"type\":\"string\",\"width\":\"half\"},{\"field\":\"icon\",\"interface\":\"icon\",\"type\":\"string\",\"width\":\"full\"}]}',1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(82,'directus_roles','collection_listing','json','repeater','{\"template\":\"{{ group_name }}\",\"createItemText\":\"Add Group\",\"fields\":[{\"field\":\"group_name\",\"width\":\"full\",\"interface\":\"text-input\",\"type\":\"string\"},{\"field\":\"collections\",\"interface\":\"repeater\",\"type\":\"JSON\",\"options\":{\"createItemText\":\"Add Collection\",\"fields\":[{\"field\":\"collection\",\"type\":\"string\",\"interface\":\"collections\",\"width\":\"full\"}]}}]}',1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(83,'directus_permissions','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(84,'directus_permissions','collection','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(85,'directus_permissions','role','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(86,'directus_permissions','status','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(87,'directus_permissions','create','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(88,'directus_permissions','read','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(89,'directus_permissions','update','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(90,'directus_permissions','delete','string','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(91,'directus_permissions','comment','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(92,'directus_permissions','explain','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(93,'directus_permissions','status_blacklist','array','tags',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(94,'directus_permissions','read_field_blacklist','array','tags',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(95,'directus_permissions','write_field_blacklist','array','tags',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(96,'directus_relations','id','integer','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(97,'directus_relations','collection_many','string','collections',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(98,'directus_relations','field_many','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(99,'directus_relations','collection_one','string','collections',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(100,'directus_relations','field_one','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(101,'directus_relations','junction_field','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(102,'directus_revisions','id','integer','primary-key',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(103,'directus_revisions','activity','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(104,'directus_revisions','collection','m2o','many-to-one',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(105,'directus_revisions','item','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(106,'directus_revisions','data','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(107,'directus_revisions','delta','json','json',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(108,'directus_revisions','parent_item','string','text-input',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(109,'directus_revisions','parent_collection','string','collections',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(110,'directus_revisions','parent_changed','boolean','switch',NULL,1,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(111,'directus_settings','project_name','string','text-input','{\"iconRight\":\"title\"}',1,NULL,1,0,0,0,1,'half',NULL,'Logo in the top-left of the App (40x40)',NULL),
	(112,'directus_settings','project_url','string','text-input','{\"iconRight\":\"link\"}',1,NULL,0,0,0,0,2,'half',NULL,'External link for the App\'s top-left logo',NULL),
	(113,'directus_settings','project_logo','file','file',NULL,1,NULL,0,0,0,0,3,'half',NULL,'A 40x40 brand logo, ideally a white SVG/PNG',NULL),
	(114,'directus_settings','project_color','string','color',NULL,1,NULL,0,0,0,0,4,'half',NULL,'Color for login background and App\'s logo',NULL),
	(115,'directus_settings','project_foreground','file','file',NULL,1,NULL,0,0,0,0,5,'half',NULL,'Centered image (eg: logo) for the login page',NULL),
	(116,'directus_settings','project_background','file','file',NULL,1,NULL,0,0,0,0,6,'half',NULL,'Full-screen background for the login page',NULL),
	(117,'directus_settings','project_public_note','string','markdown',NULL,1,NULL,0,0,0,0,7,'full',NULL,'This value will be shown on the public pages of the app',NULL),
	(118,'directus_settings','default_locale','string','language','{\"limit\":true}',1,NULL,0,0,0,0,8,'half',NULL,'Default locale for Directus Users',NULL),
	(119,'directus_settings','telemetry','boolean','switch',NULL,1,NULL,0,0,0,0,9,'half',NULL,'<a href=\"https://docs.directus.io/getting-started/concepts.html#telemetry\" target=\"_blank\">Learn More</a>',NULL),
	(120,'directus_settings','data_divider','alias','divider','{\"style\":\"large\",\"title\":\"Data\",\"hr\":true}',1,NULL,0,0,0,1,11,'full',NULL,NULL,NULL),
	(121,'directus_settings','default_limit','integer','numeric','{\"iconRight\":\"keyboard_tab\"}',1,NULL,1,0,0,0,12,'half',NULL,'Default item count in API and App responses',NULL),
	(122,'directus_settings','sort_null_last','boolean','switch',NULL,1,NULL,0,0,0,0,13,'half',NULL,'NULL values are sorted last',NULL),
	(123,'directus_settings','security_divider','alias','divider','{\"style\":\"large\",\"title\":\"Security\",\"hr\":true}',1,NULL,0,0,0,1,20,'full',NULL,NULL,NULL),
	(124,'directus_settings','auto_sign_out','integer','numeric','{\"iconRight\":\"timer\"}',1,NULL,1,0,0,0,22,'half',NULL,'Minutes before idle users are signed out',NULL),
	(125,'directus_settings','login_attempts_allowed','integer','numeric','{\"iconRight\":\"lock\"}',1,NULL,0,0,0,0,23,'half',NULL,'Failed login attempts before suspending users',NULL),
	(126,'directus_settings','password_policy','string','dropdown','{\"choices\":{\"\":\"None\",\"\\/^.{8,}$\\/\":\"Weak\",\"\\/(?=^.{8,}$)(?=.*\\\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+}{\';\'?>.<,])(?!.*\\\\s).*$\\/\":\"Strong\"}}',1,NULL,0,0,0,0,24,'half',NULL,'Weak: Minimum length 8; Strong: 1 small-case letter, 1 capital letter, 1 digit, 1 special character and the length should be minimum 8',NULL),
	(127,'directus_settings','auth_token_ttl','integer','numeric','{\"iconRight\":\"timer\"}',1,NULL,0,0,0,0,25,'half',NULL,'Minutes the API authorization token will last',NULL),
	(128,'directus_settings','files_divider','alias','divider','{\"style\":\"large\",\"title\":\"Files & Thumbnails\",\"hr\":true}',1,NULL,0,0,0,1,30,'full',NULL,NULL,NULL),
	(129,'directus_settings','file_naming','string','dropdown','{\"choices\":{\"uuid\":\"UUID (Obfuscated)\",\"file_name\":\"File Name (Readable)\"}}',1,NULL,0,0,0,0,31,'half',NULL,'File-system naming convention for uploads',NULL),
	(130,'directus_settings','asset_url_naming','string','dropdown','{\"choices\":{\"private_hash\":\"Private Hash (Obfuscated)\",\"filename_download\":\"File Name (Readable)\"}}',1,NULL,0,0,0,0,32,'half',NULL,'Thumbnail URL convention',NULL),
	(131,'directus_settings','file_mimetype_whitelist','array','tags','{\"placeholder\":\"Enter a file mimetype then hit enter (eg: image\\/jpeg)\"}',1,NULL,0,0,0,0,33,'half',NULL,'Enter a file mimetype then hit enter (eg: image/jpeg)',NULL),
	(132,'directus_settings','asset_whitelist','json','repeater','{\"template\":\"{{key}}\",\"fields\":[{\"field\":\"key\",\"interface\":\"slug\",\"width\":\"half\",\"type\":\"string\",\"required\":true,\"options\":{\"onlyOnCreate\":false}},{\"field\":\"fit\",\"interface\":\"dropdown\",\"width\":\"half\",\"type\":\"string\",\"options\":{\"choices\":{\"crop\":\"Crop (forces exact size)\",\"contain\":\"Contain (preserve aspect ratio)\"}},\"required\":true},{\"field\":\"width\",\"interface\":\"numeric\",\"width\":\"half\",\"type\":\"integer\",\"required\":true},{\"field\":\"height\",\"interface\":\"numeric\",\"width\":\"half\",\"type\":\"integer\",\"required\":true},{\"field\":\"quality\",\"interface\":\"slider\",\"width\":\"full\",\"type\":\"integer\",\"default\":80,\"options\":{\"min\":0,\"max\":100,\"step\":1},\"required\":true}]}',0,NULL,0,0,0,0,34,'full',NULL,'Defines how the thumbnail will be generated based on the requested params.',NULL),
	(133,'directus_settings','asset_whitelist_system','json','json',NULL,0,NULL,0,1,1,1,35,'half',NULL,NULL,NULL),
	(134,'directus_settings','youtube_api_key','string','text-input','{\"iconRight\":\"videocam\"}',1,NULL,0,0,0,0,36,'full',NULL,'Allows fetching more YouTube Embed info',NULL),
	(135,'directus_users','id','integer','primary-key',NULL,1,NULL,1,0,1,0,1,'full',NULL,NULL,NULL),
	(136,'directus_users','status','status','status','{\"status_mapping\":{\"draft\":{\"name\":\"Draft\",\"text_color\":\"white\",\"background_color\":\"light-gray\",\"listing_subdued\":false,\"listing_badge\":true,\"soft_delete\":false},\"invited\":{\"name\":\"Invited\",\"text_color\":\"white\",\"background_color\":\"light-gray\",\"listing_subdued\":false,\"listing_badge\":true,\"soft_delete\":false},\"active\":{\"name\":\"Active\",\"text_color\":\"white\",\"background_color\":\"success\",\"listing_subdued\":false,\"listing_badge\":false,\"soft_delete\":false},\"suspended\":{\"name\":\"Suspended\",\"text_color\":\"white\",\"background_color\":\"light-gray\",\"listing_subdued\":false,\"listing_badge\":true,\"soft_delete\":false},\"deleted\":{\"name\":\"Deleted\",\"text_color\":\"white\",\"background_color\":\"danger\",\"listing_subdued\":false,\"listing_badge\":true,\"soft_delete\":true}}}',1,NULL,1,0,0,0,2,'full',NULL,NULL,NULL),
	(137,'directus_users','first_name','string','text-input','{\"iconRight\":\"account_circle\"}',1,NULL,1,0,0,0,3,'half',NULL,NULL,NULL),
	(138,'directus_users','last_name','string','text-input','{\"iconRight\":\"account_circle\"}',1,NULL,1,0,0,0,4,'half',NULL,NULL,NULL),
	(139,'directus_users','email','string','text-input','{\"iconRight\":\"alternate_email\"}',1,'$email',1,0,0,0,5,'half',NULL,NULL,NULL),
	(140,'directus_users','email_notifications','boolean','switch',NULL,1,NULL,0,0,0,0,6,'half',NULL,NULL,NULL),
	(141,'directus_users','password','hash','password',NULL,1,NULL,1,0,0,0,7,'half',NULL,NULL,NULL),
	(142,'directus_users','role','m2o','user-roles',NULL,1,NULL,1,0,0,0,8,'half',NULL,NULL,NULL),
	(143,'directus_users','company','string','text-input','{\"iconRight\":\"location_city\"}',0,NULL,0,0,0,0,9,'half',NULL,NULL,NULL),
	(144,'directus_users','title','string','text-input','{\"iconRight\":\"text_fields\"}',0,NULL,0,0,0,0,10,'half',NULL,NULL,NULL),
	(145,'directus_users','timezone','string','dropdown','{\"choices\":{\"Pacific\\/Midway\":\"(UTC-11:00) Midway Island\",\"Pacific\\/Samoa\":\"(UTC-11:00) Samoa\",\"Pacific\\/Honolulu\":\"(UTC-10:00) Hawaii\",\"US\\/Alaska\":\"(UTC-09:00) Alaska\",\"America\\/Los_Angeles\":\"(UTC-08:00) Pacific Time (US & Canada)\",\"America\\/Tijuana\":\"(UTC-08:00) Tijuana\",\"US\\/Arizona\":\"(UTC-07:00) Arizona\",\"America\\/Chihuahua\":\"(UTC-07:00) Chihuahua\",\"America\\/Mexico\\/La_Paz\":\"(UTC-07:00) La Paz\",\"America\\/Mazatlan\":\"(UTC-07:00) Mazatlan\",\"US\\/Mountain\":\"(UTC-07:00) Mountain Time (US & Canada)\",\"America\\/Managua\":\"(UTC-06:00) Central America\",\"US\\/Central\":\"(UTC-06:00) Central Time (US & Canada)\",\"America\\/Guadalajara\":\"(UTC-06:00) Guadalajara\",\"America\\/Mexico_City\":\"(UTC-06:00) Mexico City\",\"America\\/Monterrey\":\"(UTC-06:00) Monterrey\",\"Canada\\/Saskatchewan\":\"(UTC-06:00) Saskatchewan\",\"America\\/Bogota\":\"(UTC-05:00) Bogota\",\"US\\/Eastern\":\"(UTC-05:00) Eastern Time (US & Canada)\",\"US\\/East-Indiana\":\"(UTC-05:00) Indiana (East)\",\"America\\/Lima\":\"(UTC-05:00) Lima\",\"America\\/Quito\":\"(UTC-05:00) Quito\",\"Canada\\/Atlantic\":\"(UTC-04:00) Atlantic Time (Canada)\",\"America\\/New_York\":\"(UTC-04:00) New York\",\"America\\/Caracas\":\"(UTC-04:30) Caracas\",\"America\\/La_Paz\":\"(UTC-04:00) La Paz\",\"America\\/Santiago\":\"(UTC-04:00) Santiago\",\"America\\/Santo_Domingo\":\"(UTC-04:00) Santo Domingo\",\"Canada\\/Newfoundland\":\"(UTC-03:30) Newfoundland\",\"America\\/Sao_Paulo\":\"(UTC-03:00) Brasilia\",\"America\\/Argentina\\/Buenos_Aires\":\"(UTC-03:00) Buenos Aires\",\"America\\/Argentina\\/GeorgeTown\":\"(UTC-03:00) Georgetown\",\"America\\/Godthab\":\"(UTC-03:00) Greenland\",\"America\\/Noronha\":\"(UTC-02:00) Mid-Atlantic\",\"Atlantic\\/Azores\":\"(UTC-01:00) Azores\",\"Atlantic\\/Cape_Verde\":\"(UTC-01:00) Cape Verde Is.\",\"Africa\\/Casablanca\":\"(UTC+00:00) Casablanca\",\"Europe\\/Edinburgh\":\"(UTC+00:00) Edinburgh\",\"Etc\\/Greenwich\":\"(UTC+00:00) Greenwich Mean Time : Dublin\",\"Europe\\/Lisbon\":\"(UTC+00:00) Lisbon\",\"Europe\\/London\":\"(UTC+00:00) London\",\"Africa\\/Monrovia\":\"(UTC+00:00) Monrovia\",\"UTC\":\"(UTC+00:00) UTC\",\"Europe\\/Amsterdam\":\"(UTC+01:00) Amsterdam\",\"Europe\\/Belgrade\":\"(UTC+01:00) Belgrade\",\"Europe\\/Berlin\":\"(UTC+01:00) Berlin\",\"Europe\\/Bern\":\"(UTC+01:00) Bern\",\"Europe\\/Bratislava\":\"(UTC+01:00) Bratislava\",\"Europe\\/Brussels\":\"(UTC+01:00) Brussels\",\"Europe\\/Budapest\":\"(UTC+01:00) Budapest\",\"Europe\\/Copenhagen\":\"(UTC+01:00) Copenhagen\",\"Europe\\/Ljubljana\":\"(UTC+01:00) Ljubljana\",\"Europe\\/Madrid\":\"(UTC+01:00) Madrid\",\"Europe\\/Paris\":\"(UTC+01:00) Paris\",\"Europe\\/Prague\":\"(UTC+01:00) Prague\",\"Europe\\/Rome\":\"(UTC+01:00) Rome\",\"Europe\\/Sarajevo\":\"(UTC+01:00) Sarajevo\",\"Europe\\/Skopje\":\"(UTC+01:00) Skopje\",\"Europe\\/Stockholm\":\"(UTC+01:00) Stockholm\",\"Europe\\/Vienna\":\"(UTC+01:00) Vienna\",\"Europe\\/Warsaw\":\"(UTC+01:00) Warsaw\",\"Africa\\/Lagos\":\"(UTC+01:00) West Central Africa\",\"Europe\\/Zagreb\":\"(UTC+01:00) Zagreb\",\"Europe\\/Athens\":\"(UTC+02:00) Athens\",\"Europe\\/Bucharest\":\"(UTC+02:00) Bucharest\",\"Africa\\/Cairo\":\"(UTC+02:00) Cairo\",\"Africa\\/Harare\":\"(UTC+02:00) Harare\",\"Europe\\/Helsinki\":\"(UTC+02:00) Helsinki\",\"Europe\\/Istanbul\":\"(UTC+02:00) Istanbul\",\"Asia\\/Jerusalem\":\"(UTC+02:00) Jerusalem\",\"Europe\\/Kyiv\":\"(UTC+02:00) Kyiv\",\"Africa\\/Johannesburg\":\"(UTC+02:00) Pretoria\",\"Europe\\/Riga\":\"(UTC+02:00) Riga\",\"Europe\\/Sofia\":\"(UTC+02:00) Sofia\",\"Europe\\/Tallinn\":\"(UTC+02:00) Tallinn\",\"Europe\\/Vilnius\":\"(UTC+02:00) Vilnius\",\"Asia\\/Baghdad\":\"(UTC+03:00) Baghdad\",\"Asia\\/Kuwait\":\"(UTC+03:00) Kuwait\",\"Europe\\/Minsk\":\"(UTC+03:00) Minsk\",\"Africa\\/Nairobi\":\"(UTC+03:00) Nairobi\",\"Asia\\/Riyadh\":\"(UTC+03:00) Riyadh\",\"Europe\\/Volgograd\":\"(UTC+03:00) Volgograd\",\"Asia\\/Tehran\":\"(UTC+03:30) Tehran\",\"Asia\\/Abu_Dhabi\":\"(UTC+04:00) Abu Dhabi\",\"Asia\\/Baku\":\"(UTC+04:00) Baku\",\"Europe\\/Moscow\":\"(UTC+04:00) Moscow\",\"Asia\\/Muscat\":\"(UTC+04:00) Muscat\",\"Europe\\/St_Petersburg\":\"(UTC+04:00) St. Petersburg\",\"Asia\\/Tbilisi\":\"(UTC+04:00) Tbilisi\",\"Asia\\/Yerevan\":\"(UTC+04:00) Yerevan\",\"Asia\\/Kabul\":\"(UTC+04:30) Kabul\",\"Asia\\/Islamabad\":\"(UTC+05:00) Islamabad\",\"Asia\\/Karachi\":\"(UTC+05:00) Karachi\",\"Asia\\/Tashkent\":\"(UTC+05:00) Tashkent\",\"Asia\\/Calcutta\":\"(UTC+05:30) Chennai\",\"Asia\\/Kolkata\":\"(UTC+05:30) Kolkata\",\"Asia\\/Mumbai\":\"(UTC+05:30) Mumbai\",\"Asia\\/New_Delhi\":\"(UTC+05:30) New Delhi\",\"Asia\\/Sri_Jayawardenepura\":\"(UTC+05:30) Sri Jayawardenepura\",\"Asia\\/Katmandu\":\"(UTC+05:45) Kathmandu\",\"Asia\\/Almaty\":\"(UTC+06:00) Almaty\",\"Asia\\/Astana\":\"(UTC+06:00) Astana\",\"Asia\\/Dhaka\":\"(UTC+06:00) Dhaka\",\"Asia\\/Yekaterinburg\":\"(UTC+06:00) Ekaterinburg\",\"Asia\\/Rangoon\":\"(UTC+06:30) Rangoon\",\"Asia\\/Bangkok\":\"(UTC+07:00) Bangkok\",\"Asia\\/Hanoi\":\"(UTC+07:00) Hanoi\",\"Asia\\/Jakarta\":\"(UTC+07:00) Jakarta\",\"Asia\\/Novosibirsk\":\"(UTC+07:00) Novosibirsk\",\"Asia\\/Beijing\":\"(UTC+08:00) Beijing\",\"Asia\\/Chongqing\":\"(UTC+08:00) Chongqing\",\"Asia\\/Hong_Kong\":\"(UTC+08:00) Hong Kong\",\"Asia\\/Krasnoyarsk\":\"(UTC+08:00) Krasnoyarsk\",\"Asia\\/Kuala_Lumpur\":\"(UTC+08:00) Kuala Lumpur\",\"Australia\\/Perth\":\"(UTC+08:00) Perth\",\"Asia\\/Singapore\":\"(UTC+08:00) Singapore\",\"Asia\\/Taipei\":\"(UTC+08:00) Taipei\",\"Asia\\/Ulan_Bator\":\"(UTC+08:00) Ulaan Bataar\",\"Asia\\/Urumqi\":\"(UTC+08:00) Urumqi\",\"Asia\\/Irkutsk\":\"(UTC+09:00) Irkutsk\",\"Asia\\/Osaka\":\"(UTC+09:00) Osaka\",\"Asia\\/Sapporo\":\"(UTC+09:00) Sapporo\",\"Asia\\/Seoul\":\"(UTC+09:00) Seoul\",\"Asia\\/Tokyo\":\"(UTC+09:00) Tokyo\",\"Australia\\/Adelaide\":\"(UTC+09:30) Adelaide\",\"Australia\\/Darwin\":\"(UTC+09:30) Darwin\",\"Australia\\/Brisbane\":\"(UTC+10:00) Brisbane\",\"Australia\\/Canberra\":\"(UTC+10:00) Canberra\",\"Pacific\\/Guam\":\"(UTC+10:00) Guam\",\"Australia\\/Hobart\":\"(UTC+10:00) Hobart\",\"Australia\\/Melbourne\":\"(UTC+10:00) Melbourne\",\"Pacific\\/Port_Moresby\":\"(UTC+10:00) Port Moresby\",\"Australia\\/Sydney\":\"(UTC+10:00) Sydney\",\"Asia\\/Yakutsk\":\"(UTC+10:00) Yakutsk\",\"Asia\\/Vladivostok\":\"(UTC+11:00) Vladivostok\",\"Pacific\\/Auckland\":\"(UTC+12:00) Auckland\",\"Pacific\\/Fiji\":\"(UTC+12:00) Fiji\",\"Pacific\\/Kwajalein\":\"(UTC+12:00) International Date Line West\",\"Asia\\/Kamchatka\":\"(UTC+12:00) Kamchatka\",\"Asia\\/Magadan\":\"(UTC+12:00) Magadan\",\"Pacific\\/Marshall_Is\":\"(UTC+12:00) Marshall Is.\",\"Asia\\/New_Caledonia\":\"(UTC+12:00) New Caledonia\",\"Asia\\/Solomon_Is\":\"(UTC+12:00) Solomon Is.\",\"Pacific\\/Wellington\":\"(UTC+12:00) Wellington\",\"Pacific\\/Tongatapu\":\"(UTC+13:00) Nuku\'alofa\"},\"placeholder\":\"Choose a timezone...\"}',1,NULL,1,0,0,0,11,'half',NULL,NULL,NULL),
	(146,'directus_users','locale','string','language','{\"limit\":true}',1,NULL,0,0,0,0,12,'half',NULL,NULL,NULL),
	(147,'directus_users','avatar','file','file',NULL,1,NULL,0,0,0,0,13,'full',NULL,NULL,NULL),
	(148,'directus_users','theme','string','radio-buttons','{\"format\":true,\"choices\":{\"auto\":\"Auto\",\"light\":\"Light\",\"dark\":\"Dark\"}}',1,NULL,0,0,0,0,14,'full',NULL,NULL,NULL),
	(149,'directus_users','2fa_secret','string','2fa-secret',NULL,1,NULL,0,1,0,0,15,'full',NULL,NULL,NULL),
	(150,'directus_users','locale_options','json','json',NULL,1,NULL,0,0,1,1,16,'full',NULL,NULL,NULL),
	(151,'directus_users','token','string','text-input',NULL,1,NULL,0,0,1,1,17,'full',NULL,NULL,NULL),
	(152,'directus_users','last_access_on','datetime','datetime',NULL,1,NULL,0,1,1,0,18,'full',NULL,NULL,NULL),
	(153,'directus_users','last_page','string','text-input',NULL,1,NULL,0,1,1,1,19,'full',NULL,NULL,NULL),
	(154,'directus_users','external_id','string','text-input',NULL,1,NULL,0,1,1,1,NULL,'full',NULL,NULL,NULL),
	(155,'directus_users','password_reset_token','string','text-input',NULL,1,NULL,0,1,1,0,NULL,'full',NULL,NULL,NULL),
	(156,'directus_user_sessions','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(157,'directus_user_sessions','user','user','user',NULL,0,NULL,1,0,0,0,NULL,'full',NULL,NULL,NULL),
	(158,'directus_user_sessions','token_type','string','text-input',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(159,'directus_user_sessions','token','string','text-input',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(160,'directus_user_sessions','ip_address','string','text-input',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(161,'directus_user_sessions','user_agent','string','text-input',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(162,'directus_user_sessions','created_on','datetime','datetime',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(163,'directus_user_sessions','token_expired_at','datetime','datetime',NULL,0,NULL,0,0,0,0,NULL,'full',NULL,NULL,NULL),
	(164,'directus_webhooks','id','integer','primary-key',NULL,1,NULL,1,0,1,0,NULL,'full',NULL,NULL,NULL),
	(165,'directus_webhooks','status','status','status','{\"status_mapping\":{\"active\":{\"name\":\"Active\",\"value\":\"active\",\"text_color\":\"white\",\"background_color\":\"green\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true},\"inactive\":{\"name\":\"Inactive\",\"value\":\"inactive\",\"text_color\":\"white\",\"background_color\":\"blue-grey\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false}}}',1,NULL,0,0,0,0,1,'full',NULL,NULL,NULL),
	(166,'directus_webhooks','http_action','string','dropdown','{\"choices\":{\"get\":\"GET\",\"post\":\"POST\"}}',1,NULL,1,0,0,0,2,'half-space',NULL,NULL,NULL),
	(167,'directus_webhooks','url','string','text-input','{\"placeholder\":\"https:\\/\\/example.com\",\"iconRight\":\"link\"}',1,NULL,1,0,0,0,3,'full',NULL,'',NULL),
	(168,'directus_webhooks','collection','string','collections',NULL,1,NULL,1,0,0,0,4,'half',NULL,'',NULL),
	(169,'directus_webhooks','directus_action','string','dropdown','{\"choices\":{\"item.create:after\":\"Create\",\"item.update:after\":\"Update\",\"item.delete:after\":\"Delete\"}}',1,NULL,1,0,0,0,5,'half',NULL,'',NULL),
	(170,'directus_webhooks','info','alias','divider','{\"style\":\"medium\",\"title\":\"How Webhooks Work\",\"hr\":true,\"margin\":false,\"description\":\"When the selected action occurs for the selected collection, Directus will send an HTTP request to the above URL.\"}',1,NULL,0,0,0,1,6,'full',NULL,NULL,NULL),
	(183,'unity_scenes','id','integer','primary-key',NULL,0,NULL,0,0,1,1,2,'full',NULL,NULL,NULL),
	(184,'unity_scenes','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,3,'full',NULL,'','[]'),
	(185,'unity_scenes','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(186,'unity_scenes','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,5,'full',NULL,NULL,NULL),
	(189,'unity_scenes','scene_id','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,9,'half',NULL,'Link to the underlying Unity Scene. Do not change once set up.','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Unity Scene Id\"}]'),
	(212,'maps','id','integer','primary-key',NULL,0,NULL,0,0,1,1,2,'full',NULL,NULL,NULL),
	(213,'maps','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,3,'full',NULL,'','[]'),
	(214,'maps','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(215,'maps','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,5,'full',NULL,NULL,NULL),
	(216,'maps','unity_scenes','o2m','many-to-many','{\"allow_create\":true,\"allow_select\":true,\"fields\":\"scene_name\"}',0,NULL,0,0,0,0,12,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Category\"}]'),
	(240,'info_modal_translations','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(241,'info_modal_translations','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,1,1,0,'full',NULL,'','[]'),
	(242,'info_modal_translations','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(244,'info_modal_translations','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,1,1,NULL,'full',NULL,'','[]'),
	(250,'info_panel_translations','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(251,'info_panel_translations','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,NULL,NULL),
	(252,'info_panel_translations','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(254,'info_panel_translations','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,2,'full',NULL,'','[]'),
	(269,'info_panel_translations','description','string','textarea','{\"rows\":8,\"serif\":false}',0,NULL,0,0,0,0,3,'full',NULL,NULL,'[]'),
	(270,'info_panel_translations','benefits','json','repeater','{\"placeholder\":\"New Item...\",\"createItemText\":\"Create Item\",\"limit\":null,\"structure\":\"array\",\"fields\":[{\"newItem\":true,\"field\":\"benefit\",\"width\":\"half\",\"interface\":\"text-input\",\"type\":\"string\",\"options\":[]}],\"structure_key\":\"benefit\",\"duplicable\":true,\"template\":\"{{benefit}}\"}',0,NULL,0,0,0,0,4,'full',NULL,'','[]'),
	(271,'info_panel_translations','cta_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,5,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Link Text\"}]'),
	(272,'info_panel_translations','cta_action','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,10,'full',NULL,'The Google Analytics name under which clicking on this link will be reported ','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Analytics Identifier\"}]'),
	(273,'info_panel_translations','cta_link','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,6,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Link\"}]'),
	(274,'info_modal_translations','infographic','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,NULL,'full',NULL,'','[]'),
	(328,'maps','unity_json','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"application\\/json\"}',0,NULL,0,0,0,1,15,'half',NULL,'','[]'),
	(329,'maps','unity_wasm_code','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,1,16,'half',NULL,'','[]'),
	(330,'maps','unity_loader','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,1,18,'half',NULL,'','[]'),
	(331,'maps','unity_wasm_framework','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,1,17,'half',NULL,'','[]'),
	(341,'maps','map_name','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,6,'full',NULL,'Choose the name of your webtwin (internal use only). This will not be displayed to the end user.','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"WebTwin Identifier\"}]'),
	(353,'maps','unity_configuration','alias','divider','{\"style\":\"large\",\"title\":\"Category Configuration\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,1,11,'full',NULL,NULL,'[]'),
	(359,'maps','uid','slug','slug','{\"placeholder\":\"A unique label...\",\"onlyOnCreate\":false,\"forceLowercase\":true}',0,NULL,0,0,0,0,9,'half',NULL,'the map be published on https://uid.clientname.web-twin.com','[]'),
	(360,'sponsors','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(361,'sponsors','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,2,'full',NULL,'','[]'),
	(362,'sponsors','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,3,'full',NULL,NULL,NULL),
	(363,'sponsors','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(364,'sponsors','logo','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpg,image\\/png\"}',0,NULL,0,0,0,0,6,'full',NULL,'','[]'),
	(365,'sponsors','link','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,7,'full',NULL,NULL,'[]'),
	(373,'sponsors','name','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,5,'full',NULL,'','[{\"newItem\":true,\"translation\":\"Indentifier\"}]'),
	(374,'cta','id','integer','primary-key',NULL,0,NULL,0,0,1,1,2,'full',NULL,NULL,NULL),
	(375,'cta','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,7,'full',NULL,'','[]'),
	(376,'cta','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,3,'full',NULL,NULL,NULL),
	(377,'cta','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(378,'cta','cta_type','string','conditional-fields','{\"placeholder\":\"Choose an option...\",\"formatting\":true,\"choices\":{\"product_panel\":[\"info_panel\"],\"media-video\":[\"height\",\"video_modal\",\"width\"],\"media-picture\":[\"height\",\"info_modal\",\"width\"],\"Category\":[\"unity_scene\"],\"Web_Link\":[\"link_url\"],\"product_panels\":[\"topic_panels\"]}}',0,NULL,0,0,0,0,9,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"CTA Actions\"}]'),
	(381,'cta','top','integer','slider','{\"localized\":true,\"monospace\":false,\"minimum\":\"0\",\"maximum\":\"100\",\"step\":\"1\",\"unit\":\"%\"}',0,NULL,0,0,0,0,20,'half',NULL,'','[]'),
	(382,'cta','left','integer','slider','{\"localized\":true,\"monospace\":false,\"minimum\":\"0\",\"maximum\":\"100\",\"step\":\"1\",\"unit\":\"%\"}',0,NULL,0,0,0,0,21,'half',NULL,'','[]'),
	(383,'cta','width','integer','slider','{\"localized\":true,\"monospace\":false,\"minimum\":0,\"maximum\":100,\"step\":\"1\",\"unit\":\"%\"}',0,NULL,0,0,0,0,22,'half',NULL,'the width of the hit are in percent (1-100)','[]'),
	(384,'cta','height','integer','slider','{\"localized\":true,\"monospace\":false,\"minimum\":0,\"maximum\":100,\"step\":\"1\",\"unit\":\"%\"}',0,NULL,0,0,0,0,23,'half',NULL,'the heigh of the hit are in percent (1-100)','[]'),
	(394,'cta','info_panel','m2o','many-to-one','{\"placeholder\":\"Select one\",\"threshold\":20,\"template\":\"{{title}}\"}',0,NULL,0,0,0,0,11,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Product Panel\"}]'),
	(395,'cta','video_modal','m2o','many-to-one','{\"placeholder\":\"Select one\",\"threshold\":20,\"template\":\"{{title}}\"}',0,NULL,0,0,0,0,12,'full',NULL,'','[]'),
	(396,'cta','info_modal','m2o','many-to-one','{\"placeholder\":\"Select one\",\"threshold\":20,\"template\":\"{{title}}\"}',0,NULL,0,0,0,0,13,'full',NULL,'','[]'),
	(397,'map_ctas','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(398,'map_ctas','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(399,'map_ctas','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(400,'map_ctas','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(401,'map_ctas','map','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(402,'map_ctas','cta','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(405,'unity_scenes','scene_url','slug','slug','{\"placeholder\":\"A unique label...\",\"onlyOnCreate\":false,\"forceLowercase\":true,\"mirroredField\":\"label\"}',0,NULL,0,0,0,0,7,'half',NULL,'The URL on which this category will be displayed','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Category URL\"}]'),
	(409,'info_panel_sponsors','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(410,'info_panel_sponsors','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(411,'info_panel_sponsors','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(413,'info_panel_sponsors','info_panel','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(414,'info_panel_sponsors','sponsor','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(416,'maps','unity_data','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,0,19,'full',NULL,NULL,'[]'),
	(419,'scene_ctas','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(420,'scene_ctas','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(421,'scene_ctas','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(422,'scene_ctas','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(423,'scene_ctas','scene','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(424,'scene_ctas','cta','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(426,'unity_scenes','scene_name','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,6,'half-left',NULL,'An identifier for this category. This WILL be displayed in the Navigation bar','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Navigation Identifier\"}]'),
	(427,'cta','link_url','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false,\"placeholder\":\"http:\\/\\/mywebsite.com\"}',0,'',0,0,0,1,10,'full',NULL,'the url of the site you want to link starting with http:// or https://','[]'),
	(429,'unity_scenes','is_landing_scene','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,8,'half',NULL,'','[]'),
	(430,'map_scenes','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(431,'map_scenes','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(432,'map_scenes','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(433,'map_scenes','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(434,'map_scenes','map','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(435,'map_scenes','scene','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(447,'info_panels','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(448,'info_panels','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,2,'full',NULL,'','[]'),
	(449,'info_panels','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,3,'full',NULL,NULL,NULL),
	(450,'info_panels','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(451,'info_panel_translations','info_panel','integer','primary-key','{\"monospace\":true}',0,NULL,0,0,1,1,7,'full',NULL,NULL,'[]'),
	(452,'info_panels','translations','translation','translation','{\"languages\":{\"en\":\"English\",\"es\":\"Spanish\",\"de\":\"German\",\"fr\":\"French\",\"pt\":\"Portuguese\",\"zh\":\"Chinese\",\"ru\":\"Russian\"},\"languageField\":\"language\"}',0,NULL,0,0,0,1,6,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Product Panel Configuration\"}]'),
	(453,'info_panels','sponsors','o2m','many-to-many','{\"allow_create\":true,\"allow_select\":true,\"fields\":\"name\"}',0,NULL,0,0,0,0,9,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Suppliers\"}]'),
	(454,'info_panel_translations','language','string','language','{\"limit\":true}',0,NULL,0,0,1,1,8,'full',NULL,'','[]'),
	(455,'info_panels','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,5,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Identifier\"}]'),
	(456,'video_modals','id','integer','primary-key','[]',0,NULL,1,0,1,1,1,'full',NULL,'','[]'),
	(457,'video_modals','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,3,'full',NULL,'','[]'),
	(458,'video_modals','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(459,'video_modals','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,5,'full',NULL,NULL,NULL),
	(460,'video_modal_translations','video_modal','integer','primary-key','{\"monospace\":true}',0,NULL,0,0,1,1,5,'full',NULL,NULL,'[]'),
	(461,'video_modal_translations','language','string','language','{\"limit\":true}',0,NULL,0,0,1,1,2,'full',NULL,'','[]'),
	(466,'video_modal_translations','title','string','text-input','[]',0,NULL,0,0,1,1,3,'full',NULL,'This will be used by search engine and displayed to visually impaired user in lieu of the video.','[]'),
	(467,'video_modal_translations','video','integer','numeric','[]',0,NULL,0,0,1,1,4,'full',NULL,'','[]'),
	(471,'video_modals','translations','translation','translation','{\"languages\":{\"en\":\"English\",\"es\":\"Spanish\",\"de\":\"German\",\"fr\":\"French\",\"pt\":\"Portuguese\",\"zh\":\"Chinese\",\"ru\":\"Russian\"},\"languageField\":\"language\"}',0,NULL,0,0,0,1,7,'full',NULL,NULL,'[]'),
	(472,'video_modal_translations','id','integer','primary-key','[]',0,NULL,1,0,1,1,1,'full',NULL,'','[]'),
	(473,'video_modals','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,1,0,0,0,6,'full',NULL,'A unique name to identify the video in the CMS. This will not be displayed to the user','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Identifier\"}]'),
	(474,'info_modals','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(475,'info_modals','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,2,'full',NULL,'','[]'),
	(476,'info_modals','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(477,'info_modals','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,5,'full',NULL,NULL,NULL),
	(478,'info_modal_translations','info_modal','integer','primary-key','{\"monospace\":true}',0,NULL,0,0,1,1,NULL,'full',NULL,NULL,'[]'),
	(479,'info_modal_translations','language','string','language','{\"limit\":false}',0,NULL,0,0,1,1,NULL,'full',NULL,'','[]'),
	(480,'info_modals','translations','translation','translation','{\"languageField\":\"language\",\"languages\":{\"en\":\"English\",\"es\":\"Spanish\",\"de\":\"German\",\"fr\":\"French\",\"pt\":\"Portuguese\",\"zh\":\"Chinese\",\"ru\":\"Russian\"}}',0,NULL,0,0,0,1,6,'full',NULL,NULL,'[]'),
	(481,'info_modals','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,1,0,0,0,3,'full',NULL,'A useful name for this picture for use in the CMS only. This will not be displayed to the end user.','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Identifier\"}]'),
	(503,'map_translations','cta_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,6,'half',NULL,'','[]'),
	(504,'map_translations','cta_url','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,7,'half',NULL,'','[]'),
	(506,'map_translations','facebook','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,12,'half',NULL,'','[]'),
	(507,'map_translations','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(509,'map_translations','linked_in','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,16,'half',NULL,'','[]'),
	(512,'map_translations','loading_screen_content','string','textarea','{\"rows\":8,\"serif\":false}',0,NULL,0,0,0,1,10,'full',NULL,'','[]'),
	(513,'map_translations','loading_screen_title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,9,'full',NULL,'','[]'),
	(516,'map_translations','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,2,'full',NULL,NULL,NULL),
	(517,'map_translations','page_title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,4,'half',NULL,'','[]'),
	(518,'map_translations','primary_cta','alias','divider','{\"style\":\"large\",\"title\":\"Primary CTA\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,1,5,'full',NULL,NULL,'[]'),
	(520,'map_translations','show_facebook','boolean','switch','{\"labelOn\":\"\",\"labelOff\":\"\",\"checkbox\":false}',0,NULL,0,0,0,1,13,'half',NULL,'','[]'),
	(521,'map_translations','show_linkedin','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,1,17,'half',NULL,'','[]'),
	(524,'map_translations','show_twitter','boolean','switch','{\"labelOn\":\"\",\"checkbox\":false}',0,NULL,0,0,0,1,15,'half',NULL,'','[]'),
	(526,'map_translations','social_media_links','alias','divider','{\"style\":\"large\",\"title\":\"Social Media Links\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,1,11,'full',NULL,NULL,'[]'),
	(529,'map_translations','strapline','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,3,'half',NULL,'located on the left hand side of the logo','[{\"newItem\":true}]'),
	(530,'map_translations','twitter','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,1,14,'half',NULL,'','[]'),
	(564,'map_translations','language','string','language','{\"limit\":true}',0,NULL,0,0,1,1,30,'full',NULL,NULL,'[]'),
	(565,'map_translations','map','integer','primary-key','{\"monospace\":true}',0,NULL,1,0,1,1,29,'full',NULL,NULL,'[]'),
	(566,'maps','translations','translation','translation','{\"languageField\":\"language\",\"languages\":{\"en\":\"English\",\"fr\":\"French\",\"nl\":\"Dutch\",\"de\":\"German\",\"it\":\"Italian\",\"sv\":\"Swedish\",\"es\":\"Spanish\"}}',0,NULL,0,0,0,1,31,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Page Configuration\"}]'),
	(567,'map_translations','unity_loading_screen','alias','divider','{\"style\":\"medium\",\"title\":\"Loading Screen \",\"hr\":true,\"margin\":true,\"description\":\"Configure the text that will appear on the loading screem\"}',0,NULL,0,0,0,0,8,'full',NULL,NULL,'[]'),
	(572,'cta','cta_style','string','conditional-fields','{\"choices\":{\"Button\":[\"button_appearance\",\"button_name_and_description\",\"left\",\"name_and_description\",\"top\",\"translations\"],\"Overlay\":[\"cta_background_image\",\"height\",\"left\",\"show_hit_area\",\"skew\",\"top\",\"width\"]},\"placeholder\":\"Choose an option...\",\"formatting\":true}',0,NULL,0,0,0,0,17,'full',NULL,'To configure on Overlay, please contact your Immersionn admin. ','[]'),
	(578,'cta_translations','id','integer','primary-key',NULL,0,NULL,0,0,1,1,7,'full',NULL,NULL,NULL),
	(579,'cta_translations','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,1,1,1,'full',NULL,'','[]'),
	(580,'cta_translations','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,2,'full',NULL,NULL,NULL),
	(581,'cta_translations','cta_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,4,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"CTA Name\"}]'),
	(582,'cta_translations','cta_description','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,5,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"CTA Description\"}]'),
	(583,'cta_translations','cta','integer','primary-key','{\"monospace\":true}',0,NULL,0,0,1,1,6,'full',NULL,'','[]'),
	(584,'cta','translations','translation','translation','{\"languageField\":\"language\",\"languages\":{\"en\":\"English\",\"es\":\"Spanish\",\"de\":\"German\",\"fr\":\"French\",\"pt\":\"Portuguese\",\"zh\":\"Chinese\",\"ru\":\"Russian\"}}',0,NULL,0,0,0,0,27,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Language\"}]'),
	(585,'cta_translations','language','string','language','{\"limit\":false}',0,NULL,0,0,1,1,8,'full',NULL,'','[]'),
	(586,'cta','admin_title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,1,0,0,0,5,'full',NULL,'A useful name for the CTA for use in the CMS only. This will not be displayed to the end user','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Identifier\"}]'),
	(596,'maps','allow_fullscreen','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,27,'half',NULL,'','[]'),
	(598,'maps','meta_description','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,38,'full',NULL,'Configure how your links will be displayed in twitter, facebook and others','[]'),
	(600,'maps','open_graph_image','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,0,39,'full',NULL,NULL,'[]'),
	(601,'maps','twitter_image','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,0,0,40,'full',NULL,NULL,'[]'),
	(602,'maps','meta_title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,37,'full',NULL,NULL,'[]'),
	(613,'map_translations','contact_link','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,1,1,20,'full',NULL,'','[]'),
	(615,'map_translations','external_link','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,1,1,25,'full',NULL,'','[]'),
	(619,'map_translations','contact_link_url','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,21,'full',NULL,NULL,'[]'),
	(620,'map_translations','contact_link_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,22,'full',NULL,NULL,'[]'),
	(621,'map_translations','external_link_url','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,26,'full',NULL,NULL,'[]'),
	(622,'map_translations','external_link_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,27,'full',NULL,NULL,'[]'),
	(623,'map_translations','contact_link_icon','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,1,1,23,'full',NULL,'','[]'),
	(624,'map_translations','external_link_icon','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,1,1,28,'full',NULL,'','[]'),
	(626,'map_themes','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(627,'map_themes','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,2,'full',NULL,'','[]'),
	(628,'map_themes','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,3,'full',NULL,NULL,NULL),
	(629,'map_themes','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,4,'full',NULL,NULL,NULL),
	(630,'map_themes','logo','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,14,'half-left',NULL,'Your brand logo (SVG Format)','[]'),
	(631,'map_themes','brand_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,28,'half',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Progress Bar Colour\"}]'),
	(632,'map_themes','header_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,15,'half',NULL,'','[]'),
	(633,'map_themes','background_image','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,9,'half',NULL,'','[]'),
	(634,'map_themes','loading_screen_background_image','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,25,'full',NULL,'','[]'),
	(635,'map_themes','loading_screen_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,26,'half',NULL,'','[]'),
	(636,'map_themes','show_loading_screen_gradient','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,27,'half',NULL,'Display a gradient of the selected colour in the loading screen','[]'),
	(637,'map_themes','google_font_name','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,7,'full',NULL,NULL,'[]'),
	(643,'map_themes','nav_bar_logo','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,31,'half',NULL,'','[]'),
	(645,'map_themes','footer_text','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,20,'full',NULL,NULL,'[]'),
	(646,'map_themes','footer_logo','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,19,'half-left',NULL,'Your brand logo (SVG Format)','[]'),
	(647,'map_themes','footer_links','json','repeater','{\"placeholder\":\"New Item...\",\"createItemText\":\"Create Item\",\"limit\":null,\"structure\":\"array\",\"fields\":[{\"newItem\":true,\"field\":\"text\",\"width\":\"half\",\"interface\":\"text-input\",\"type\":\"string\",\"options\":[]},{\"newItem\":true,\"field\":\"link\",\"width\":\"half\",\"interface\":\"text-input\",\"type\":\"string\",\"options\":[]}]}',0,NULL,0,0,0,0,21,'full',NULL,'','[]'),
	(648,'map_themes','favicon','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,10,'half',NULL,'','[]'),
	(649,'map_themes','theme_name','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,5,'full',NULL,'A unique name for this theme. This will not be displayed to the end user','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Identifier\"}]'),
	(650,'maps','map_theme','m2o','many-to-one','{\"visible_fields\":\"theme_name\",\"placeholder\":\"Select one\",\"threshold\":20,\"template\":\"{{theme_name}}\"}',0,NULL,0,0,0,0,8,'half',NULL,'','[]'),
	(651,'map_themes','cta_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,44,'half',NULL,'','[]'),
	(652,'map_themes','cta_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,41,'half',NULL,'','[]'),
	(653,'map_themes','header_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,16,'half',NULL,'','[]'),
	(654,'cta','show_hit_area','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,25,'full',NULL,NULL,'[]'),
	(662,'maps','meta_data','alias','divider','{\"style\":\"large\",\"title\":\"Meta Data Information\",\"hr\":true,\"margin\":true,\"description\":\"Meta data defe the title, description and picture used if your site is shared on a link (whatsaspp, messenger, twitter...)\"}',0,NULL,0,0,0,0,36,'full',NULL,NULL,'[]'),
	(680,'map_themes','cta_icon_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,45,'half',NULL,'','[]'),
	(681,'map_themes','primary_cta_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,37,'half',NULL,'','[]'),
	(682,'map_themes','primary_cta_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,36,'half',NULL,'','[]'),
	(684,'map_themes','link_block_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,62,'half',NULL,'','[]'),
	(685,'map_themes','link_block_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,63,'half',NULL,'','[]'),
	(686,'map_themes','page_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,8,'full',NULL,'Set the background color of the page. If no Background Image is set, this color will show. If the Background Image is a transparent .png, this color will show beneath.','[]'),
	(687,'map_themes','map_menu_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,32,'half',NULL,'','[]'),
	(688,'map_themes','external_link_icon','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,64,'half',NULL,'','[]'),
	(689,'map_themes','contact_link_icon','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,65,'half',NULL,'','[]'),
	(690,'map_themes','cta_text_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,42,'half',NULL,'','[]'),
	(691,'unity_scenes','admin_tags','array','tags','{\"iconRight\":\"local_offer\",\"validationMessage\":\"Please enter a valid tag\",\"alphabetize\":true,\"lowercase\":true,\"wrap\":false,\"format\":false,\"sanitize\":false}',0,NULL,0,0,0,0,12,'full',NULL,NULL,'[]'),
	(695,'unity_scenes','scene_ctas','o2m','many-to-many','{\"allow_create\":true,\"allow_select\":true,\"fields\":\"admin_title,cta_type\",\"template\":\"{{admin_title}}\"}',0,NULL,0,0,0,1,10,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Call to Action\"}]'),
	(696,'cta','unity_scene','m2o','many-to-one','{\"placeholder\":\"Select one\",\"threshold\":20,\"template\":\"{{scene_name}}\",\"visible_fields\":\"scene_name\"}',0,NULL,0,0,0,0,15,'full',NULL,'The category that will be open when the user click on the CTAs','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Target Category\"}]'),
	(697,'unity_scene_sponsors','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(698,'unity_scene_sponsors','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(699,'unity_scene_sponsors','owner','owner','owner','{\"template\":\"{{first_name}} {{last_name}}\",\"display\":\"both\"}',0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(700,'unity_scene_sponsors','created_on','datetime_created','datetime-created',NULL,0,NULL,0,1,1,1,0,'full',NULL,NULL,NULL),
	(701,'unity_scene_sponsors','unity_scene','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(702,'unity_scene_sponsors','sponsor','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(703,'unity_scenes','sponsors','o2m','many-to-many','{\"allow_create\":true,\"allow_select\":true,\"fields\":\"name\",\"template\":\"{{name}}\"}',0,NULL,0,0,0,0,11,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Suppliers\"}]'),
	(704,'maps','unity_enabled','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,14,'full',NULL,'','[]'),
	(705,'unity_scenes','static_image','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,13,'full',NULL,'A static image in case the customer device does not support WebGL and Unity','[]'),
	(706,'map_themes','site_header','alias','divider','{\"style\":\"medium\",\"title\":\"General Settings - Site header\",\"description\":\"Logo, text\\/background color\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,11,'full',NULL,NULL,'[]'),
	(707,'map_themes','site_footer','alias','divider','{\"style\":\"medium\",\"title\":\"General Settings - Site footer\",\"description\":\"Configure the site footer for the map\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,18,'full',NULL,NULL,'[]'),
	(708,'map_themes','primary_cta','alias','divider','{\"style\":\"medium\",\"title\":\"Primary CTA\",\"description\":\"Set background\\/text colors for the Primary CTA component\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,35,'full',NULL,NULL,'[]'),
	(712,'map_themes','link_block','alias','divider','{\"style\":\"large\",\"title\":\"Gadgets configuration (right handside of the screen)\",\"description\":\"Configure the appearance of the contact and external link icon\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,61,'full',NULL,NULL,'[]'),
	(713,'map_themes','buttons','alias','divider','{\"style\":\"medium\",\"title\":\"Configure a second style for your secondary CTAs\",\"description\":\"If you need to apply a different colours to some of your secondary CTAs, configure a secondary style. Skip if not required.\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,49,'full',NULL,NULL,'[]'),
	(714,'map_themes','general','alias','divider','{\"style\":\"large\",\"title\":\"General Theme settings\",\"description\":\"Logo, text\\/background color, links, strapline and text. This apply to both the loading screen and the main screen\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,6,'full',NULL,NULL,'[]'),
	(715,'map_themes','map_menu','alias','divider','{\"style\":\"medium\",\"title\":\"Map Navigation\",\"description\":\"Breadcrumb nav appearance. Color and logo\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,30,'full',NULL,NULL,'[]'),
	(716,'map_themes','loading_screen','alias','divider','{\"style\":\"large\",\"title\":\"Loading screen\",\"description\":\"Configure what appears in place of your map while your webtwin is loading. \",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,24,'full',NULL,NULL,'[]'),
	(717,'map_themes','footer_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,22,'half',NULL,'','[]'),
	(718,'map_themes','footer_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,23,'half',NULL,'','[]'),
	(720,'map_themes','cta_style','string','radio-buttons','{\"choices\":{\"square\":\"Square\",\"round\":\"Round\",\"pill\":\"Pill\"},\"format\":true}',0,NULL,0,0,0,0,34,'full',NULL,NULL,'[]'),
	(721,'map_themes','title_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,17,'full',NULL,NULL,'[]'),
	(722,'map_themes','cta_description_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,48,'full',NULL,NULL,'[]'),
	(723,'map_themes','cta_description_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,47,'full',NULL,NULL,'[]'),
	(724,'cta','postion','alias','divider','{\"style\":\"large\",\"title\":\"Style and Position\",\"hr\":true,\"margin\":true,\"description\":\"Configure the type of CTA and where it will be on the screen \"}',0,NULL,0,0,0,0,16,'full',NULL,'','[]'),
	(725,'cta','name_and_description','alias','divider','{\"style\":\"large\",\"title\":\" Name and Description\",\"description\":\"\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,26,'full',NULL,'','[]'),
	(727,'cta','cta_status','alias','divider','{\"style\":\"medium\",\"title\":\"CTA Status\",\"description\":\"Start with \\\"draft\\\" and select published when you want it to appear on the map.\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,6,'full',NULL,NULL,'[]'),
	(728,'cta_translations','name_and_description','alias','divider','{\"style\":\"medium\",\"title\":\"\",\"description\":\"Configure what will be displayed to the end user for the selected language\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,3,'full',NULL,NULL,'[]'),
	(729,'cta','gtm_uid','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,31,'full',NULL,'The unique Google Analytic name under which clicking on this link will be reported','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Google Analytics Name\"}]'),
	(730,'sponsors','gtm_uid','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false,\"placeholder\":\"The name under which clicking on this supplier will be reported in google analytics\"}',0,NULL,0,0,0,0,10,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Supplier - Google Analytics name\"}]'),
	(731,'cta','gtm_tag_type','string','dropdown','{\"choices\":{\"category\":\"Category\",\"media\":\"Media\",\"product\":\"Product\",\"link\":\"External Link\"},\"placeholder\":\"Choose an option...\",\"allow_other\":false,\"formatting\":true}',0,NULL,0,0,0,0,30,'full',NULL,'The Level at which clicking on this link will be reported ','[]'),
	(732,'maps','contact_link_gtm_uid','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false,\"placeholder\":\"The name under which a click on the contact link will appear on google analytics\"}',0,NULL,0,0,0,0,34,'full',NULL,'The name under which a click on the contact link will appear on google analytics ','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Contact Link - Google Analytics Name\"}]'),
	(733,'maps','external_link_gtm_uid','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false,\"placeholder\":\"The name under which a click on the external link will appear on google analytics\"}',0,NULL,0,0,0,0,35,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"External link - Google Analytics Name\"}]'),
	(734,'maps','primary_cta_gtm_uid','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false,\"placeholder\":\"The name under which a click on the main CTA will appear on google analytics\"}',0,NULL,0,0,0,0,33,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Primary CTA - Google Analytics Name\"}]'),
	(735,'cta','analytics_divider','alias','divider','{\"style\":\"large\",\"title\":\"Google Analytics Configuration\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,29,'full',NULL,NULL,'[]'),
	(736,'info_panel_translations','product_panel_analytics_divider','alias','divider','{\"style\":\"large\",\"title\":\"Google Analytics Configuration\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,9,'full',NULL,'Analytics configuration','[]'),
	(737,'maps','unity_files_divider','alias','divider','{\"style\":\"large\",\"title\":\"Unity Files\",\"description\":\"Upload the Unity Build here\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,13,'full',NULL,NULL,'[]'),
	(738,'maps','analytics_divider','alias','divider','{\"style\":\"large\",\"title\":\"Google Analytics Configuration\",\"description\":\"\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,32,'full',NULL,NULL,'[]'),
	(739,'map_translations','gadget_divider','alias','divider','{\"style\":\"large\",\"title\":\"Widgets Configuration\",\"description\":\"Configure the additional widgets appearing on the right handside of your twin\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,18,'full',NULL,NULL,'[]'),
	(740,'maps','main_configuration_divider','alias','divider','{\"style\":\"large\",\"title\":\"Page Configuration\",\"description\":\"Configure your languages and the different text elements of your twin\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,30,'full',NULL,NULL,'[]'),
	(741,'map_themes','mainmap_them_divider','alias','divider','{\"style\":\"large\",\"title\":\"Navigation bar, CTAs and webtwin icons Configuration\",\"description\":\"Configure navigation menu, CTAs and their background, social media icons & colour\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,29,'full',NULL,NULL,'[]'),
	(742,'map_themes','cta_styling_divider','alias','divider','{\"style\":\"medium\",\"title\":\"Style your Call To Action (CTA)\",\"hr\":true,\"margin\":false,\"description\":\"Pick up the colours of your CTAs and the description\"}',0,NULL,0,0,0,0,33,'full',NULL,NULL,'[]'),
	(744,'maps','show_link_block','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,1,1,28,'half',NULL,'','[]'),
	(745,'maps','show_site_header','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,21,'half',NULL,'','[]'),
	(746,'maps','show_site_footer','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,29,'half',NULL,'','[]'),
	(747,'maps','show_strapline','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,22,'half',NULL,'Strapline is located in your header at the left of your logo',NULL),
	(748,'maps','show_page_title','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,23,'half',NULL,'','[]'),
	(749,'maps','show_primary_cta','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,25,'half',NULL,'','[]'),
	(750,'video_modal_translations','video_upload','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"video\\/mp4,video\\/quicktime\"}',0,NULL,0,0,0,0,8,'full',NULL,'','[]'),
	(751,'video_modal_translations','video_embed','string','code','{\"language\":\"text\\/plain\",\"lineNumber\":true,\"template\":\"\\n\"}',0,NULL,0,0,1,1,10,'full',NULL,'','[]'),
	(752,'video_modal_translations','video_type','string','conditional-fields','{\"choices\":{\"upload\":[\"video_upload\"],\"embed\":[\"video_embed\",\"video_embeded_divider\",\"youtube_id\"]},\"placeholder\":\"Choose an option...\",\"formatting\":true}',0,NULL,0,0,0,0,7,'full',NULL,'','[]'),
	(753,'map_themes','language_bar_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,12,'full',NULL,NULL,'[]'),
	(754,'map_themes','language_bar_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,13,'full',NULL,NULL,'[]'),
	(755,'maps','default_language_code','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,7,'half',NULL,'','[]'),
	(756,'maps','show_contact_link','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,24,'half',NULL,NULL,'[]'),
	(757,'maps','show_external_link','boolean','switch','{\"checkbox\":false}',0,NULL,0,0,0,0,26,'half',NULL,NULL,'[]'),
	(758,'maps','asset_url','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,10,'full',NULL,'The full URL starting with https:// where the map will be published','[]'),
	(759,'maps','about_this_page','alias','divider','{\"style\":\"large\",\"title\":\"About this page\",\"hr\":true,\"margin\":true,\"description\":\"Apply a theme to your map, configure title and main call to action, choose which elements will appear on your map and configure your meta data!\"}',0,NULL,0,0,0,0,1,'full',NULL,NULL,'[]'),
	(761,'maps','appear_divider','alias','divider','{\"style\":\"large\",\"title\":\"Configure what will appear on your map\",\"description\":\"Toggle on or off the different element of you map\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,20,'full',NULL,NULL,'[]'),
	(762,'map_translations','contact_divider','alias','divider','{\"style\":\"medium\",\"title\":\"Contacts\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,19,'full',NULL,NULL,'[]'),
	(763,'map_translations','divider_external','alias','divider','{\"style\":\"medium\",\"title\":\"External Link\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,24,'full',NULL,NULL,'[]'),
	(765,'cta','description','alias','divider','{\"style\":\"large\",\"title\":\"About this page\",\"description\":\"Create your Call to actions using the component you have defined. Modify the position of the CTAs and choose how to report on them in google analytics\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,1,'full',NULL,NULL,'[]'),
	(766,'unity_scenes','description','alias','divider','{\"style\":\"large\",\"title\":\"About this page\",\"description\":\"Assign the call to actions and suppliers to the right categories\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,1,'full',NULL,NULL,'[]'),
	(767,'video_modal_translations','video_embeded_divider','alias','divider','{\"style\":\"medium\",\"title\":\"Embed a youtube video or livestream in your twin\",\"description\":\"Embed a youtube or Livestream video.  Play the you tube video. The URL will look like this https:\\/\\/www.youtube.com\\/watch?v=XYZs1d3T. The Youtube ID is XYZs1d3T\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,9,'full',NULL,'','[]'),
	(768,'video_modals','divider_status','alias','divider','{\"style\":\"large\",\"title\":\"Status\",\"description\":\"Pulished Videos will be made visible. mark your video as draft if you do not want it to appear.\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,2,'full',NULL,NULL,'[]'),
	(770,'map_themes','alternate_cta_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,55,'half',NULL,'',NULL),
	(771,'map_themes','alternate_cta_icon_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,56,'half',NULL,'','[]'),
	(772,'map_themes','alternate_cta_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,52,'half',NULL,'','[]'),
	(773,'map_themes','alternate_cta_text_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,53,'half',NULL,'','[]'),
	(774,'map_themes','alternate_cta_description_background_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,59,'full',NULL,NULL,'[]'),
	(775,'map_themes','alternate_cta_description_text_color','string','color','{\"format\":\"hex\",\"palette\":[\"#E91E63\",\"#F44336\",\"#FF9800\",\"#FFC107\",\"#FFEB3B\",\"#CDDC39\",\"#4CAF50\",\"#00BCD4\",\"#2196F3\",\"#3F51B5\",\"#9C27B0\",\"#607D8B\"],\"paletteOnly\":false}',0,NULL,0,0,0,0,58,'full',NULL,NULL,'[]'),
	(777,'map_themes','cta_text_size','string','dropdown','{\"choices\":{\"normal\":\"Default\",\"large\":\"Large\"},\"placeholder\":\"Choose an option...\",\"allow_other\":false,\"formatting\":true}',0,NULL,0,0,0,0,40,'full',NULL,NULL,'[]'),
	(780,'cta','cta_background_image','file','file','{\"crop\":true,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false,\"accept\":\"image\\/jpeg, image\\/png, image\\/svg+xml, image\\/gif\"}',0,NULL,0,0,0,0,18,'full',NULL,'','[]'),
	(781,'cta','skew','integer','slider','{\"localized\":true,\"monospace\":false,\"minimum\":\"-50\",\"maximum\":\"50\",\"step\":\"0.1\",\"unit\":\"deg\"}',0,NULL,0,0,0,0,24,'full',NULL,'Overlay CTA skew (degrees)','[]'),
	(782,'cta','cta_appearance','string','dropdown','{\"format\":false,\"placeholder\":\"Choose an option...\",\"allow_other\":false,\"formatting\":true,\"choices\":{\"default\":\"Default\",\"alternate\":\"Alternate\"}}',0,NULL,0,0,0,0,19,'half-left',NULL,'Select alternate if you want to apply a 2ndary CTA style that you have defined in your theme.','[]'),
	(783,'map_themes','media_icon_video','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,1,1,66,'full',NULL,'Upload the icon that will appear on the top of a video panel','[]'),
	(784,'map_themes','media_icon_picture','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,1,1,67,'full',NULL,'Upload what will appear on the top of a media picture panel','[]'),
	(785,'map_themes','media_icon_panel','file','file','{\"crop\":false,\"viewType\":\"cards\",\"viewOptions\":{\"title\":\"title\",\"subtitle\":\"type\",\"content\":\"description\",\"src\":\"data\"},\"viewQuery\":[],\"filters\":[],\"allowDelete\":false}',0,NULL,0,0,1,1,68,'full',NULL,'','[]'),
	(786,'map_themes','cta_icon_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose the colour of the + button and its background\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,43,'full',NULL,NULL,'[]'),
	(787,'map_themes','cta_text_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose the text and background colour of your CTA\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,39,'full',NULL,NULL,'[]'),
	(788,'map_themes','cta_description_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose how the \\\"on hover\\\" description of your CTA will appear\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,46,'full',NULL,NULL,'[]'),
	(789,'map_themes','secondary_cta_divider','alias','divider','{\"style\":\"medium\",\"title\":\"Configure your secondary CTAs \",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,38,'full',NULL,NULL,'[]'),
	(790,'map_themes','cta_2nd_icon_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose a 2nd style for the colour of the + button and its background\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,54,'full',NULL,NULL,'[]'),
	(791,'map_themes','cta_2nd_description_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose a second style for how the \\\"on hover\\\" description of your CTA will appear\",\"hr\":true,\"margin\":true}',0,NULL,0,0,0,0,57,'full',NULL,NULL,'[]'),
	(792,'map_themes','cta_2nd_text_divider','alias','divider','{\"style\":\"small\",\"title\":\"Choose a 2nd style for the text and background colour of your CTA\",\"hr\":true,\"margin\":false}',0,NULL,0,0,0,0,51,'full',NULL,NULL,'[]'),
	(793,'map_themes','is_2nd_cta_style_required','string','conditional-fields','{\"choices\":{\"yes\":[\"alternate_cta_background_color\",\"alternate_cta_description_background_color\",\"alternate_cta_description_text\",\"alternate_cta_description_text_color\",\"alternate_cta_icon_color\",\"alternate_cta_text_background\",\"alternate_cta_text_background_color\",\"alternate_cta_text_color\",\"cta_2nd_description_divider\",\"cta_2nd_icon_divider\",\"cta_2nd_text_divider\"],\"no\":[\"divider_style\"]},\"placeholder\":\"\",\"formatting\":true}',0,NULL,0,0,0,0,50,'full',NULL,'','[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"Do you need to style some of your CTAs differently?\"}]'),
	(794,'map_themes','divider_style','alias','divider','{\"style\":\"small\",\"title\":\"\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,60,'full',NULL,NULL,'[]'),
	(795,'cta','cta_to_category','o2m','many-to-many','{\"fields\":\"scene_name, admin_tags\",\"allow_create\":false,\"allow_select\":true,\"template\":\"{{scene_name}}\"}',0,NULL,0,0,0,1,28,'full',NULL,NULL,'[{\"newItem\":true,\"locale\":\"en-US\",\"translation\":\"CTA Placement\"}]'),
	(796,'video_modal_translations','youtube_id','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,'The unique Youtube ID for this video.','[]'),
	(797,'cta','cta_type_divider','alias','divider','{\"style\":\"medium\",\"title\":\"Choose which actions your CTA will do\",\"description\":\"Your CTAs can either open a new category, launch a media (videos or pictures), open a product panel or go to an external web link\",\"hr\":false,\"margin\":false}',0,NULL,0,0,0,0,8,'full',NULL,NULL,'[]'),
	(800,'unity_scenes','maps','o2m','many-to-many','{\"allow_create\":false,\"allow_select\":false,\"fields\":\"map_name\",\"template\":\"{{map_name}}\"}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(801,'topics','id','integer','primary-key',NULL,0,NULL,0,0,1,1,1,'full',NULL,NULL,NULL),
	(802,'topics','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,2,'full',NULL,'','[]'),
	(803,'topics','description','string','text-input','{\"rows\":\"4\",\"serif\":false,\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,4,'full',NULL,'','[]'),
	(804,'topics','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,3,'full',NULL,NULL,'[]'),
	(805,'supplier_topics','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(806,'supplier_topics','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,NULL,'[]'),
	(807,'supplier_topics','supplier','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(808,'supplier_topics','topic','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(809,'sponsors','topics','o2m','many-to-many','{\"fields\":\"title,description\",\"template\":\"{{title}} - {{description}}\",\"allow_create\":true,\"allow_select\":true}',0,NULL,0,0,0,0,8,'full',NULL,NULL,'[]'),
	(810,'supplier_industries','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(811,'supplier_industries','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,NULL,NULL),
	(813,'supplier_industries','supplier','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(814,'supplier_industries','industry','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(815,'industries','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(816,'industries','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,'','[]'),
	(817,'industries','title','string','text-input','{\"trim\":true,\"showCharacterCount\":true,\"formatValue\":false,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(818,'sponsors','industries','o2m','many-to-many','{\"fields\":\"title\",\"template\":\"{{title}}\",\"allow_create\":true,\"allow_select\":true}',0,NULL,0,0,0,0,9,'full',NULL,NULL,'[]'),
	(819,'info_panels','supplier_topic','m2o','many-to-one','{\"template\":\"{{title}} - {{description}}\",\"visible_fields\":\"title,description\",\"placeholder\":\"Select one\",\"threshold\":20}',0,NULL,0,0,0,0,10,'full',NULL,'','[]'),
	(820,'info_panels','supplier_industry','m2o','many-to-one','{\"template\":\"{{title}}\",\"visible_fields\":\"title\",\"placeholder\":\"Select one\",\"threshold\":20}',0,NULL,0,0,0,0,11,'full',NULL,NULL,'[]'),
	(821,'info_panels','layout','string','dropdown','{\"choices\":{\"default\":\"Default\",\"large\":\"Large\"},\"placeholder\":\"Choose an option...\",\"allow_other\":false,\"formatting\":true}',0,NULL,0,0,0,0,8,'full',NULL,NULL,'[]'),
	(822,'cta_topic_panels','id','integer','primary-key',NULL,0,NULL,0,0,1,1,0,'full',NULL,NULL,NULL),
	(823,'cta_topic_panels','status','status','status','{\"status_mapping\":{\"published\":{\"name\":\"Published\",\"value\":\"published\",\"text_color\":\"white\",\"background_color\":\"accent\",\"browse_subdued\":false,\"browse_badge\":true,\"soft_delete\":false,\"published\":true,\"required_fields\":true},\"draft\":{\"name\":\"Draft\",\"value\":\"draft\",\"text_color\":\"white\",\"background_color\":\"blue-grey-100\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":false,\"published\":false,\"required_fields\":false},\"deleted\":{\"name\":\"Deleted\",\"value\":\"deleted\",\"text_color\":\"white\",\"background_color\":\"red\",\"browse_subdued\":true,\"browse_badge\":true,\"soft_delete\":true,\"published\":false,\"required_fields\":false}}}',0,NULL,1,0,0,0,0,'full',NULL,NULL,NULL),
	(824,'cta_topic_panels','cta','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(825,'cta_topic_panels','panel','integer','numeric','{\"localized\":true,\"monospace\":false}',0,NULL,0,0,0,0,NULL,'full',NULL,NULL,'[]'),
	(826,'cta','topic_panels','o2m','many-to-many','{\"fields\":\"title\",\"template\":\"{{title}}\",\"allow_create\":true,\"allow_select\":true}',0,NULL,0,0,0,0,14,'full',NULL,NULL,'[]'),
	(827,'info_panels','supplier_config','string','conditional-fields','{\"choices\":{\"manual\":[\"layout\",\"sponsors\"],\"related\":[\"layout\",\"supplier_industry\",\"supplier_topic\"]},\"placeholder\":\"Choose an option...\",\"formatting\":true}',0,NULL,0,0,0,0,7,'full',NULL,'','[]');

/*!40000 ALTER TABLE `directus_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table directus_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_permissions`;

CREATE TABLE `directus_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `collection` varchar(64) NOT NULL,
  `role` int(11) unsigned NOT NULL,
  `status` varchar(64) DEFAULT NULL,
  `create` varchar(16) DEFAULT 'none',
  `read` varchar(16) DEFAULT 'none',
  `update` varchar(16) DEFAULT 'none',
  `delete` varchar(16) DEFAULT 'none',
  `comment` varchar(8) DEFAULT 'none',
  `explain` varchar(8) DEFAULT 'none',
  `read_field_blacklist` varchar(1000) DEFAULT NULL,
  `write_field_blacklist` varchar(1000) DEFAULT NULL,
  `status_blacklist` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_permissions` WRITE;
/*!40000 ALTER TABLE `directus_permissions` DISABLE KEYS */;

INSERT INTO `directus_permissions` (`id`, `collection`, `role`, `status`, `create`, `read`, `update`, `delete`, `comment`, `explain`, `read_field_blacklist`, `write_field_blacklist`, `status_blacklist`)
VALUES
	(4,'directus_files',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(5,'complex_maps',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(6,'complex_maps',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(7,'complex_maps',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(8,'info_modals',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(9,'info_modals',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(10,'info_modals',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(11,'info_panels',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(12,'info_panels',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(13,'info_panels',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(17,'unity_scenes',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(18,'unity_scenes',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(19,'unity_scenes',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(31,'directus_activity',3,NULL,'full','mine','none','none','update','none',NULL,NULL,NULL),
	(32,'directus_collection_presets',3,NULL,'full','full','mine','mine','none','none',NULL,NULL,NULL),
	(33,'directus_collections',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(34,'directus_fields',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(35,'directus_files',3,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(36,'directus_folders',3,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(37,'directus_permissions',3,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(38,'directus_relations',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(39,'directus_revisions',3,NULL,'full','full','none','none','none','none',NULL,NULL,NULL),
	(40,'directus_roles',3,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(41,'directus_settings',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(42,'directus_users',3,'active','none','full','mine','mine','none','none',NULL,NULL,NULL),
	(43,'directus_users',3,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(44,'directus_users',3,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(45,'directus_users',3,'invited','none','none','none','none','none','none',NULL,NULL,NULL),
	(46,'directus_users',3,'suspended','none','none','none','none','none','none',NULL,NULL,NULL),
	(47,'cta',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(48,'cta',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(49,'cta',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(50,'map_ctas',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(51,'map_ctas',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(52,'map_ctas',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(56,'sponsors',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(57,'sponsors',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(58,'sponsors',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(59,'info_panel_sponsors',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(60,'info_panel_sponsors',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(61,'info_panel_sponsors',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(62,'scene_ctas',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(63,'scene_ctas',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(64,'scene_ctas',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(65,'map_scenes',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(66,'map_scenes',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(67,'map_scenes',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(68,'info_panel',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(69,'info_panel',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(70,'info_panel',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(71,'info_panel_translations',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(72,'video_modals',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(73,'maps',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(74,'maps',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(75,'maps',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(76,'info_panel',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(77,'video_modal_translations',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(78,'video_modals',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(79,'video_modals',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(80,'video_modals',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(81,'map_translations',2,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(82,'info_modal_translations',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(83,'info_modal_translations',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(84,'info_modal_translations',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(85,'cta_translations',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(86,'cta_translations',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(87,'cta_translations',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(88,'map_themes',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(89,'map_themes',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(90,'map_themes',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(91,'unity_scene_sponsors',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(92,'unity_scene_sponsors',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(93,'unity_scene_sponsors',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(94,'cta',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(95,'cta',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(96,'cta',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(97,'cta_translations',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(98,'cta_translations',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(99,'cta_translations',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(100,'info_modal_translations',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(101,'info_modal_translations',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(102,'info_modal_translations',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(103,'info_modals',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(104,'info_modals',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(105,'info_modals',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(106,'info_panel_sponsors',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(107,'info_panel_sponsors',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(108,'info_panel_sponsors',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(109,'info_panel_translations',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(110,'info_panels',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(111,'info_panels',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(112,'info_panels',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(113,'map_ctas',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(114,'map_ctas',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(115,'map_ctas',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(116,'map_scenes',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(117,'map_scenes',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(118,'map_scenes',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(119,'map_themes',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(120,'map_themes',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(121,'map_themes',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(122,'map_translations',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(123,'maps',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(124,'maps',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(125,'maps',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(126,'scene_ctas',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(127,'scene_ctas',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(128,'scene_ctas',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(129,'sponsors',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(130,'sponsors',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(131,'sponsors',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(132,'unity_scene_sponsors',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(133,'unity_scene_sponsors',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(134,'unity_scene_sponsors',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(135,'unity_scenes',3,'published','none','full','none','none','none','none','','',NULL),
	(136,'unity_scenes',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(137,'unity_scenes',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(138,'video_modal_translations',3,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(139,'video_modals',3,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(140,'video_modals',3,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(141,'video_modals',3,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(142,'directus_activity',4,NULL,'full','mine','none','none','update','none',NULL,NULL,NULL),
	(143,'directus_collection_presets',4,NULL,'full','full','mine','mine','none','none',NULL,NULL,NULL),
	(144,'directus_collections',4,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(145,'directus_fields',4,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(146,'directus_files',4,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(147,'directus_folders',4,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(148,'directus_permissions',4,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(149,'directus_relations',4,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(150,'directus_revisions',4,NULL,'full','full','none','none','none','none',NULL,NULL,NULL),
	(151,'directus_roles',4,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(152,'directus_settings',4,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(153,'directus_users',4,'active','none','full','mine','mine','none','none',NULL,NULL,NULL),
	(154,'directus_users',4,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(155,'directus_users',4,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(156,'directus_users',4,'invited','none','none','none','none','none','none',NULL,NULL,NULL),
	(157,'directus_users',4,'suspended','none','none','none','none','none','none',NULL,NULL,NULL),
	(158,'maps',4,'published','full','full','full','full','full','none',NULL,NULL,NULL),
	(159,'maps',4,'draft','full','full','full','full','full','none',NULL,NULL,NULL),
	(160,'maps',4,'deleted','full','full','full','full','full','none',NULL,NULL,NULL),
	(161,'unity_scenes',4,'published','full','full','full','full','full','none','','',''),
	(162,'unity_scenes',4,'draft','full','full','full','full','full','none','','',''),
	(163,'unity_scenes',4,'deleted','full','full','full','full','full','none','','',''),
	(164,'directus_activity',5,NULL,'full','mine','none','none','update','none',NULL,NULL,NULL),
	(165,'directus_collection_presets',5,NULL,'full','full','mine','mine','none','none',NULL,NULL,NULL),
	(166,'directus_collections',5,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(167,'directus_fields',5,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(168,'directus_files',5,NULL,'full','full','full','full','none','none','embed','embed',NULL),
	(169,'directus_folders',5,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(170,'directus_permissions',5,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(171,'directus_relations',5,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(172,'directus_revisions',5,NULL,'full','full','none','none','none','none',NULL,NULL,NULL),
	(173,'directus_roles',5,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(174,'directus_settings',5,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(175,'directus_users',5,'active','none','full','mine','mine','none','none',NULL,NULL,NULL),
	(176,'directus_users',5,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(177,'directus_users',5,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(178,'directus_users',5,'invited','none','none','none','none','none','none',NULL,NULL,NULL),
	(179,'directus_users',5,'suspended','none','none','none','none','none','none',NULL,NULL,NULL),
	(180,'cta',5,'published','none','full','full','none','full','none','skew,height,width,show_hit_area,left,top,cta_style,cta_type_divider,analytics_divider,cta_status,postion,cta_appearance,cta_background_image,gtm_tag_type,gtm_uid,cta_to_category','skew,width,height,show_hit_area,top,left,cta_type_divider,cta_style,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,analytics_divider,cta_to_category',''),
	(181,'cta',5,'draft','none','full','full','none','full','none','width,height,skew,show_hit_area,left,top,cta_type_divider,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,analytics_divider,cta_style,cta_to_category','width,height,skew,show_hit_area,left,top,cta_appearance,cta_type_divider,gtm_tag_type,gtm_uid,cta_background_image,cta_style,analytics_divider,cta_status,postion,cta_to_category',''),
	(182,'cta',5,'deleted','none','full','full','none','full','none','skew,height,width,show_hit_area,cta_style,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,analytics_divider,cta_type_divider,left,top,cta_to_category','width,height,skew,show_hit_area,top,left,cta_style,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,analytics_divider,cta_type_divider,cta_to_category',''),
	(183,'cta_translations',5,'published','full','full','full','full','full','none','','',''),
	(184,'cta_translations',5,'draft','full','full','full','full','full','none','','',''),
	(185,'cta_translations',5,'deleted','full','full','full','full','full','none','','',''),
	(186,'info_modal_translations',5,'published','full','full','full','full','full','none','','',''),
	(187,'info_modal_translations',5,'draft','full','full','full','full','full','none','','',''),
	(188,'info_modal_translations',5,'deleted','full','full','full','full','full','none','','',''),
	(189,'info_modals',5,'published','full','full','full','full','full','none','','',''),
	(190,'info_modals',5,'draft','full','full','full','full','full','none','','',''),
	(191,'info_modals',5,'deleted','full','full','full','full','full','none','','',''),
	(192,'info_panel_sponsors',5,'published','full','full','full','full','full','none','','',''),
	(193,'info_panel_sponsors',5,'draft','full','full','full','full','full','none','','',''),
	(194,'info_panel_sponsors',5,'deleted','full','full','full','full','full','none','','',''),
	(195,'info_panel_translations',5,NULL,'full','full','full','full','full','none','','',''),
	(196,'info_panels',5,'published','full','full','full','full','full','none','','',''),
	(197,'info_panels',5,'draft','full','full','full','full','full','none','','',''),
	(198,'info_panels',5,'deleted','full','full','full','full','full','none','','',''),
	(199,'map_ctas',5,'published','full','full','full','full','full','none','','',''),
	(200,'map_ctas',5,'draft','full','full','full','full','full','none','','',''),
	(201,'map_ctas',5,'deleted','full','full','full','full','full','none','','',''),
	(202,'map_themes',5,'published','full','full','full','full','full','none','','',''),
	(203,'map_themes',5,'draft','full','full','full','full','full','none','','',''),
	(204,'map_themes',5,'deleted','full','full','full','full','full','none','','',''),
	(205,'maps',5,'published','none','full','full','full','full','none','unity_wasm_code,unity_json,unity_loader,unity_wasm_framework,initial_scene_id,unity_data,unity_configuration,unity_files_divider,unity_scenes,uid,allow_fullscreen,unity_enabled','unity_json,unity_wasm_code,unity_loader,unity_wasm_framework,initial_scene_id,unity_configuration,unity_files_divider,unity_data,unity_enabled,unity_scenes,uid,asset_url,allow_fullscreen',''),
	(206,'maps',5,'draft','none','full','full','full','full','none','unity_json,unity_wasm_code,unity_loader,unity_wasm_framework,unity_data,unity_scenes,unity_configuration','unity_wasm_code,unity_loader,unity_wasm_framework,unity_json,unity_data,unity_scenes,unity_configuration',''),
	(207,'maps',5,'deleted','none','full','full','full','full','none','unity_json,unity_wasm_code,unity_loader,unity_wasm_framework,unity_data','unity_enabled,unity_json,unity_wasm_code,unity_loader,unity_wasm_framework,initial_scene_id,unity_scenes',''),
	(208,'map_translations',5,NULL,'full','full','full','full','full','none','','',''),
	(209,'scene_ctas',5,'published','full','full','full','full','full','none','','',''),
	(210,'scene_ctas',5,'draft','full','full','full','full','full','none','','',''),
	(211,'scene_ctas',5,'deleted','full','full','full','full','full','none','','',''),
	(212,'sponsors',5,'published','full','full','full','full','full','none','topics,industries,gtm_uid','topics,industries,gtm_uid',''),
	(213,'sponsors',5,'draft','full','full','full','full','full','none','gtm_uid,topics,industries','topics,industries,gtm_uid',''),
	(214,'sponsors',5,'deleted','full','full','full','full','full','none','gtm_uid,topics,industries','gtm_uid,topics,industries',''),
	(215,'unity_scene_sponsors',5,'published','full','full','full','full','full','none','','',''),
	(216,'unity_scene_sponsors',5,'draft','full','full','full','full','full','none','','',''),
	(217,'unity_scene_sponsors',5,'deleted','full','full','full','full','full','none','','',''),
	(218,'unity_scenes',5,'published','none','full','full','none','full','none','scene_id,is_landing_scene','scene_id,is_landing_scene',''),
	(219,'unity_scenes',5,'draft','none','full','full','none','full','none','','scene_id,is_landing_scene',''),
	(220,'unity_scenes',5,'deleted','none','full','full','none','full','none','','is_landing_scene,scene_id',''),
	(221,'video_modal_translations',5,NULL,'full','full','full','full','full','none','','',''),
	(222,'video_modals',5,'published','full','full','full','none','full','none','','',''),
	(223,'video_modals',5,'draft','full','full','full','none','full','none','','',''),
	(224,'video_modals',5,'deleted','none','none','none','none','none','none','','',''),
	(225,'map_scenes',5,'published','none','full','none','none','full','none','','',''),
	(226,'map_scenes',5,'draft','none','full','none','none','full','none','','',''),
	(227,'map_scenes',5,'deleted','none','full','none','none','full','none','','',''),
	(228,'cta',5,'$create','none','none','none','none','none','none','width,height,skew,show_hit_area,cta_style,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,cta_type_divider,cta_to_category,analytics_divider,left,top','width,height,skew,show_hit_area,top,left,cta_style,gtm_uid,gtm_tag_type,cta_background_image,cta_appearance,postion,cta_status,cta_to_category,cta_type_divider,analytics_divider',NULL),
	(229,'directus_activity',6,NULL,'full','mine','none','none','update','none',NULL,NULL,NULL),
	(230,'directus_collection_presets',6,NULL,'full','full','mine','mine','none','none',NULL,NULL,NULL),
	(231,'directus_collections',6,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(232,'directus_fields',6,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(233,'directus_files',6,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(234,'directus_folders',6,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(235,'directus_permissions',6,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(236,'directus_relations',6,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(237,'directus_revisions',6,NULL,'full','full','none','none','none','none',NULL,NULL,NULL),
	(238,'directus_roles',6,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(239,'directus_settings',6,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(240,'directus_users',6,'active','none','full','mine','mine','none','none',NULL,NULL,NULL),
	(241,'directus_users',6,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(242,'directus_users',6,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(243,'directus_users',6,'invited','none','none','none','none','none','none',NULL,NULL,NULL),
	(244,'directus_users',6,'suspended','none','none','none','none','none','none',NULL,NULL,NULL),
	(245,'cta',6,'published','full','full','full','full','full','none','','',''),
	(246,'cta',6,'draft','full','full','full','full','full','none','','',''),
	(247,'cta',6,'deleted','full','full','full','full','full','none','','',''),
	(248,'cta_translations',6,'published','full','full','full','full','full','none','','',''),
	(249,'cta_translations',6,'draft','full','full','full','full','full','none','','',''),
	(250,'cta_translations',6,'deleted','full','full','full','full','full','none','','',''),
	(251,'info_modal_translations',6,'published','full','full','full','full','full','none','','',''),
	(252,'info_modal_translations',6,'draft','full','full','full','full','full','none','','',''),
	(253,'info_modal_translations',6,'deleted','full','full','full','full','full','none','','',''),
	(254,'info_modals',6,'published','full','full','full','full','full','none','','',''),
	(255,'info_modals',6,'draft','full','full','full','full','full','none','','',''),
	(256,'info_modals',6,'deleted','full','full','full','full','full','none','','',''),
	(257,'info_panel_sponsors',6,'published','full','full','full','full','full','none','','',''),
	(258,'info_panel_sponsors',6,'draft','full','full','full','full','full','none','','',''),
	(259,'info_panel_sponsors',6,'deleted','full','full','full','full','full','none','','',''),
	(260,'info_panel_translations',6,NULL,'full','full','full','full','full','none','','',''),
	(261,'info_panels',6,'published','full','full','full','full','full','none','','',''),
	(262,'info_panels',6,'draft','full','full','full','full','full','none','','',''),
	(263,'info_panels',6,'deleted','full','full','full','full','full','none','','',''),
	(264,'map_ctas',6,'published','full','full','full','full','full','none','','',''),
	(265,'map_ctas',6,'draft','full','full','full','full','full','none','','',''),
	(266,'map_ctas',6,'deleted','full','full','full','full','full','none','','',''),
	(267,'map_scenes',6,'published','full','full','full','full','full','none','','',''),
	(268,'map_scenes',6,'draft','full','full','full','full','full','none','','',''),
	(269,'map_scenes',6,'deleted','full','full','full','full','full','none','','',''),
	(270,'map_themes',6,'published','full','full','full','full','full','none','','',''),
	(271,'map_themes',6,'draft','full','full','full','full','full','none','','',''),
	(272,'map_themes',6,'deleted','full','full','full','full','full','none','','',''),
	(273,'map_translations',6,NULL,'full','full','full','full','full','none','','',''),
	(274,'maps',6,'published','full','full','full','full','full','none','','',''),
	(275,'maps',6,'draft','full','full','full','full','full','none','','',''),
	(276,'maps',6,'deleted','full','full','full','full','full','none','','',''),
	(277,'scene_ctas',6,'published','full','full','full','full','full','none','','',''),
	(278,'scene_ctas',6,'draft','full','full','full','full','full','none','','',''),
	(279,'scene_ctas',6,'deleted','full','full','full','full','full','none','','',''),
	(280,'sponsors',6,'published','full','full','full','full','full','none','','',''),
	(281,'sponsors',6,'draft','full','full','full','full','full','none','','',''),
	(282,'sponsors',6,'deleted','full','full','full','full','full','none','','',''),
	(283,'unity_scene_sponsors',6,'published','full','full','full','full','full','none','','',''),
	(284,'unity_scene_sponsors',6,'draft','full','full','full','full','full','none','','',''),
	(285,'unity_scene_sponsors',6,'deleted','full','full','full','full','full','none','','',''),
	(286,'unity_scenes',6,'published','full','full','full','full','full','none','','',''),
	(287,'unity_scenes',6,'draft','full','full','full','full','full','none','','',''),
	(288,'unity_scenes',6,'deleted','full','full','full','full','full','none','','',''),
	(289,'video_modal_translations',6,NULL,'full','full','full','full','full','none','','',''),
	(290,'video_modals',6,'published','full','full','full','full','full','none','','',''),
	(291,'video_modals',6,'draft','full','full','full','full','full','none','','',''),
	(292,'video_modals',6,'deleted','full','full','full','full','full','none','','',''),
	(293,'industries',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(294,'industries',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(295,'industries',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(296,'cta_topic_panels',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(297,'cta_topic_panels',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(298,'cta_topic_panels',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(299,'supplier_industries',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(300,'supplier_industries',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(301,'supplier_industries',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(302,'supplier_topics',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(303,'supplier_topics',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(304,'supplier_topics',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(305,'topics',2,'published','none','full','none','none','none','none',NULL,NULL,NULL),
	(306,'topics',2,'draft','none','full','none','none','none','none',NULL,NULL,NULL),
	(307,'topics',2,'deleted','none','full','none','none','none','none',NULL,NULL,NULL),
	(308,'supplier_industries',6,'published','full','full','full','full','full','none','','',''),
	(309,'supplier_industries',6,'draft','full','full','full','full','full','none','','',''),
	(310,'supplier_industries',6,'deleted','full','full','full','full','full','none','','',''),
	(311,'supplier_topics',6,'published','full','full','full','full','full','none','','',''),
	(312,'supplier_topics',6,'draft','full','full','full','full','full','none','','',''),
	(313,'supplier_topics',6,'deleted','full','full','full','full','full','none','','',''),
	(314,'topics',6,'published','full','full','full','full','full','none','','',''),
	(315,'topics',6,'draft','full','full','full','full','full','none','','',''),
	(316,'topics',6,'deleted','full','full','full','full','full','none','','',''),
	(317,'industries',6,'published','full','full','full','full','full','none','','',''),
	(318,'industries',6,'draft','full','full','full','full','full','none','','',''),
	(319,'industries',6,'deleted','full','full','full','full','full','none','','',''),
	(320,'cta_topic_panels',6,'published','full','full','full','full','full','none','','',''),
	(321,'cta_topic_panels',6,'draft','full','full','full','full','full','none','','',''),
	(322,'cta_topic_panels',6,'deleted','full','full','full','full','full','none','','',''),
	(323,'directus_activity',7,NULL,'full','mine','none','none','update','none',NULL,NULL,NULL),
	(324,'directus_collection_presets',7,NULL,'full','full','mine','mine','none','none',NULL,NULL,NULL),
	(325,'directus_collections',7,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(326,'directus_fields',7,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(327,'directus_files',7,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(328,'directus_folders',7,NULL,'full','full','full','full','none','none',NULL,NULL,NULL),
	(329,'directus_permissions',7,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(330,'directus_relations',7,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(331,'directus_revisions',7,NULL,'full','full','none','none','none','none',NULL,NULL,NULL),
	(332,'directus_roles',7,NULL,'none','mine','none','none','none','none',NULL,NULL,NULL),
	(333,'directus_settings',7,NULL,'none','full','none','none','none','none',NULL,NULL,NULL),
	(334,'directus_users',7,'active','none','full','mine','mine','none','none',NULL,NULL,NULL),
	(335,'directus_users',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(336,'directus_users',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(337,'directus_users',7,'invited','none','none','none','none','none','none',NULL,NULL,NULL),
	(338,'directus_users',7,'suspended','none','none','none','none','none','none',NULL,NULL,NULL),
	(339,'cta',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(340,'cta',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(341,'cta',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(342,'cta_topic_panels',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(343,'cta_topic_panels',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(344,'cta_topic_panels',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(345,'cta_translations',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(346,'cta_translations',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(347,'cta_translations',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(348,'industries',7,'published','full','full','none','none','none','none',NULL,NULL,NULL),
	(349,'industries',7,'draft','full','full','none','none','none','none',NULL,NULL,NULL),
	(350,'industries',7,'deleted','full','full','none','none','none','none',NULL,NULL,NULL),
	(351,'info_modals',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(352,'info_modals',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(353,'info_modals',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(354,'info_modal_translations',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(355,'info_modal_translations',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(356,'info_modal_translations',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(357,'info_panels',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(358,'info_panels',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(359,'info_panels',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(360,'info_panel_sponsors',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(361,'info_panel_sponsors',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(362,'info_panel_sponsors',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(363,'info_panel_translations',7,NULL,'none','none','none','none','none','none',NULL,NULL,NULL),
	(364,'maps',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(365,'maps',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(366,'maps',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(367,'map_ctas',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(368,'map_ctas',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(369,'map_ctas',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(370,'map_scenes',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(371,'map_scenes',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(372,'map_scenes',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(373,'map_themes',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(374,'map_themes',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(375,'map_themes',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(376,'map_translations',7,NULL,'none','none','none','none','none','none',NULL,NULL,NULL),
	(377,'scene_ctas',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(378,'scene_ctas',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(379,'scene_ctas',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(380,'sponsors',7,'published','full','full','mine','mine','none','none',NULL,NULL,NULL),
	(381,'sponsors',7,'draft','full','full','mine','mine','none','none',NULL,NULL,NULL),
	(382,'sponsors',7,'deleted','full','full','mine','mine','none','none',NULL,NULL,NULL),
	(383,'supplier_industries',7,'published','full','full','full','full','full','none','','',''),
	(384,'supplier_industries',7,'draft','full','full','full','full','full','none','','',''),
	(385,'supplier_industries',7,'deleted','full','full','full','full','full','none','','',''),
	(386,'supplier_topics',7,'published','full','full','full','full','full','none','','',''),
	(387,'supplier_topics',7,'draft','full','full','full','full','full','none','','',''),
	(388,'supplier_topics',7,'deleted','full','full','full','full','full','none','','',''),
	(389,'topics',7,'published','full','full','none','none','none','none',NULL,NULL,NULL),
	(390,'topics',7,'draft','full','full','none','none','none','none',NULL,NULL,NULL),
	(391,'topics',7,'deleted','full','full','none','none','none','none',NULL,NULL,NULL),
	(392,'unity_scenes',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(393,'unity_scenes',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(394,'unity_scenes',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(395,'unity_scene_sponsors',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(396,'unity_scene_sponsors',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(397,'unity_scene_sponsors',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(398,'video_modals',7,'published','none','none','none','none','none','none',NULL,NULL,NULL),
	(399,'video_modals',7,'draft','none','none','none','none','none','none',NULL,NULL,NULL),
	(400,'video_modals',7,'deleted','none','none','none','none','none','none',NULL,NULL,NULL),
	(401,'video_modal_translations',7,NULL,'none','none','none','none','none','none',NULL,NULL,NULL);

/*!40000 ALTER TABLE `directus_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table directus_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_relations`;

CREATE TABLE `directus_relations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `collection_many` varchar(64) NOT NULL,
  `field_many` varchar(45) NOT NULL,
  `collection_one` varchar(64) DEFAULT NULL,
  `field_one` varchar(64) DEFAULT NULL,
  `junction_field` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_relations` WRITE;
/*!40000 ALTER TABLE `directus_relations` DISABLE KEYS */;

INSERT INTO `directus_relations` (`id`, `collection_many`, `field_many`, `collection_one`, `field_one`, `junction_field`)
VALUES
	(1,'directus_activity','action_by','directus_users',NULL,NULL),
	(2,'directus_collections_presets','user','directus_users',NULL,NULL),
	(3,'directus_collections_presets','group','directus_groups',NULL,NULL),
	(4,'directus_fields','collection','directus_collections','fields',NULL),
	(5,'directus_files','uploaded_by','directus_users',NULL,NULL),
	(6,'directus_files','folder','directus_folders',NULL,NULL),
	(7,'directus_folders','parent_folder','directus_folders',NULL,NULL),
	(8,'directus_permissions','group','directus_groups',NULL,NULL),
	(9,'directus_revisions','activity','directus_activity',NULL,NULL),
	(10,'directus_users','role','directus_roles','users',NULL),
	(11,'directus_users','avatar','directus_files',NULL,NULL),
	(25,'cta','info_panel','info_panels',NULL,NULL),
	(26,'cta','video_modal','video_modals',NULL,NULL),
	(27,'cta','info_modal','info_modals',NULL,NULL),
	(38,'map_scenes','scene','unity_scenes',NULL,'map'),
	(39,'info_panel_translations','info_panel','info_panels','translations',NULL),
	(40,'info_panel_sponsors','info_panel','info_panels','sponsors','sponsor'),
	(41,'info_panel_sponsors','sponsor','sponsors',NULL,'info_panel'),
	(42,'video_modal_translations','video_modal','video_modals','translations',NULL),
	(43,'info_modal_translations','info_modal','info_modals','translations',NULL),
	(44,'map_translations','map','maps','translations',NULL),
	(45,'cta_translations','cta','cta','translations',NULL),
	(46,'maps','map_theme','map_themes',NULL,NULL),
	(47,'scene_ctas','scene','unity_scenes','scene_ctas','cta'),
	(48,'scene_ctas','cta','cta',NULL,'scene'),
	(49,'cta','unity_scene','unity_scenes',NULL,NULL),
	(50,'unity_scene_sponsors','unity_scene','unity_scenes','sponsors','sponsor'),
	(51,'unity_scene_sponsors','sponsor','sponsors',NULL,'unity_scene'),
	(52,'scene_ctas','scene','unity_scenes',NULL,'cta'),
	(53,'scene_ctas','cta','cta','cta_to_category','scene'),
	(57,'map_scenes','scene','unity_scenes','maps','map'),
	(58,'map_scenes','map','maps',NULL,'scene'),
	(59,'map_scenes','map','maps','unity_scenes','scene'),
	(60,'map_scenes','scene','unity_scenes',NULL,'map'),
	(61,'supplier_topics','supplier','sponsors','topics','topic'),
	(62,'supplier_topics','topic','topics',NULL,'supplier'),
	(63,'cta','id','cta_translations',NULL,'id'),
	(64,'cta','id','supplier_industries',NULL,'id'),
	(65,'supplier_industries','supplier','sponsors','industries','industry'),
	(66,'supplier_industries','industry','industries',NULL,'supplier'),
	(67,'info_panels','supplier_topic','topics',NULL,NULL),
	(68,'info_panels','supplier_industry','industries',NULL,NULL),
	(69,'cta_topic_panels','cta','cta','topic_panels','panel'),
	(70,'cta_topic_panels','panel','info_panels',NULL,'cta');

/*!40000 ALTER TABLE `directus_relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table directus_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `directus_roles`;

CREATE TABLE `directus_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `ip_whitelist` text,
  `external_id` varchar(255) DEFAULT NULL,
  `module_listing` text,
  `collection_listing` text,
  `enforce_2fa` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_group_name` (`name`),
  UNIQUE KEY `idx_roles_external_id` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `directus_roles` WRITE;
/*!40000 ALTER TABLE `directus_roles` DISABLE KEYS */;

INSERT INTO `directus_roles` (`id`, `name`, `description`, `ip_whitelist`, `external_id`, `module_listing`, `collection_listing`, `enforce_2fa`)
VALUES
	(1,'Administrator','Admins have access to all managed data within the system by default',NULL,NULL,NULL,NULL,0),
	(2,'Public','Controls what API data is publicly available without authenticating',NULL,NULL,NULL,NULL,0),
	(4,'Unity Developper',NULL,NULL,'24127eaa-5c6b-49e8-9564-654d75623ffc',NULL,NULL,0),
	(5,'Client',NULL,NULL,'41dad8f2-857e-44db-a267-084aef69a68c','[{\"newItem\":true,\"name\":\"Training\",\"link\":\"https:\\/\\/docs.google.com\\/document\\/d\\/1Nmyqt1kvJY65aBIM7-3phLplCHBR60LLIV9XXBNBMSY\",\"icon\":\"school\"}]',NULL,0),
	(6,'Team Member',NULL,NULL,'3024e1f0-f831-4a72-b4e4-c2368942900f','[{\"newItem\":true,\"name\":\"Sign Out\",\"link\":\"#\\/laval-virtual\\/users\\/\"}]',NULL,0),
	(7,'Supplier',NULL,NULL,'447eeebc-6176-4d19-bfe3-8e65929156ad',NULL,NULL,0);

/*!40000 ALTER TABLE `directus_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table industries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `industries`;

CREATE TABLE `industries` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table info_modal_translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info_modal_translations`;

CREATE TABLE `info_modal_translations` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `infographic` int(10) unsigned DEFAULT NULL,
  `info_modal` int(11) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table info_modals
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info_modals`;

CREATE TABLE `info_modals` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `title` varchar(200) NOT NULL COMMENT 'A useful name for this picture for use in the CMS only. This will not be displayed to the end user.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table info_panel_sponsors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info_panel_sponsors`;

CREATE TABLE `info_panel_sponsors` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `info_panel` int(11) DEFAULT NULL,
  `sponsor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table info_panel_translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info_panel_translations`;

CREATE TABLE `info_panel_translations` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `description` text,
  `benefits` text,
  `cta_text` varchar(200) DEFAULT NULL,
  `cta_action` varchar(200) DEFAULT NULL COMMENT 'The Google Analytics name under which clicking on this link will be reported ',
  `cta_link` varchar(200) DEFAULT NULL,
  `info_panel` int(11) DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table info_panels
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info_panels`;

CREATE TABLE `info_panels` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `supplier_topic` int(10) unsigned DEFAULT NULL,
  `supplier_industry` int(10) unsigned DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `supplier_config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table map_ctas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map_ctas`;

CREATE TABLE `map_ctas` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `map` int(11) DEFAULT NULL,
  `cta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table map_scenes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map_scenes`;

CREATE TABLE `map_scenes` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `map` int(11) DEFAULT NULL,
  `scene` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table map_themes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map_themes`;

CREATE TABLE `map_themes` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `logo` int(10) unsigned DEFAULT NULL COMMENT 'Your brand logo (SVG Format)',
  `brand_color` varchar(20) DEFAULT NULL,
  `header_background_color` varchar(20) DEFAULT NULL,
  `background_image` int(10) unsigned DEFAULT NULL,
  `loading_screen_background_image` int(10) unsigned DEFAULT NULL,
  `loading_screen_background_color` varchar(20) DEFAULT NULL,
  `show_loading_screen_gradient` tinyint(3) unsigned DEFAULT NULL COMMENT 'Display a gradient of the selected colour in the loading screen',
  `google_font_name` varchar(200) DEFAULT NULL,
  `nav_bar_logo` int(10) unsigned DEFAULT NULL,
  `footer_text` varchar(200) DEFAULT NULL,
  `footer_logo` int(10) unsigned DEFAULT NULL COMMENT 'Your brand logo (SVG Format)',
  `footer_links` text,
  `favicon` int(10) unsigned DEFAULT NULL,
  `theme_name` varchar(200) DEFAULT NULL COMMENT 'A uniqu name for this theme. This will n be displayed to the end user',
  `cta_background_color` varchar(20) DEFAULT NULL,
  `cta_text_color` varchar(20) DEFAULT NULL,
  `header_text_color` varchar(20) DEFAULT NULL,
  `cta_icon_color` varchar(20) DEFAULT NULL,
  `primary_cta_background_color` varchar(20) DEFAULT NULL,
  `primary_cta_text_color` varchar(20) DEFAULT NULL,
  `link_block_background_color` varchar(20) DEFAULT NULL,
  `link_block_text_color` varchar(20) DEFAULT NULL,
  `page_background_color` varchar(20) DEFAULT NULL COMMENT 'Set the background color of the page. If no Background Image is set, this color will show. If the Background Image is a transparent .png, this color will show beneath.',
  `map_menu_color` varchar(20) DEFAULT NULL,
  `external_link_icon` int(10) unsigned DEFAULT NULL,
  `contact_link_icon` int(10) unsigned DEFAULT NULL,
  `cta_text_background_color` varchar(20) DEFAULT NULL,
  `footer_background_color` varchar(20) DEFAULT NULL,
  `footer_text_color` varchar(20) DEFAULT NULL,
  `cta_style` varchar(100) DEFAULT NULL,
  `title_text_color` varchar(20) DEFAULT NULL,
  `cta_description_background_color` varchar(20) DEFAULT NULL,
  `cta_description_text_color` varchar(20) DEFAULT NULL,
  `language_bar_background_color` varchar(20) DEFAULT NULL,
  `language_bar_text_color` varchar(20) DEFAULT NULL,
  `alternate_cta_background_color` varchar(20) DEFAULT NULL,
  `alternate_cta_icon_color` varchar(20) DEFAULT NULL,
  `alternate_cta_text_color` varchar(20) DEFAULT NULL,
  `alternate_cta_text_background_color` varchar(20) DEFAULT NULL,
  `alternate_cta_description_background_color` varchar(20) DEFAULT NULL,
  `alternate_cta_description_text_color` varchar(20) DEFAULT NULL,
  `cta_text_size` varchar(100) DEFAULT NULL,
  `media_icon_video` int(10) unsigned DEFAULT NULL COMMENT 'Upload the icon that will appear on the top of a video panel',
  `media_icon_picture` int(10) unsigned DEFAULT NULL COMMENT 'Upload what will appear on the top of a media picture panel',
  `media_icon_panel` int(10) unsigned DEFAULT NULL,
  `is_2nd_cta_style_required` varchar(255) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table map_translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map_translations`;

CREATE TABLE `map_translations` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `owner` int(10) unsigned DEFAULT NULL,
  `facebook` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `linked_in` varchar(200) DEFAULT NULL,
  `loading_screen_title` varchar(200) DEFAULT NULL,
  `loading_screen_content` text,
  `strapline` varchar(200) DEFAULT NULL COMMENT 'located on the left hand side of the logo',
  `page_title` varchar(200) DEFAULT NULL,
  `cta_text` varchar(200) DEFAULT NULL,
  `cta_url` varchar(200) DEFAULT NULL,
  `show_facebook` tinyint(3) unsigned DEFAULT NULL,
  `show_twitter` tinyint(3) unsigned DEFAULT NULL,
  `show_linkedin` tinyint(3) unsigned DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  `map` int(11) NOT NULL,
  `contact_link` varchar(200) DEFAULT NULL,
  `external_link` varchar(200) DEFAULT NULL,
  `contact_link_url` varchar(200) DEFAULT NULL,
  `contact_link_text` varchar(200) DEFAULT NULL,
  `external_link_url` varchar(200) DEFAULT NULL,
  `external_link_text` varchar(200) DEFAULT NULL,
  `contact_link_icon` int(10) unsigned DEFAULT NULL,
  `external_link_icon` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table maps
# ------------------------------------------------------------

DROP TABLE IF EXISTS `maps`;

CREATE TABLE `maps` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `unity_json` int(10) unsigned DEFAULT NULL,
  `unity_wasm_code` int(10) unsigned DEFAULT NULL,
  `unity_loader` int(10) unsigned DEFAULT NULL,
  `unity_wasm_framework` int(10) unsigned DEFAULT NULL,
  `map_name` varchar(200) DEFAULT NULL COMMENT 'Choose the name of your webtwin (internal use only). This will not be displayed to the end user.',
  `uid` varchar(200) DEFAULT NULL COMMENT 'the map be published on https://uid.clientname.web-twin.com',
  `unity_data` int(10) unsigned DEFAULT NULL,
  `allow_fullscreen` tinyint(3) unsigned DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL COMMENT 'Configure how your links will be displayed in twitter, facebook and others',
  `open_graph_image` int(10) unsigned DEFAULT NULL,
  `twitter_image` int(10) unsigned DEFAULT NULL,
  `meta_title` varchar(200) DEFAULT NULL,
  `map_theme` int(10) unsigned DEFAULT NULL,
  `unity_enabled` tinyint(3) unsigned DEFAULT '1',
  `contact_link_gtm_uid` varchar(200) DEFAULT NULL COMMENT 'The name under which a click on the contact link will appear on google analytics ',
  `external_link_gtm_uid` varchar(200) DEFAULT NULL,
  `primary_cta_gtm_uid` varchar(200) DEFAULT NULL,
  `show_link_block` tinyint(3) unsigned DEFAULT NULL,
  `show_site_header` tinyint(3) unsigned DEFAULT NULL,
  `show_site_footer` tinyint(3) unsigned DEFAULT NULL,
  `show_strapline` tinyint(3) unsigned DEFAULT NULL COMMENT 'Strapline is located in your header at the left of your logo',
  `show_page_title` tinyint(3) unsigned DEFAULT NULL,
  `show_primary_cta` tinyint(3) unsigned DEFAULT NULL,
  `default_language_code` varchar(200) DEFAULT 'en',
  `show_contact_link` tinyint(3) unsigned DEFAULT NULL,
  `show_external_link` tinyint(3) unsigned DEFAULT NULL,
  `asset_url` varchar(200) DEFAULT NULL COMMENT 'The full URL starting with https:// where the map will be published',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table scene_ctas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `scene_ctas`;

CREATE TABLE `scene_ctas` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `scene` int(11) DEFAULT NULL,
  `cta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table sponsors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sponsors`;

CREATE TABLE `sponsors` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `logo` int(10) unsigned DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `gtm_uid` varchar(200) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table supplier_industries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `supplier_industries`;

CREATE TABLE `supplier_industries` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `supplier` int(11) DEFAULT NULL,
  `industry` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table supplier_topics
# ------------------------------------------------------------

DROP TABLE IF EXISTS `supplier_topics`;

CREATE TABLE `supplier_topics` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `supplier` int(11) DEFAULT NULL,
  `topic` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table topics
# ------------------------------------------------------------

DROP TABLE IF EXISTS `topics`;

CREATE TABLE `topics` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `description` varchar(2000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table unity_scene_sponsors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `unity_scene_sponsors`;

CREATE TABLE `unity_scene_sponsors` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `unity_scene` int(11) DEFAULT NULL,
  `sponsor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table unity_scenes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `unity_scenes`;

CREATE TABLE `unity_scenes` (
  `id` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `scene_id` varchar(200) DEFAULT NULL COMMENT 'Link to the underlying Unity Scene. Do not change once set up.',
  `scene_url` varchar(200) DEFAULT NULL COMMENT 'The URL on which this category will be displayed',
  `scene_name` varchar(200) DEFAULT NULL COMMENT 'An identifier for this category. This WILL be displayed in the Navigation bar',
  `is_landing_scene` tinyint(3) unsigned DEFAULT NULL,
  `admin_tags` varchar(2000) DEFAULT NULL,
  `static_image` int(10) unsigned DEFAULT NULL COMMENT 'A static image in case the customer device does not support WebGL and Unity',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table video_modal_translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `video_modal_translations`;

CREATE TABLE `video_modal_translations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL COMMENT 'This will be used by search engine and displayed to visually impaired user in lieu of the video.',
  `video` int(11) unsigned DEFAULT NULL,
  `video_modal` int(11) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  `video_upload` int(10) unsigned DEFAULT NULL,
  `video_embed` text,
  `video_type` varchar(255) DEFAULT NULL,
  `youtube_id` varchar(200) DEFAULT NULL COMMENT 'The unique Youtube ID for this video.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table video_modals
# ------------------------------------------------------------

DROP TABLE IF EXISTS `video_modals`;

CREATE TABLE `video_modals` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `owner` int(10) unsigned DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `title` varchar(200) NOT NULL COMMENT 'A unique name to identify the video in the CMS. This will not be displayed to the user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
