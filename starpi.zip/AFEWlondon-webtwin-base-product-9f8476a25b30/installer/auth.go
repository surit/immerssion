package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"strings"

	"github.com/spf13/viper"
)

type AuthUserResponse struct {
	Data struct {
		User struct {
			ID        string `json:"id"`
			FirstName string `json:"first_name"`
			LastName  string `json:"last_name"`
			Role      string `json:"role"`
			Email     string `json:"email"`
		} `json:"user"`
	} `json:"data"`
}

type AuthErrorResponse struct {
	Error AuthError `json:"error"`
}

type AuthError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	// Get auth session, if the cookie exists then redirect to homepage
	session, _ := sessionStore.Get(r, directusSessionName)
	if cookie, _ := session.Values[directusCookieKey].(string); cookie != "" {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}

	// If it's not a POST request just render the template
	loginTemplate := template.Must(template.ParseFiles("templates/login.gohtml"))
	if r.Method != http.MethodPost {
		loginTemplate.Execute(w, nil)
		return
	}

	// Otherwise get in, we're goin loggin in...
	// Build the endpoint and encode the credentials
	authenticateEndpoint := fmt.Sprintf("%s/%s/auth/authenticate", strings.TrimRight(viper.GetString("API.Endpoint"), "/"), viper.GetString("DB.Main"))
	encodedCredentials, err := json.Marshal(Credentials{
		Email:    r.FormValue("Email"),
		Password: r.FormValue("Password"),
		Mode:     "cookie",
	})
	if err != nil {
		fmt.Errorf("Couldn't encode credentials: %d", err)
	}

	// Make the authentication request
	resp, err := http.Post(authenticateEndpoint, "application/json", bytes.NewBuffer(encodedCredentials))
	if err != nil || resp.StatusCode >= 500 {
		loginTemplate.Execute(w, AuthError{
			Message: "Something went wrong.",
		})
		return
	}

	// Send user back to page if there is a client error (invalid/malformed
	// username/password)
	if resp.StatusCode >= 400 {
		errorResponse := AuthErrorResponse{}
		json.NewDecoder(resp.Body).Decode(&errorResponse)

		loginTemplate.Execute(w, errorResponse.Error)
		return
	}

	// Decode user response data
	userData := AuthUserResponse{}
	json.NewDecoder(resp.Body).Decode(&userData)

	if userData.Data.User.Role != "1" {
		loginTemplate.Execute(w, AuthError{
			Message: "You are not authorized to use this platform. Please speak to an administrator to request access.",
		})
		return
	}

	// Set the rawCookie response as a session that will be used later
	// on to set as a header on future requests
	session.Values[directusCookieKey] = resp.Header["Set-Cookie"][1]
	session.Values["user"] = userData
	session.Save(r, w)

	// Then redirect to homepage
	http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	// Get auth session and set the rawCookie value to nil, set MaxAge to -1 to
	// delete the cookie then redirect user back to login page
	session, _ := sessionStore.Get(r, directusSessionName)
	session.Options.MaxAge = -1
	session.Values[directusCookieKey] = nil

	session.Save(r, w)
	http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
}

func authorize(next http.HandlerFunc) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Get auth session
		session, _ := sessionStore.Get(r, directusSessionName)

		// If there is no cookie at all redirect to login page
		if cookie, _ := session.Values[directusCookieKey].(string); cookie == "" {
			http.Redirect(w, r, "/login", http.StatusTemporaryRedirect)
			return
		}

		next(w, r)
	})
}
