package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"net/mail"
	"strings"

	"github.com/gosimple/slug"
	"github.com/spf13/viper"
)

type IndexData struct {
	User     *AuthUserResponse
	Projects []string
	Message  string
	Error    error
}

type ProjectData struct {
	ProjectKey      string          `json:"project"`
	ProjectName     string          `json:"project_name"`
	SuperAdminToken string          `json:"super_admin_token"`
	DBHost          string          `json:"db_host"`
	DBName          string          `json:"db_name"`
	DBUser          string          `json:"db_user"`
	DBPassword      string          `json:"db_password"`
	UserEmail       string          `json:"user_email"`
	UserPassword    string          `json:"user_password"`
	Private         bool            `json:"private"`
	Storage         *StorageOptions `json:"storage"`
	Mail            *MailOptions    `json:"mail"`
	CORS            *CORSOptions    `json:"cors"`
}

type StorageOptions struct {
	Adapter   string            `json:"adapter"`
	Key       string            `json:"key"`
	Secret    string            `json:"secret"`
	Bucket    string            `json:"bucket"`
	Version   string            `json:"version"`
	Region    string            `json:"region"`
	Options   map[string]string `json:"options"`
	Root      string            `json:"root"`
	ThumbRoot string            `json:"thumb_root"`
	RootURL   string            `json:"root_url"`
}

type MailOptions struct {
	Transport  string `json:"transport"`
	Host       string `json:"host"`
	Port       string `json:"port"`
	Username   string `json:"username"`
	Password   string `json:"password"`
	Encryption string `json:"encryption"`
	From       string `json:"from"`
}

type CORSOptions struct {
	Enabled        bool     `json:"enabled"`
	Origin         []string `json:"origin"`
	Methods        []string `json:"methods"`
	Headers        []string `json:"headers"`
	ExposedHeaders []string `json:"exposed_headers"`
	MaxAge         uint     `json:"max_age"`
	Credentials    bool     `json:"credentials"`
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	// Get user data
	session, _ := sessionStore.Get(r, directusSessionName)
	user := session.Values["user"].(*AuthUserResponse)

	// Open the database
	db, err := sql.Open("mysql", viper.GetString("DB.DSN"))
	if err != nil {
		fmt.Printf("Couldn't open database: %d", err)
	}
	defer db.Close()

	// Query the database to get all existing databases
	databases, err := db.Query(`show databases`)
	if err != nil {
		fmt.Printf("Error querying database: %d", err)
	}

	// Create variables that the response will be parsed into
	var projects []string
	var project string

	// Parse the results
	for databases.Next() {
		databases.Scan(&project)
		if project != "information_schema" && project != "performance_schema" && project != "mysql" && project != "sys" {
			projects = append(projects, project)
		}
	}

	// Either get the projects or create a project depending on the method -
	// this needs a refactoring though as the form value check is a bit smelly
	if r.Method == "GET" || r.FormValue("ProjectName") == "" {
		getProjects(w, r, user, projects)
	}
	if r.Method == "POST" && r.FormValue("ProjectName") != "" {
		createProject(w, r, user, projects)
	}
}

func getProjects(w http.ResponseWriter, r *http.Request, user *AuthUserResponse, projects []string) {
	// Build data object that will be passed through to template
	indexData := &IndexData{
		user,
		projects,
		"",
		nil,
	}

	// Execute template
	indexTemplate := template.Must(template.ParseFiles("templates/index.gohtml"))
	indexTemplate.Execute(w, indexData)
}

func createProject(w http.ResponseWriter, r *http.Request, user *AuthUserResponse, projects []string) {
	indexTemplate := template.Must(template.ParseFiles("templates/index.gohtml"))

	// Generate the project name/key/db names as they all need to be formatted
	// slightly differently
	projectName := r.FormValue("ProjectName")
	projectEmail := r.FormValue("ProjectEmail")
	projectPassword := r.FormValue("ProjectPassword")
	projectTemplate := r.FormValue("ProjectTemplate")
	projectKey := slug.Make(projectName)
	projectDbName := strings.ReplaceAll(projectKey, "-", "_")

	sendValidationError := func(message string) {
		err := errors.New(message)
		indexData := &IndexData{user, projects, "", err}
		indexTemplate.Execute(w, indexData)
	}

	if projectName == "" {
		sendValidationError("Project name required")
		return
	}
	if projectEmail == "" {
		sendValidationError("Admin email address required")
		return
	}
	if _, err := mail.ParseAddress(projectEmail); err != nil {
		sendValidationError("Admin email address not valid")
		return
	}
	if projectPassword == "" {
		sendValidationError("Admin password required")
		return
	}

	// Open the database
	db, err := sql.Open("mysql", viper.GetString("DB.DSN"))
	if err != nil {
		fmt.Printf("Couldn't open database: %d", err)
	}
	defer db.Close()

	// Execute the create database query
	if _, err := db.Exec(fmt.Sprintf("create database %s", projectDbName)); err != nil {
		// Build data object that will be passed through to template
		indexData := &IndexData{user, projects, "", err}
		indexTemplate.Execute(w, indexData)

		return
	}

	// Tack the created project onto the end of the projects slice
	projects = append(projects, projectDbName)

	// Create the project in directus
	createProjectEndpoint := fmt.Sprintf("%s/server/projects", strings.TrimRight(viper.GetString("API.Endpoint"), "/"))

	// Generate the project data and marshal it to be sent as a payload to the
	// HTTP POST request
	projectData := newProjectData(projectKey, projectName, projectDbName, projectEmail, projectPassword)
	projectPayload, _ := json.Marshal(projectData)

	if _, err := Post(w, r, createProjectEndpoint, projectPayload); err != nil {
		// Build data object that will be passed through to template
		indexData := &IndexData{user, projects, "", err}

		// Execute template
		indexTemplate.Execute(w, indexData)
		return
	}

	// Now populate the database if a project template is selected
	if projectTemplate == "standard" {
		if err := populateDatabase(db, projectDbName); err != nil {
			// Build data object that will be passed through to template
			indexData := &IndexData{user, projects, "", err}

			// Execute template
			indexTemplate.Execute(w, indexData)
			return
		}
	}

	// Apply the correct filenaming settings
	if _, err := db.Exec("update directus_settings set `value`='file_name' where `key`='file_naming'"); err != nil {
		// Build data object that will be passed through to template
		indexData := &IndexData{user, projects, "", err}

		// Execute template
		indexTemplate.Execute(w, indexData)
		return
	}
	if _, err := db.Exec("update directus_settings set `value`='filename_download' where `key`='asset_url_naming'"); err != nil {
		// Build data object that will be passed through to template
		indexData := &IndexData{user, projects, "", err}

		// Execute template
		indexTemplate.Execute(w, indexData)
		return
	}

	// Build data object that will be passed through to template
	indexData := &IndexData{
		user,
		projects,
		fmt.Sprintf("%s created (key: %s)", projectName, projectKey),
		nil,
	}

	// Execute template
	indexTemplate.Execute(w, indexData)
}

func newProjectData(projectKey, projectName, projectDbName, projectEmail, projectPassword string) *ProjectData {
	return &ProjectData{
		projectKey,
		projectName,
		viper.GetString("API.SuperAdminToken"),
		viper.GetString("DB.Host"),
		projectDbName,
		viper.GetString("DB.User"),
		viper.GetString("DB.Password"),
		projectEmail,
		projectPassword,
		true,
		newStorageOptions(projectKey),
		newMailOptions(),
		newCORSOptions(),
	}
}

func newStorageOptions(projectKey string) *StorageOptions {
	return &StorageOptions{
		"s3",
		viper.GetString("S3.Key"),
		viper.GetString("S3.Secret"),
		viper.GetString("S3.Bucket"),
		"latest",
		viper.GetString("S3.Region"),
		map[string]string{
			"ACL":          "public-read",
			"CacheControl": "max-age=604800",
		},
		fmt.Sprintf("/%s", projectKey),
		fmt.Sprintf("/%s/thumbnails", projectKey),
		fmt.Sprintf("%s/%s", viper.GetString("S3.CloudfrontURL"), projectKey),
	}
}

func newMailOptions() *MailOptions {
	return &MailOptions{
		viper.GetString("Mail.Transport"),
		viper.GetString("Mail.Host"),
		viper.GetString("Mail.Port"),
		viper.GetString("Mail.Username"),
		viper.GetString("Mail.Password"),
		viper.GetString("Mail.Encryption"),
		viper.GetString("Mail.From"),
	}
}

func newCORSOptions() *CORSOptions {
	return &CORSOptions{
		Enabled:     true,
		Origin:      []string{"*"},
		Methods:     []string{"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"},
		Headers:     []string{"x-directus-project"},
		MaxAge:      600,
		Credentials: true,
	}
}

func populateDatabase(db *sql.DB, dbName string) error {
	template, err := ioutil.ReadFile("data/standard_map.sql")
	if err != nil {
		fmt.Println("Couldn't open standard map data")
	}

	// Target the newly created database
	if _, err := db.Exec(fmt.Sprintf("use %s", dbName)); err != nil {
		return err
	}

	// Split up each request to be executed
	requests := strings.Split(string(template), ";\n")

	for _, request := range requests {
		if request == "" {
			break
		}
		if _, err := db.Exec(request); err != nil {
			return err
		}
	}

	return nil
}
