<?php

return [
    'database' => [
        'type' => 'mysql',
        'host' => 'localhost',
        'port' => 3306,
        'name' => 't-systems',
        'username' => 'admin',
        'password' => 'MYU4dU;X[HmRVVg&hkfm',
        'engine' => 'InnoDB',
        'charset' => 'utf8mb4',
        // Remove 'host' above when using sockets
    //    'socket' => '',
    ],

    'cookie' => [
        'same_site' => 'Lax',
        'secure' => false
    ],

    'cors' => [
        'enabled' => true,
        'origin' => array (
		0 => 'https://app.webtwin.afew.work',
		1 => 'http://localhost',
),
        'methods' => array (
  0 => 'GET',
  1 => 'POST',
  2 => 'PUT',
  3 => 'PATCH',
  4 => 'DELETE',
  5 => 'HEAD',
),
        'headers' => array (
),
        'exposed_headers' => array (
),
        'max_age' => 600,
        'credentials' => true,
    ],

    'rate_limit' => [
        'enabled' => false,
        'limit' => 100,
        'interval' => 60,
        'adapter' => 'redis',
        'host' => '127.0.0.1',
        'port' => 6379,
        'timeout' => 10,
    ],

    'storage' => [
	    'adapter' => 's3',
	    'key' => 'AKIA42ZOFMKVDALD62E5',
	    'secret' => '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',
	    'bucket' => 'webtwin',
	    'version' => 'latest',
	    'region' => 'eu-west-2',
	    'options' => [
		    'ACL' => 'public-read',
		    'CacheControl' => 'max-age=604800'
	    ],
	    //'endpoint' => 's3-endpoint',
	    'root' => '/t-systems',
	    'thumb_root' => '/t-systems/thumbnails',
	    'root_url' => 'https://d1mcoyn3idghep.cloudfront.net/t-systems',
    ],

    'mail' => [
	    'default' => [
		    'transport' => 'smtp',
		    'host' => 'email-smtp.eu-west-2.amazonaws.com',
		    'port' => '587',
		    'username' => 'AKIA42ZOFMKVBARHYSQ3',
		    'password' => 'BB1FYfbfPW3iLyk29VJ8lC/3eCO0kLCWqvW8wFNqy0vg',
		    'encryption' => 'tls',
		    'from' => 'no-reply@web-twin.com'
	    ],
    ],

    'cache' => [
        'enabled' => false,
        'response_ttl' => 3600,
        'pool' => [
            // 'adapter' => '',
            // 'path' => '',
            // 'host' => '',
            // 'port' => '',
        ],
    ],

    'auth' => [
        'secret_key' => '0fWcMO85n2k2JObVPixIXuMnHlikMQlD',
        'public_key' => 'daa10750-ee63-4538-917c-dbcea5e5ef02',
        'ttl' => 20,
        'social_providers' => [
            // 'okta' => '',
            // 'github' => '',
            // 'facebook' => '',
            // 'google' => '',
            // 'twitter' => '',
        ],
    ],

    'hooks' => [
        'actions' => [],
        'filters' => [],
    ],

    'tableBlacklist' => [],

    'env' => 'production',

    'logger' => [
        'path' => '/srv/webtwin/src/core/Directus/Util/Installation/../../../../../logs',
    ],
];
