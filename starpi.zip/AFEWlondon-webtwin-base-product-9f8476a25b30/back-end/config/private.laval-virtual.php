<?php

return [
    'database' => [
        'type' => 'mysql',
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'laval_virtual',
        'username' => 'admin',
        'password' => 'MYU4dU;X[HmRVVg&hkfm',
        'engine' => 'InnoDB',
        'charset' => 'utf8mb4',
        // Remove 'host' above when using sockets
        'socket' => '',
    ],

    'cookie' => [
        'same_site' => 'Lax',
        'secure' => false
    ],

    'cors' => [
        'enabled' => true,
        'origin' => array (
  0 => '*',
),
        'methods' => array (
  0 => 'GET',
  1 => 'POST',
  2 => 'PUT',
  3 => 'PATCH',
  4 => 'DELETE',
  5 => 'HEAD',
),
        'headers' => array (
),
        'exposed_headers' => array (
),
        'max_age' => 600,
        'credentials' => true,
    ],

    'rate_limit' => [
        'enabled' => false,
        'limit' => 100,
        'interval' => 60,
        'adapter' => 'redis',
        'host' => '127.0.0.1',
        'port' => 6379,
        'timeout' => 10,
    ],

    'storage' => [
        'adapter' => 's3',
        'root' => '/laval-virtual',
        'root_url' => 'https://d1mcoyn3idghep.cloudfront.net/laval-virtual',
        'thumb_root' => '/laval-virtual/thumbnails',
        'key' => 'AKIA42ZOFMKVDALD62E5',
        'secret' => '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',
        'region' => 'eu-west-2',
        'version' => 'latest',
        'bucket' => 'webtwin',
        'options' => array (
  'ACL' => 'public-read',
  'CacheControl' => 'max-age=604800',
),
        // 'endpoint' => '',
        // 'proxy_downloads' => '',
    ],

    'mail' => [
        'default' => [
		'transport' => 'smtp',
		'host' => 'email-smtp.eu-west-2.amazonaws.com',
		'port' => '587',
		'username' => 'AKIA42ZOFMKVBARHYSQ3',
		'password' => 'BB1FYfbfPW3iLyk29VJ8lC/3eCO0kLCWqvW8wFNqy0vg',
		'encryption' => 'tls',
		'from' => 'no-reply@web-twin.com'
        ],
    ],

    'cache' => [
        'enabled' => false,
        'response_ttl' => 3600,
        'pool' => [
            // 'adapter' => '',
            // 'path' => '',
            // 'host' => '',
            // 'port' => '',
        ],
    ],

    'auth' => [
        'secret_key' => '8dH558lPlxkajiyK7cdyW74EdIpv35TB',
        'public_key' => 'e1d3d00c-89c9-44de-bbc6-c166aae94402',
        'ttl' => 20,
        'social_providers' => [
            // 'okta' => '',
            // 'github' => '',
            // 'facebook' => '',
            // 'google' => '',
            // 'twitter' => '',
        ],
    ],

    'hooks' => [
        'actions' => [],
        'filters' => [],
    ],

    'tableBlacklist' => [],

    'env' => 'production',

    'logger' => [
        'path' => '/srv/back-end/src/core/Directus/Util/Installation/../../../../../logs',
    ],
];
