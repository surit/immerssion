![WebTwin logo](WebTwin-logo.png)

# Overview
This repository contains the source code for the front and back end services of the WebTwin platform by Immersionn. The platform consists of four key services:

* **App** - often referred to as the _front-end_ or the _client-side_ - this is the website that the general public will access. It consumes its data from the API. The source code for this service is stored in the [`/app`](https://bitbucket.org/jeanmarchus2/webtwin-base-product/src/master/front-end/) directory.
* **CMS** - often referred to as the _back-end_, this is where the client will add and edit the content for their instance. The API runs on a platform called [Directus](https://directus.io/) Every client will access their database using this service, however each client's data will be stored in separate databases for security.
* **Databases** - each client has their own database which is stored on a single MySQL instance that sits on the same EC2 webserver as the rest of the services.
* **Installer** - this is a standalone service that creates an empty client database, initialises and connects to a new Directus project, and if applicable provisions the Directus instance with a pre-selected template.
* **Router** - a custom router that performs a [DNS lookup](#dns) for any CNAME records from a request host that doesn't match any nginx server blocks.

## ⚠️ Important note about user accounts
It is important to note that every time a new database and subsequent Directus instance is created a new table of users will be created for that project and as such user accounts cannot be shared across client instances.

# Naming conventions

## Clients
When a client is created via the installer for a customer, a Project Name will be required. This Project Name will be parsed into the following values:

* **Project name**: the raw project name specified in the installer e.g. "VR days"
* **Project key**: the raw project name parsed into kebab-case to be used by the Directus API e.g. `vr-days`
* **Database name**: the raw project name but in snake case for compatibility with the MySQL database e.g. `vr_days`


There is an `immersionn` client which is to be used internally as a testing and administrative platform. **Note**: you will only be able to access the WebTwin installer using login details from this client with a role of `administrator`.

## Map
Each client can have multiple maps associated with their instance identified by its own key - maps are created and configured in the API and when published, will be accessible to the public via the app.

## URLs
With the client and map naming conventions in mind, using VR days as an example client and 'event2021' as an example map, you would use the following URLs to access the API login screen and a map on the website, respectively:

| Service | Pattern | Example
| - | - | - |
| CMS | https://<CLIENT_KEY>.cms.web-twin.com | https://vr-days.cms.web-twin.com |
| App/Front-end map | https://<MAP_KEY>.<CLIENT_KEY>.web-twin.com | https://event2021.vr-days.web-twin.com

# Services

## CMS
The content management system used is called Directus. Web Twin uses [version 8](https://v8.docs.directus.io/getting-started/introduction.html). It is a "headless" CMS built in PHP which features a rich admin UI for adding/editing content, an API and a JavaScript SDK for accessing the content from the front end.

To all intents and purposes Directus merely acts as a wrapper for a vanilla MySQL database and adds a bit of sugar on the top. The platform is not tied to and does not rely on Directus.

## App (Front end)
The front end is a server-side generated app built in Nuxt.js, a Vue.js framework. It uses PostCSS and Babel to transform modern CSS and JS respectively into a flavour that the majority of browsers can interpret. As it generates pages on the initial page request (or every request for non-JS-enabled users) it requires a Node.js server to run.

The front end current exists as a single instance which queries the CMS using the Directus JS SDK and pulls in the relevant content for the client/map pairing.

## Installer
[The installer](https://installer.web-twin.com) is where you create new client instances. On installation it performs the following tasks:

1. creates a blank MySQL database [as mentioned above](#clients);
1. provisions a new Directus instance on that database;
1. creates a new admin user based the details supplied on the form (note: **not** the same details as the logged in user);
1. copies over the directus structure from a static SQL file which defines the 'shape' of the Directus fields

It is important to note that you can only log in to the installer as an administrator user from the internal `immersionn` client.

# Router
There is a custom router that picks up any non-web-twin based URLs that are pointed at the server and performs a DNS lookup to see if they have a valid client/map app URL (e.g. https://event2021.vr-days.web-twin.com). This is written in Go and deployed as an executable that uses systemd as a daemon. It runs in tandem with the [nginx webserver](#nginx) discussed in the next section.

# Infrastructure

## Server
The entire Web Twin product lives on a t2.micro Amazon EC2 instance. Currently the IP of this instance is `3.11.9.25` (TODO: this should be changed over to an elastic IP so we can spin up more/less powerful instances where necessary).

The app, CMS, installer and router are all located in the `/srv` directory of the server.

## Webserver
We use [OpenResty](https://openresty.org/en/) which is a subset of nginx as a webserver. This allows us to create SSL certificates on the fly via the [lua-resty-auto-ssl](https://github.com/auto-ssl/lua-resty-auto-ssl) plugin instead of having to manually provision new ones for each new map/client subdomain pairing.

The webserver configuration is still all in an nginx flavour but isn't stored in the regular nginx config location. The OpenResty nginx config can be found in `/usr/local/openresty/nginx`.

There are currently four site configurations used to route traffic to the server. Copies of these configurations are stored in the `/nginx` directory of this repository.

* `installer.conf` listens for http(s)://installer.web-twin.com and routes traffic to the installer service
* `backend.conf` listens for http(s)://<CLIENT_KEY>.cms.web-twin.com and routes traffic to the CMS service
* `frontend.conf` listens for http(s)://<MAP_KEY>.<CLIENT_KEY>.web-twin.com and proxies traffic to the front-end Node.js service.
* `default.conf` listens for any remaining traffic that doesn't fit the aforementioned three expressions. It proxies this traffic through a custom router that will perform a CNAME lookup on the request host to see if its value fits the http(s)://<MAP_KEY>.<CLIENT_KEY>.web-twin.com expression and proxies the request to the map.

## Database
WebTwin currently using a single Amazon RDS MySQL `t2.micro` instance. Currently there are no automatic backups performed but this can be set up in the AWS control panel.

## Node.js
The app/front-end relies on Node.js to server-side generate the initial page load (or every page load for non-JS users). [pm2](https://github.com/Unitech/pm2) is used as a daemon to maintain the Node.js process and handling no-downtime reload.

## systemd
[systemd](https://www.freedesktop.org/wiki/Software/systemd/) is used as a daemon for the installer and router binaries.

## S3/Cloudfront
All assets are stored in an S3 bucket which is served up by Cloudfront. The Directus configuration file has an S3 adapter which gets copied over on each installation and creates a new directory in the `webtwin` bucket for the instance.

### Brotli compression of Unity assets
Generally the compiled data/WASM/JS files from Unity tend to be quite large. In an effort to reduce the page download these assets can be Brotli compressed. Due to the fact that these are exported with `.br` file extensions (e.g. `asset.data.br` or `asset.wasm.br`) the mimetype and content encoding gets lost in translation on upload to S3. To mitigate this, we have built a Lambda function that listens to any uploads whose file names end in either `.data.br`, `.wasm.br` or `.js.br` and reinstates the correct mimetype and content encoding headers.

## SES
Amazon SES is used for sending transactional emails from Directus such as invites/forgotten passwords/etc. The configuration for this is injected at installation time in the same way the S3 adapter credentials are.

# Local installation

Obtain the code:
```sh
$ git clone git@bitbucket.org:jeanmarchus2/webtwin-base-product.git
```

## Directus
**Note**: Requires knowledge of Apache - if that's not your jam and you're absolutely desperate to do some work on the front-end, consider just using the live version of the API (but be careful!)

1. As the CMS is just a wrapper over a vanilla MySQL database, the easiest way to get up and running is to export a full client database from the RDS instance and import it into your local MySQL instance.

1. Install Directus locally by following steps 1-4 [here](https://v8.docs.directus.io/installation/git.html). I'd recommend doing it outside of this repo otherwise you'll get loads of untracked files.

1. Once installed copy over the configuration file for the instance whose data you exported in the first step from the server (or from the back-end directory in this repo if the project exists). This config can be found on the server at `/srv/back-end/config` and should go in the equivalent folder on your local Directus project.

1. The CMS should now be accessible on the URL specified in the Apache config

## App/front-end
Change into the front-end directory:
```sh
$ cd front-end
```

Update the value for `DIRECTUS_URL` field in the .env file - skip this if you wish to just use the live version (this could be dangerous so proceed with caution).

Install dependencies:
```sh
$ yarn
```

Run the development server:
```sh
$ yarn dev
```

## Installer
Make sure you have Go installed locally: https://golang.org/dl/

Change into the installer directory:
```sh
$ cd installer
```

Copy the config.sample over and fill out the fields:
```sh
$ cp config.sample.yaml config.yaml
```

Install dependencies:
```sh
$ go get
```

Run the app:
```sh
$ go run main.go
```

Access the installer at https://localhost:8000

# Deployment
## App/frontend
Make sure your `id_rsa.pub` key is copied to the `~/.ssh/authorized_keys` file on the server

Run `make deploy-prod` (or `make deploy-uat`) on your local machine in the `/front-end` directory - this will copy over the files to the server minus any dependencies because you haven't got all day.

Next ssh into the server, install dependencies, rebuild and reload:

```sh
$ ssh ubuntu@3.11.9.25
$ cd /srv/front-end
$ npm install
$ npm run build
$ pm2 reload frontend
```

## CMS
The CMS is a vanilla instance of Directus and as such there is no source code to deploy. There are some backed up configuration files that live in the /back-end directory of this repository for safe keeping.

Consider regularly backing these up by running `scp -r ubuntu@3.11.9.25:/srv/back-end/config/private.* back-end/` when in the root directory of this project just to be on the safe side.

## Installer & router
These are slightly tricker (and in the case of the router, riskier) to deploy with no downtime as the installer and router are both deployed as executables and can't be overwritten whilst running.

With that in mind, here is the process:

Change into the installer or router directory:
```sh
$ cd installer # or cd router
```

Build the executable:
```sh
$ make build
```

ssh into the server (in a new tab) and stop the current service:
```sh
$ ssh ubuntu@3.11.9.25
$ sudo service installer stop # or sudo service router stop
```

Deploy the executable you just built:
```sh
$ make deploy-prod // (or make deploy-uat)
```

In the tab with the ssh session, restart the service you just stopped:
```sh
$ sudo service installer start # or sudo service router start
```