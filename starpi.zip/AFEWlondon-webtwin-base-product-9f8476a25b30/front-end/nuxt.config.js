export default {
  // Global page headers (https://go.nuxtjs.dev/config-head)
  head: {
    title: 'front-end',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: '' },
    ],
  },

  // Global CSS (https://go.nuxtjs.dev/config-css)
  css: ['sanitize.css', '@/assets/style.css'],

  // Plugins to run before rendering page (https://go.nuxtjs.dev/config-plugins)
  plugins: [
    { src: '@/plugins/fullscreen', mode: 'client' },
    { src: '@/plugins/vue-modal', mode: 'client' },
    { src: '@/plugins/vue-plyr', mode: 'client' },
    { src: '@/plugins/webfont-loader', mode: 'client' },
    { src: '@/plugins/global-events', mode: 'client' },
    { src: '@/plugins/directus-inject' },
    { src: '@/plugins/clamp', mode: 'client' },
  ],

  // Auto import components (https://go.nuxtjs.dev/config-components)
  components: false,

  // Modules for dev and build (recommended) (https://go.nuxtjs.dev/config-modules)
  buildModules: [
    // https://go.nuxtjs.dev/eslint
    '@nuxtjs/eslint-module',
  ],

  // Modules (https://go.nuxtjs.dev/config-modules)
  modules: ['@nuxtjs/gtm', 'nuxt-polyfill'],

  gtm: {
    enabled: true,
    debug: true,
    id: process.env.GTM_UID,
  },

  env: {
    directusUrl: process.env.DIRECTUS_URL,
  },

  publicRuntimeConfig: {
    directusUrl: process.env.DIRECTUS_URL,
    directusUid: process.env.DIRECTUS_UID,
    gtm: {
      id: process.env.GOOGLE_TAG_MANAGER_ID,
    },
  },

  privateRuntimeConfig: {},
  polyfill: {
    features: [
      {
        require: 'event-source',
        detect: () => 'EventSource' in window,
      },
      {
        require: 'promise',
        detect: () => 'Promise' in window,
      },
    ],
  },
  router: {
    scrollBehavior: (to, from, savedPosition) => {
      if (savedPosition) return savedPosition
      return false
    },
    extendRoutes(routes, resolve) {
      if (process.env.NODE_ENV === 'production') {
        routes.push(
          {
            name: 'default',
            path: '/',
            component: resolve(__dirname, 'pages/index.vue'),
          },
          {
            name: 'scene',
            path: '/:scene_id',
            component: resolve(__dirname, 'pages/index.vue'),
          },
          {
            name: 'custom',
            path: '*',
            component: resolve(__dirname, 'pages/NotFound.vue'),
          }
        )
      } else {
        routes.push(
          {
            name: 'default',
            path: '/',
            component: resolve(__dirname, 'pages/NotFound.vue'),
          },
          {
            name: 'map',
            path: '/:project_id/:map_id',
            component: resolve(__dirname, 'pages/index.vue'),
          },
          {
            name: 'scene',
            path: '/:project_id/:map_id/:scene_id',
            component: resolve(__dirname, 'pages/index.vue'),
          },
          {
            name: 'custom',
            path: '*',
            component: resolve(__dirname, 'pages/NotFound.vue'),
          }
        )
      }
    },
  },

  // Build Configuration (https://go.nuxtjs.dev/config-build)
  build: {
    transpile: ['vue-unity-webgl', 'vue-fullscreen', 'vue-plyr'],

    postcss: {
      // Add plugin names as key and arguments as value
      // Install them before as dependencies with npm or yarn
      plugins: {
        // Disable a plugin by passing false as value
        'postcss-color-function': {},
        'postcss-import': {},
        'postcss-math': {},
        'postcss-nested': {},
        'postcss-preset-env': {
          stage: 0,
          importFrom: './vars.json',
          preserve: false,
        },
      },
      preset: {
        // Change the postcss-preset-env settings
        autoprefixer: {
          grid: false,
        },
      },
    },
  },
}
