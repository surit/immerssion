import { SET_PICTURE_MODAL, CLOSE_PICTURE_MODAL } from '@/store/mutation-types'

export const state = () => ({
  pictureModal: false,
})

export const mutations = {
  [SET_PICTURE_MODAL](state, payload) {
    state.pictureModal = payload
  },
  [CLOSE_PICTURE_MODAL](state) {
    state.pictureModal = false
  },
}

export const getters = {}

export const actions = {
  setPictureModal({ commit }, id) {
    commit(SET_PICTURE_MODAL, id)
  },
}
