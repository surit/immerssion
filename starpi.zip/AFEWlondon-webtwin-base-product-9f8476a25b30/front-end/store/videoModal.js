// import { client } from '@/helpers/directus-sdk'
// import DirectusSDK from '@directus/sdk-js'

import {
  SET_ACTIVE_VIDEO_MODAL,
  CLOSE_VIDEO_MODAL,
} from '@/store/mutation-types'

export const state = () => ({
  videoModal: false,
  videoModalOpen: false,
})

export const mutations = {
  [SET_ACTIVE_VIDEO_MODAL](state, payload) {
    state.videoModal = payload
  },
  [CLOSE_VIDEO_MODAL](state) {
    state.videoModal = false
  },
}

export const getters = {}

export const actions = {
  setActiveVideoModal({ commit }, id) {
    commit(SET_ACTIVE_VIDEO_MODAL, id)
  },
}
