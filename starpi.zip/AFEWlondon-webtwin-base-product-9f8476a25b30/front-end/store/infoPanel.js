import { SET_INFO_PANEL, CLOSE_INFO_PANEL } from '@/store/mutation-types'

export const state = () => ({
  infoPanel: false,
})

export const mutations = {
  [SET_INFO_PANEL](state, payload) {
    state.infoPanel = payload
  },
  [CLOSE_INFO_PANEL](state) {
    state.infoPanel = false
  },
}

export const getters = {}

export const actions = {
  setInfoPanel({ commit }, id) {
    commit(SET_INFO_PANEL, id)
  },
}
