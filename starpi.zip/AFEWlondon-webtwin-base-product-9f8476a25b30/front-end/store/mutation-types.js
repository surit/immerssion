export const INITIAL_SETUP = 'Handling initial setup'
export const SET_UNITY_SCENES = 'Setting unity scenes'
export const STORE_SETTINGS = 'Storing site settings'
export const SET_SCENE = 'Setting active scene'
export const SET_LOADING = 'Setting loading state'
export const SET_MAP_IDS = 'Setting map IDs'
export const SET_INFO_PANEL = 'Setting active info panel'
export const CLOSE_INFO_PANEL = 'Closing info panel'
export const SET_ERROR = 'Setting error'

export const SET_ACTIVE_VIDEO_MODAL = 'Setting active video modal'
export const CLOSE_VIDEO_MODAL = 'Closing video modal'

export const SET_PICTURE_MODAL = 'Setting active picture modal'
export const CLOSE_PICTURE_MODAL = 'Closing picture modal'

export const SET_LANGUAGE = 'Setting active language'

export const SET_UNITY_ENABLED = 'WebGL not supported. Activating Basic Mode'

export const SET_WEBGL_SUPPORT = 'WEB GL support checked'

export const SET_INITIAL_SCENE = 'Setting the initial scene ID'
export const SET_CTA_VISIBILITY = 'Setting visibility of CTAs'
export const SET_MOBILE_OVERLAY = 'Setting visibility of mobile overlay'
export const CLOSE_MOBILE_OVERLAY = 'Closing mobile overlay'
export const SET_DEVICE = 'Setting device type'
export const SET_CTAS = 'Setting scene CTAs'
export const SET_ALL_SCENES = 'Setting all scenes'
