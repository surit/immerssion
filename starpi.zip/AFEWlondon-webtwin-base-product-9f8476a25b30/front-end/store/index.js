// import { client } from '@/helpers/directus-sdk'
// import DirectusSDK from '@directus/sdk-js'

import {
  INITIAL_SETUP,
  SET_UNITY_SCENES,
  SET_SCENE,
  SET_LOADING,
  SET_LANGUAGE,
  SET_UNITY_ENABLED,
  SET_WEBGL_SUPPORT,
  SET_INITIAL_SCENE,
  SET_CTA_VISIBILITY,
  SET_MOBILE_OVERLAY,
  CLOSE_MOBILE_OVERLAY,
  SET_DEVICE,
  SET_ALL_SCENES,
  SET_CTAS,
  SET_ERROR,
  SET_MAP_IDS,
} from '@/store/mutation-types'

export const state = () => ({
  projectID: null,
  mapID: null,
  activeMap: null,
  activeScene: null,
  initialUnityScene: null,
  device: 'mobile',
  lang: 'en',
  loading: true,
  mapTheme: null,
  unityEnabled: false,
  webGlSupport: false,
  ctaBorderRadius: '0px',
  ctasVisible: false,
  mobileOverlayVisible: false,
  mobileOverlayContent: null,
  mobileOverlayCb: null,
  mobileOverlayParams: null,
  allScenes: [],
  activeCtas: [],
  error: false,
})

export const mutations = {
  [INITIAL_SETUP](state, { map, theme }) {
    state.activeMap = map
    switch (theme.cta_style) {
      case 'square':
        state.ctaBorderRadius = '0px'
        break
      case 'round':
        state.ctaBorderRadius = '6px'
        break
      case 'pill':
        state.ctaBorderRadius = '1em'
        break
    }
    state.mapTheme = theme
    state.unityEnabled = map.unity_enabled
  },
  [SET_MAP_IDS](state, { projectID, mapID }) {
    state.projectID = projectID
    state.mapID = mapID
  },
  [SET_UNITY_SCENES](state, payload) {
    state.unityScenes = payload
  },
  [SET_ERROR](state, payload) {
    state.error = payload
  },
  [SET_SCENE](state, payload) {
    state.activeScene = payload
  },
  [SET_LOADING](state, payload) {
    state.loading = payload
  },
  [SET_INITIAL_SCENE](state, payload) {
    state.initialUnityScene = payload
  },
  [SET_ALL_SCENES](state, payload) {
    state.allScenes = payload
  },
  [SET_UNITY_ENABLED](state, payload) {
    state.unityEnabled = payload
  },
  [SET_LANGUAGE](state, payload) {
    state.lang = payload
  },
  [SET_WEBGL_SUPPORT](state, payload) {
    state.webGlSupport = payload
  },
  [SET_CTA_VISIBILITY](state, payload) {
    state.ctasVisible = payload
  },
  [SET_DEVICE](state, payload) {
    state.device = payload
  },
  [SET_CTAS](state, payload) {
    state.activeCtas = payload
  },
  [SET_MOBILE_OVERLAY](state, payload) {
    state.mobileOverlayParams = payload?.params || false
    state.mobileOverlayVisible = payload?.status || false
    state.mobileOverlayContent = payload?.content || false
    state.mobileOverlayCb = payload?.cb || false
  },
  [CLOSE_MOBILE_OVERLAY](state) {
    state.mobileOverlayVisible = false
    state.mobileOverlayContent = false
    state.mobileOverlayCb = false
    state.mobileOverlayParams = false
  },
}

export const getters = {
  // Should we try to start Unity?
  startUnity: (state) => {
    return state.webGlSupport && state.unityEnabled
  },

  // Is there an actiev overlay? (video, picture or panel)
  overlayActive: (state) => {
    if (
      state.pictureModal.pictureModal ||
      state.infoPanel.infoPanel ||
      state.videoModal.videoModal
    ) {
      return true
    }
    return false
  },

  // Get custom Google font from CMS. Fall back to Roboto
  fontFamily: (state) => {
    return state.mapTheme?.google_font_name || 'Roboto'
  },

  // Is this a multi language map?
  multiLanguage: (state) => {
    return (
      (state.activeMap && state.activeMap?.translations?.length > 1) || false
    )
  },
}

export const actions = {
  // Get initial data
  // Load in all available views, plus general settings here.
  nuxtServerInit({ commit }, { route }) {
    const projectID = route.query.project || route.params.project_id
    const mapID = route.query.map || route.params.map_id
    commit(SET_MAP_IDS, { projectID, mapID })
  },
  initialSetup({ commit }, data) {
    commit(INITIAL_SETUP, data)
  },
  setActiveScene({ commit, dispatch }, scene) {
    const ctas =
      scene && scene.scene_ctas
        ? scene?.scene_ctas
            .map((item) => item.cta)
            .filter((el) => el !== null && el.status !== 'draft')
        : []
    dispatch('clearCtas').then(() => {
      commit(SET_CTAS, ctas)
      commit(SET_SCENE, scene)
    })
  },
  clearCtas({ commit }) {
    commit(SET_CTAS, [])
  },
  setActiveLanguage({ commit }, language) {
    commit(SET_LANGUAGE, language)
  },
  handleLoadingState({ commit }, loading) {
    commit(SET_LOADING, loading)
  },
  setUnityEnabled({ commit }, payload) {
    commit(SET_UNITY_ENABLED, payload)
  },

  setInitialScene({ commit }, payload) {
    commit(SET_INITIAL_SCENE, payload)
  },
  setAllScenes({ commit }, payload) {
    commit(SET_ALL_SCENES, payload)
  },

  setWebGlSupport({ commit }, payload) {
    commit(SET_WEBGL_SUPPORT, payload)
  },
  setCtaVisibility({ commit }, payload) {
    commit(SET_CTA_VISIBILITY, payload)
  },
  setMobileOverlay({ commit }, payload) {
    commit(SET_MOBILE_OVERLAY, payload)
  },
  closeMobileOverlay({ commit }) {
    commit(CLOSE_MOBILE_OVERLAY)
  },
  setDevice({ commit }, payload) {
    commit(SET_DEVICE, payload)
  },
}
