import Vue from 'vue'
import fullscreen from 'vue-fullscreen'
Vue.use(fullscreen)
