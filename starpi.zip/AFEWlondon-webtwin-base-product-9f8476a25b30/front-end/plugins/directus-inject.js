import DirectusSDK from '@directus/sdk-js'

export default ({ route, store }, inject) => {
  // Try store first so client-side requests can access it, failing that try
  // the route query (for initial server request) and lastly the route params
  // for local dev
  const projectID =
    store.state.projectID || route.query.project || route.params.project_id

  const client = new DirectusSDK({
    url: process.env.directusUrl,
    project: projectID,
  })

  inject('client', client)
}
