import Vue from 'vue'
import GlobalEvents from 'vue-global-events'
Vue.component('GlobalEvents', GlobalEvents)
