import webfontloader from 'webfontloader'

export default (context, inject) => {
  // Inject $hello(msg) in Vue, context and store.
  inject('webfontloader', webfontloader)
}
