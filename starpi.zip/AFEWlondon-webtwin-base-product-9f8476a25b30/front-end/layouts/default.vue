<template>
  <main
    :class="$style.Wrap"
    :style="
      backgroundImage
        ? {
            backgroundColor: backgroundColor,
            backgroundImage: `url(${backgroundImage})`,
            fontFamily: `${fontFamily}`,
          }
        : {
            backgroundColor: backgroundColor,
            fontFamily: `${fontFamily}`,
          }
    "
  >
    <app-header v-if="activeMap" />
    <section v-if="activeMap" class="u-container">
      <app-title :class="$style.Title" />
      <unity-scene />
    </section>
    <Nuxt v-if="activeMap" :class="$style.Content" />
    <app-footer v-if="activeMap" />
  </main>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import AppHeader from '@/components/AppHeader'
import AppFooter from '@/components/AppFooter'
import AppTitle from '@/components/AppTitle'
import UnityScene from '@/components/UnityScene'

export default {
  name: 'Map',
  components: {
    AppHeader,
    AppFooter,
    AppTitle,
    UnityScene,
  },
  computed: {
    ...mapState(['activeMap', 'mapTheme', 'projectID', 'mapID']),
    ...mapGetters(['fontFamily']),
    backgroundImage() {
      return this.mapTheme?.background_image?.data?.full_url || false
    },
    backgroundColor() {
      return this.mapTheme?.page_background_color || '#fff'
    },
  },
  async mounted() {
    const projectID = this.projectID
    const mapID = this.mapID
    console.log(this.$route, projectID, mapID)
    if (!projectID || !mapID) this.$router.push({ name: 'error' })

    if (mapID && mapID !== '') {
      try {
        // Get map data based on URL params
        const response = await this.$client.getItems('maps', {
          fields: [
            '*',
            'map_theme.*.*',
            'unity_data.*',
            'unity_json.*',
            'unity_wasm_framework.*',
            'unity_wasm_code.*',
            'unity_loader.*',
            'open_graph_image.*',
            'twitter_image.*',
            'translations.*',
          ],
          single: true,
          filter: {
            uid: mapID,
          },
        })

        // Set the default language for the map
        const defaultLanguage = response.data?.default_language_code
        this.setActiveLanguage(defaultLanguage)

        // Handle initial state setup
        this.initialSetup({
          projectID,
          mapID,
          map: response.data,
          theme: response.data?.map_theme || false,
        })
      } catch (err) {
        console.log(err)
      }
    }
    // load custom web font ASAP
    // TODO: prefetch google url
    this.$webfontloader.load({
      google: {
        families: [`${this.fontFamily}:400,700`],
      },
    })
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  },
  destroyed() {
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    ...mapActions([
      'setWebGlSupport',
      'setDevice',
      'setActiveLanguage',
      'initialSetup',
    ]),

    handleResize() {
      const width = window.innerWidth
      width <= 960 ? this.setDevice('mobile') : this.setDevice('desktop')
    },
  },
}
</script>

<style module lang="postcss">
.Wrap {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-size: cover;
  background-position: center;
}
.Content {
  flex-grow: 1;
}
</style>
