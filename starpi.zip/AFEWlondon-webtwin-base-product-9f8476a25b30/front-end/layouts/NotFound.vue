<template>
  <main :class="$style.Wrap">
    <Nuxt :class="$style.Content" />
  </main>
</template>

<script>
export default {
  name: 'NotFound',
}
</script>

<style module lang="postcss">
.Wrap {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.Content {
  flex-grow: 1;
}
</style>
