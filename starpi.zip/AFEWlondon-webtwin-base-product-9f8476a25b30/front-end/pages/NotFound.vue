<template>
  <section class="u-container">
    <header>
      <h1>Page not found</h1>
    </header>
  </section>
</template>

<script>
export default {
  name: 'NotFound',
  layout: 'NotFound',
}
</script>
