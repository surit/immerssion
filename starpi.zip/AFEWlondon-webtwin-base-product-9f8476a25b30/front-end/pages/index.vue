<template>
  <section class="u-container">
    <primary-cta />
  </section>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import PrimaryCta from '@/components/PrimaryCta'

export default {
  name: 'HomePage',
  layout: 'Map',
  components: {
    PrimaryCta,
  },
  computed: {
    ...mapState(['activeMap', 'mapTheme', 'error']),
    pageTitle() {
      return this.activeMap?.meta_title || ''
    },
    metaDescription() {
      return this.activeMap?.meta_description || ''
    },
    ogUrl() {
      return this.activeMap?.asset_url || ''
    },
    ogImage() {
      return this.activeMap?.open_graph_image?.data?.full_url || null
    },
    twitterImage() {
      return this.activeMap?.twitter_image?.data?.full_url || null
    },
    favicon() {
      return this.mapTheme?.favicon?.data?.full_url || '/favicon.ico'
    },
  },
  methods: {
    ...mapActions(['setActiveLanguage', 'initialSetup']),
  },
  head() {
    return {
      title: this.pageTitle,
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.metaDescription,
        },
        {
          hid: 'og-title',
          property: 'og:image',
          content: this.pageTitle,
        },
        {
          hid: 'og-image',
          property: 'og:image',
          content: this.ogImage,
        },
        {
          hid: 'og-url',
          property: 'og:url',
          content: this.ogUrl,
        },
        {
          hid: 'og-desc',
          property: 'og:description',
          content: this.metaDescription,
        },
        {
          hid: 'twitter-card',
          property: 'twitter:card',
          content: 'summary_large_card',
        },
        {
          hid: 'twitter-image',
          property: 'twitter:image',
          content: this.twitterImage,
        },
      ],
      link: [
        {
          rel: 'icon',
          type: 'image/x-icon',
          href: this.favicon,
        },
      ],
    }
  },
}
</script>

<style></style>
