<template>
  <section
    v-if="activeMap.show_primary_cta"
    :class="[$style.PrimaryCta, 'u-container']"
  >
    <a
      :href="activeTranslations.cta_url"
      target="_blank"
      :data-cta="activeMap.primary_cta_gtm_uid"
      class="u-custom-font"
      :style="{
        color: mapTheme.primary_cta_text_color,
        backgroundColor: mapTheme.primary_cta_background_color,
        borderRadius: ctaBorderRadius,
      }"
    >
      {{ activeTranslations.cta_text || 'no translation' }}
    </a>
  </section>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'AppHeader',
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme', 'ctaBorderRadius']),
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },
}
</script>

<style module lang="postcss">
.PrimaryCta {
  padding: 2.5rem 0.5rem;
  display: flex;
  & a {
    background: var(--c-brand);
    color: #fff;
    text-decoration: none;
    padding: 0.75rem 1rem;
    border-radius: 10px;
    font-size: 1.2rem;
    text-align: center;
    display: block;
    margin: 0 auto;
  }

  @media (--sm) {
    padding: 2.5rem 1rem;
    & a {
      font-size: 1.4rem;
      padding: 0.75rem 2.5rem;
    }
  }
  @media (--md) {
    & a {
      font-size: 1.6rem;
    }
  }
  @media (--lg) {
    & a {
      font-size: 2rem;
    }
  }
}
</style>
