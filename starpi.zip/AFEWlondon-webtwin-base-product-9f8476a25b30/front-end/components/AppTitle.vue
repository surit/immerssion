<template>
  <header v-if="activeMap.show_page_title" :class="$style.AppTitle">
    <h1 class="u-custom-font" :style="{ color: mapTheme.title_text_color }">
      {{ activeTranslations.page_title }}
    </h1>
  </header>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'AppTitle',
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme']),
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },
}
</script>

<style module lang="postcss">
.AppTitle {
  text-align: center;
  color: var(--c-grey);
  line-height: 1.2;
  padding: 1rem 0.5rem;
  padding-bottom: 0;
  @media (--md) {
    padding-top: 2rem;
  }
  @media (--lg) {
  }
}
</style>
