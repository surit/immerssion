<template>
  <button
    :class="$style.Cta"
    :style="{
      backgroundColor: mapTheme.cta_background_color,
      borderRadius: ctaBorderRadius,
      color: mapTheme.cta_icon_color,
    }"
  >
    <slot />
    <icon-close
      v-if="icon === 'close'"
      :style="{ stroke: mapTheme.cta_icon_color }"
    />
  </button>
</template>

<script>
import { mapState } from 'vuex'
import IconClose from '@/components/_icons/IconClose'
export default {
  name: 'Cta',
  components: {
    IconClose,
  },
  props: {
    icon: {
      type: String,
      default: '',
    },
  },
  computed: {
    ...mapState(['mapTheme', 'ctaBorderRadius']),
  },
}
</script>

<style module lang="postcss">
.Cta {
  background: var(--c-brand);
  -webkit-appearance: none;
  border: none;
  margin: 0;
  padding: 0.5rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  font-size: 1rem;
  line-height: 1.2;
  text-transform: uppercase;
  font-weight: bold;
  outline: none;
  pointer-events: auto;
  border-radius: 4px;
  & svg {
    stroke: #fff;
    display: block;
  }
}
</style>
