<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="transparent"
    :stroke="strokeColor"
    stroke-width="1"
    stroke-linecap="butt"
    stroke-linejoin="arcs"
  >
    <path
      d="M15.6 11.6L22 7v10l-6.4-4.5v-1zM4 5h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7c0-1.1.9-2 2-2z"
    />
  </svg>
</template>
<script>
export default {
  props: {
    strokeColor: {
      type: String,
      default: '#ffffff',
    },
  },
}
</script>
