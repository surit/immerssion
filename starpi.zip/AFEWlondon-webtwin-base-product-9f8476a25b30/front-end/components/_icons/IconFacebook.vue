<template>
  <svg
    width="10"
    height="20"
    viewBox="0 0 10 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.82129 20V11H9.55368L10 7H6.82129V5.05176C6.82129 4.02176 6.8476 3 8.2869 3H9.74469V0.140137C9.74469 0.0971367 8.49249 0 7.22568 0C4.57999 0 2.9234 1.6572 2.9234 4.7002V7H0V11H2.9234V20H6.82129Z"
      fill="black"
    />
  </svg>
</template>
