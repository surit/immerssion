<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="none"
    :stroke="strokeColor"
    stroke-width="1"
    stroke-linecap="butt"
    stroke-linejoin="arcs"
  >
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="12" y1="16" x2="12" y2="12"></line>
    <line x1="12" y1="8" x2="12.01" y2="8"></line>
  </svg>
</template>
<script>
export default {
  props: {
    strokeColor: {
      type: String,
      default: '#ffffff',
    },
  },
}
</script>
