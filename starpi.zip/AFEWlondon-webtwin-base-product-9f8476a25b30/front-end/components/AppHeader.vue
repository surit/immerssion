<template>
  <header
    v-if="activeMap.show_site_header"
    :class="$style.AppHeader"
    :style="{ backgroundColor: mapTheme.header_background_color }"
  >
    <section
      v-if="multiLanguage"
      :class="$style.LanguageSelect"
      :style="{
        backgroundColor: mapTheme.language_bar_background_color,
        color: mapTheme.language_bar_text_color,
      }"
    >
      <ul :class="[$style.LanguageSelectInner, 'u-container']">
        <template v-for="(item, i) in activeMap.translations">
          <li
            :key="`language-${i}`"
            :style="{
              borderColor: mapTheme.language_bar_text_color,
            }"
          >
            <button
              :class="{
                [$style.LanguageCta]: true,
                [$style.LanguageCtaActive]: lang === item.language,
              }"
              :style="{
                color: mapTheme.language_bar_text_color,
              }"
              @click="handleSetActiveLanguage(item.language)"
            >
              {{ item.language }}
            </button>
          </li>
        </template>
      </ul>
    </section>
    <div :class="[$style.Inner, 'u-container']">
      <section v-if="logoUrl" :class="$style.Logo">
        <img :src="logoUrl" />
      </section>
      <section
        v-if="activeMap.show_strapline"
        :class="[$style.Strapline, 'u-custom-font']"
        :style="{ color: mapTheme.header_text_color }"
      >
        {{ activeTranslations.strapline }}
      </section>
    </div>
  </header>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex'
export default {
  name: 'AppHeader',
  computed: {
    ...mapState(['activeMap', 'lang', 'multiple', 'mapTheme']),
    ...mapGetters(['multiLanguage']),
    logoUrl() {
      return this.mapTheme?.logo?.data?.full_url || false
    },
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },
  mounted() {
    const language = this.$route.query.lang
    if (language && this.activeMap.translations.length) {
      // check if translations exist
      const translationAvailable =
        this.activeMap.translations.filter((e) => e.language === language)
          .length > 0

      if (translationAvailable) {
        // set the language
        this.setActiveLanguage(this.$route.query.lang)
      } else {
        console.log('no translation available for: ', language)
      }
    }
  },
  methods: {
    ...mapActions(['setActiveLanguage']),
    handleSetActiveLanguage(language) {
      this.$router.push({ query: { lang: language } })
      this.setActiveLanguage(language)
    },
  },
}
</script>

<style module lang="postcss">
.AppHeader {
  background: var(--c-header-bg);
}

.LanguageSelect {
  background: var(--c-grey);
  color: #fff;
  & span {
    padding: 0 0.5rem;
  }
}

.LanguageSelectInner {
  display: flex;
  justify-content: flex-end;
  padding: 0.5rem 1rem;
  list-style: none;
  & li {
    border-right: 1px solid #fff;
    padding: 0 0.5rem;
    &:last-child {
      border: none;
      padding-right: 0;
    }
  }
}

.LanguageCta {
  -webkit-appearance: none;
  border: none;
  margin: 0;
  padding: 0;
  background: transparent;
  color: #fff;
  text-transform: uppercase;
  cursor: pointer;
}

.LanguageCtaActive {
  font-weight: bold;
}

.Inner {
  display: flex;
  justify-content: space-between;
  padding: 1.5rem 1rem;
}

.Logo {
  margin: 0 auto;
  /* max-width: 210px; */
  /* margin: 0 auto;
  max-height: 60px;
  display: flex; */
  & svg,
  & img {
    display: block;
    height: 100%;
    max-height: 60px;
    object-fit: contain;
    margin: 0 auto;
  }

  @media (--md) {
    margin: 0;
    & img,
    & svg {
      margin: 0;
    }
  }
}

.Strapline {
  display: none;
  font-size: 1.4rem;
  color: #fff;
  align-self: center;

  @media (--md) {
    display: block;
  }
}
</style>
