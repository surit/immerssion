<template>
  <footer
    v-if="activeMap.show_site_footer"
    :class="$style.AppFooter"
    :style="{ backgroundColor: mapTheme.footer_background_color }"
  >
    <div :class="[$style.Inner, 'u-container']">
      <section v-if="logoUrl" :class="$style.Logo">
        <img :src="logoUrl" />
      </section>
      <section :class="$style.FooterText">
        <p>{{ mapTheme.footer_text }}</p>
      </section>
      <section v-if="footerLinks" :class="$style.FooterLinks">
        <ul>
          <li v-for="(item, i) in footerLinks" :key="`link-${i}`">
            <a href="#">{{ item.text }}</a>
          </li>
        </ul>
      </section>
    </div>
  </footer>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'AppFooter',
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme']),
    logoUrl() {
      return this.mapTheme?.footer_logo?.data?.full_url || false
    },
    footerLinks() {
      return this.mapTheme?.footer_links || false
    },
  },
}
</script>
<style module lang="postcss">
.AppFooter {
  background: var(--c-grey);
  color: #fff;
}
.Inner {
  padding: 2rem 1rem;
  & p {
    margin: 0;
  }
}
.Logo {
  /* height: 60px; */
  display: flex;
  & svg,
  & img {
    display: block;
    height: 100%;
    max-height: 60px;
    object-fit: contain;
    margin: 0 auto;
  }
  @media (--md) {
    margin: 0;
    display: flex;
    justify-content: flex-start;
    & img,
    & svg {
      margin: 0;
    }
  }
}

.FooterLinks {
  margin-top: 0.5rem;
  & ul {
    margin: 0;
    padding: 0;
    list-style: none;
    display: flex;
    & li {
      margin: 0;
      padding: 0;
      margin-right: 1rem;
      & a {
        color: #fff;
        font-size: 0.9rem;
      }
    }
  }
}

.FooterText {
  margin-top: 1rem;
}
</style>
