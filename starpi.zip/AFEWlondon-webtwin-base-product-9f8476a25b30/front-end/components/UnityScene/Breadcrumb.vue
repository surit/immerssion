<template>
  <nav :class="$style.Breadcrumb">
    <ul>
      <li v-if="navBarLogo" :class="$style.RootLogo">
        <template v-if="navBarLogoLink">
          <a
            :href="navBarLogoLink"
            :target="navBarLogoLinkNewTab ? '_blank' : '_self'"
          >
            <img :src="navBarLogo" />
          </a>
        </template>
        <template v-else>
          <img :src="navBarLogo" />
        </template>
      </li>
      <template v-if="activeScene && activeScene.breadcrumb_home_link">
        <li :class="$style.HomeLink">
          <a
            :href="activeScene.breadcrumb_home_link"
            :style="{ color: mapTheme.map_menu_color }"
          >
            {{ homeLinkText }}
          </a>
        </li>
      </template>
      <template v-if="activeScene && !activeScene.breadcrumb_home_link">
        <li
          :class="$style.HomeLink"
          :style="{ color: mapTheme.map_menu_color }"
          @click="goToHomeScene"
        >
          {{ homeLinkText }}
        </li>
      </template>
      <li
        v-if="
          activeScene && activeScene.scene_id !== initialUnityScene.scene_id
        "
        :style="{ color: mapTheme.map_menu_color }"
      >
        <span :class="$style.Chevron">
          <icon-chevron-right :style="{ stroke: mapTheme.map_menu_color }" />
        </span>
        {{ activeScene.scene_name }}
      </li>
    </ul>
  </nav>
</template>

<script>
import { mapActions, mapState, mapGetters } from 'vuex'
import IconChevronRight from '@/components/_icons/IconChevronRight'
export default {
  name: 'Breadcrumb',
  components: {
    IconChevronRight,
  },
  props: {
    unityInstance: {
      type: [Object, Boolean],
      default: false,
    },
  },
  computed: {
    ...mapState([
      'activeMap',
      'activeScene',
      'activeSidePanel',
      'initialUnityScene',
      'mapTheme',
      'unityEnabled',
    ]),
    ...mapGetters(['startUnity']),
    navBarLogo() {
      return this.mapTheme?.nav_bar_logo?.data?.full_url || false
    },
    navBarLogoLink() {
      return this.mapTheme?.nav_bar_logo_link || false
    },
    navBarLogoLinkNewTab() {
      return this.mapTheme?.nav_bar_logo_link_new_tab
    },
    singleScene() {
      return this.activeMap?.unity_scenes.length === 1
    },
    homeLinkText() {
      return this.initialUnityScene?.scene_name
    },
  },
  mounted() {},
  methods: {
    ...mapActions(['setActiveScene', 'closeSidePanel', 'setCtaVisibility']),
    goToHomeScene() {
      if (this.singleScene) return
      if (
        this.startUnity &&
        this.initialUnityScene.scene_id !== this.activeScene.scene_id
      )
        this.setCtaVisibility(false)
      const projectID = this.$route.params.project_id
      const mapID = this.$route.params.map_id
      // close the side panel if its open
      if (this.activeSidePanel) this.closeSidePanel()
      // TODO: get this from CMS
      if (projectID && mapID) {
        this.$router.push({ path: `/${projectID}/${mapID}` })
      } else {
        this.$router.push({ path: `/` })
      }
      if (this.initialUnityScene.scene_name !== this.activeScene.scene_name) {
        if (this.unityInstance && this.startUnity) {
          this.unityInstance.SendMessage(
            'SceneMgmt',
            'changeScene',
            this.initialUnityScene.scene_id
          )
        }
        this.setActiveScene(this.initialUnityScene)
      }
    },
  },
}
</script>
<style module lang="postcss">
.Breadcrumb {
  padding: 0.5rem;
  position: absolute;
  top: 0;
  left: 0;

  & ul {
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    & li {
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      padding-top: 3px;
      font-weight: 700;
    }
  }
}

:global(.u-fs) {
  & .Breadcrumb {
    top: 0rem;
    & ul li {
      /* font-size: clamp(1rem, 10vw, 2rem); */
    }
  }
}

.RootLogo {
  padding-top: 0 !important;
  max-width: 40px;
  margin-right: 0.5rem !important;
  &:before {
    display: none;
  }
  & img {
    width: 100%;
    height: auto;
  }
}

.HomeLink {
  text-decoration: underline;
  cursor: pointer;
  text-decoration: none;
  & a {
    text-decoration: none;
  }
  &:hover {
    text-decoration: underline;
    & a {
      text-decoration: underline;
    }
  }
}

.Chevron {
  padding: 0 0.25rem;
  & svg {
    stroke: var(--c-brand);
    display: block;
    width: 1rem;
    height: 1rem;
  }
}
</style>
