<template>
  <section
    :class="{
      [$style.SponsorZone]: true,
      [$style.LayoutFull]: layout === 'full',
      [$style.SingleSponsor]: sponsors.length === 1,
    }"
  >
    <template v-for="(item, index) in sponsors">
      <sponsor
        :key="`sponsor-${index}`"
        :sponsor="item"
        :single="sponsors.length === 1"
        panel
      />
    </template>
  </section>
</template>

<script>
import Sponsor from '@/components/UnityScene/Sponsor'
export default {
  name: 'SponsorZone',
  components: {
    Sponsor,
  },
  props: {
    sponsors: {
      type: Array,
      default: () => [],
    },
    layout: {
      type: String,
      default: 'default',
    },
  },
}
</script>
<style module lang="postcss">
.SponsorZone {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-auto-rows: min-content;
  grid-gap: 1rem;
  margin-top: 1rem;
  align-items: start;
  @media (--lg) {
    grid-template-columns: 1fr 1fr 1fr;
  }
}

.LayoutFull {
  grid-template-columns: 1fr 1fr;
  @media (--sm) {
    grid-template-columns: 1fr 1fr 1fr;
  }
  @media (--md) {
    grid-template-columns: 1fr 1fr 1fr;
  }
  @media (--lg) {
    grid-template-columns: 1fr 1fr 1fr 1fr;
  }
  @media (--xl) {
    grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
  }
}
.SingleSponsor {
  display: block;
}
</style>
