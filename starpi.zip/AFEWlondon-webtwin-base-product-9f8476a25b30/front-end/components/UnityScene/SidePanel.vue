<template>
  <aside
    v-if="content"
    :class="{
      [$style.SidePanel]: true,
      [$style.SidePanelLarge]: layout === 'large',
      [$style.SidePanelFullWidth]: layout === 'full',
    }"
  >
    <transition name="cta">
      <cta
        v-if="showCloseCta"
        :icon="'close'"
        :class="$style.CloseCta"
        @click.native="handleClosePanel"
      />
    </transition>
    <div :class="$style.Inner">
      <section :class="$style.Content">
        <header :class="$style.Header">
          <h2>{{ activeTranslations.title }}</h2>
        </header>
        <p>{{ activeTranslations.description }}</p>
        <ul>
          <li
            v-for="(item, i) in activeTranslations.benefits"
            :key="`benefit-${i}`"
          >
            {{ item.benefit }}
          </li>
        </ul>
        <footer :class="$style.Footer">
          <a
            :href="activeTranslations.cta_link"
            :data-link="activeTranslations.cta_text"
          >
            {{ activeTranslations.cta_text }}
          </a>
        </footer>
      </section>
      <sponsor-zone
        :sponsors="suppliers"
        :layout="layout"
        :class="$style.Suppliers"
      />
    </div>
  </aside>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import Cta from '@/components/Cta'
import SponsorZone from '@/components/UnityScene/SponsorZone'

export default {
  name: 'InfoPanel',
  components: { Cta, SponsorZone },
  data() {
    return {
      content: null,
      showCloseCta: false,
      suppliers: [],
    }
  },
  computed: {
    ...mapState(['lang']),
    ...mapState('infoPanel', ['infoPanel']),
    activeTranslations() {
      const translations = this.content.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
    sponsors() {
      if (!this.content?.sponsors) return []
      return this.content?.sponsors.map((item) => {
        return item.sponsor
      })
    },
    supplierTopic() {
      return this.content?.supplier_topic?.ref
    },
    supplierIndustry() {
      return this.content?.supplier_industry?.ref
    },
    layout() {
      return this.content?.layout || 'default'
    },
  },
  async mounted() {
    try {
      const response = await this.$client.getItems('info_panels', {
        fields: ['*.*', 'translations.*', 'sponsors.sponsor.*.*'],
        single: true,
        status: 'published',
        filter: {
          id: this.infoPanel,
        },
      })
      this.content = response.data
      this.showCloseCta = true
      this.getSuppliers()
    } catch (err) {
      this.handleClosePanel()
      console.error(err)
    }
  },
  methods: {
    ...mapActions('infoPanel', ['setInfoPanel']),
    handleClosePanel() {
      this.showCloseCta = false
      this.$nextTick(() => {
        this.setInfoPanel(false)
      })
    },
    getSuppliers() {
      const filter = {}
      if (!this.supplierTopic && !this.supplierIndustry) {
        console.log('no topics or industries')
        this.suppliers = this.content.sponsors.map((item) => {
          return item.sponsor
        })
        return
      }
      if (this.supplierTopic) {
        filter['topics.topic.ref'] = {
          eq: this.supplierTopic,
        }
      }
      if (this.supplierIndustry) {
        filter['industries.industry.ref'] = {
          eq: this.supplierIndustry,
        }
      }
      console.log(filter)
      this.$client
        .getItems('sponsors', {
          fields: ['*.*'],
          status: 'published',
          filter,
        })
        .then((resp) => {
          this.suppliers = resp.data
          console.log(this.suppliers.length)
        })
        .catch((err) => {
          console.error('ERROR', err)
        })
    },
  },
}
</script>

<style module lang="postcss">
.SidePanel {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  width: 100%;
  background: #fff;
  display: flex;
  flex-direction: column;
  pointer-events: auto;
  color: var(--c-grey);
  z-index: 4;

  @media (--md) {
    width: 50%;
  }
  @media (--lg) {
    width: 33.33%;
  }
}

.Inner {
  flex-grow: 1;
  overflow-x: hidden;
  overflow-y: auto;
  padding: 3rem 1rem;
  display: grid;
  grid-template-rows: min-content min-content;
  grid-template-columns: 1fr;
  grid-template-areas: 'Content' 'Suppliers';
  @media (--md) {
    padding: 3.5rem 1rem 0 1rem;
  }
}

.CloseCta {
  position: absolute;
  top: 1rem;
  right: 1rem;
  @media (--md) {
    right: 0;
    transform: translateX(calc(100% + 1rem));
  }
}

.Content {
  min-height: 0;
  font-size: 0.9rem;
  grid-area: Content;
  align-self: start;
  & p {
    white-space: pre-line;
  }
  & p:first-child {
    margin-top: 0;
  }

  & ul {
    margin: 0;
    padding: 0 0 0 1rem;
    & li {
      margin-bottom: 0.5rem;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
}

.Header {
  & h2 {
    margin: 0;
    line-height: 1.2;
  }
  @media (--lg) {
    & h2 {
      font-size: 1.5rem;
    }
  }
}

.Suppliers {
  grid-area: Suppliers;
  padding-bottom: 2rem;
}

.Footer {
  padding: 0;
  margin: 2rem 0;
  & a {
    color: var(--c-brand);
  }
}

.SidePanelLarge {
  @media (--md) {
    width: 85%;
    & .Inner {
      grid-template-rows: auto;
      grid-template-columns: 1fr 1fr;
      grid-template-areas: 'Content Suppliers';
    }
    & .Content {
      position: sticky;
      top: 0;
      margin-right: 0.5rem;
    }
    & .Suppliers {
      margin-left: 0.5rem;
      margin-top: 0;
    }
  }
  @media (--lg) {
    width: 75%;
  }
}

.SidePanelFullWidth {
  @media (--md) {
    width: 85%;
    & .Inner {
      grid-template-rows: min-content 1fr;
      grid-template-columns: 1fr 1fr;
      grid-template-areas: 'Content .' 'Suppliers Suppliers';
    }
    & .Content {
      position: static;
    }
    & .Suppliers {
      margin-left: 0.5rem;
      margin-top: 0;
    }
  }
  @media (--lg) {
    width: 75%;
  }
}
</style>
