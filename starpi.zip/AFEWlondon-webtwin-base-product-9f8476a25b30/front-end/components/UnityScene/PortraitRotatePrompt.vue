<template>
  <section :class="$style.PortaitRotate">
    <div :class="$style.Msg">
      <icon-rotate />
      <p>
        For the best experience, please rotate your device to landscape mode
      </p>
    </div>
  </section>
</template>

<script>
import IconRotate from '@/components/_icons/IconRotate'

export default {
  name: 'PortaitRotate',
  components: {
    IconRotate,
  },
}
</script>
<style module lang="postcss">
.PortaitRotate {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: hidden;
  z-index: 20;
  display: none;
  justify-content: center;
  align-items: center;

  @media (--portrait) {
    display: flex;
    background: #fff;
  }

  @media (--md) {
    @media (--portrait) {
      display: none;
    }
  }
}

.Msg {
  max-width: 200px;
  text-align: center;
  & svg {
    width: 3rem;
    height: 3rem;
    stroke: var(--c-brand);
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
  }
}
</style>
