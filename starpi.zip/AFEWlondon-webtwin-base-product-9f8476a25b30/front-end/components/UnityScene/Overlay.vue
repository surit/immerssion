<template>
  <section>
    <template v-for="(item, i) in activeCtas">
      <!-- Unity Scene CTAs -->
      <transition :key="`cta-${item.id}-${i}`" name="fade">
        <cta-button
          v-if="
            item &&
            item.cta_style === 'Button' &&
            ctasVisible &&
            item.status === 'published'
          "
          :id="`cta-${item.id}`"
          :item="item"
        />
      </transition>

      <transition :key="`cta-${item.id}-${i}`" name="fade">
        <cta-overlay
          v-if="
            item &&
            item.cta_style === 'Overlay' &&
            ctasVisible &&
            item.status === 'published'
          "
          :item="item"
        />
      </transition>
    </template>

    <div v-if="mobileOverlayVisible" :class="$style.MobileOverlay">
      <h2 v-if="mobileOverlayContent">{{ mobileOverlayContent }}</h2>
      <div :class="$style.Options">
        <cta
          :class="$style.MobileOverlaymore"
          @click.native="closeMobileOverlay()"
        >
          back
        </cta>
        <template v-if="linkList">
          <cta
            v-for="(link, index) in mobileOverlayLinks"
            :key="`'link-${index}`"
            :class="$style.MobileOverlaymore"
            @click.native="handleMobileOverlayCb(link.id)"
          >
            {{ getTranslation(link, 'title') }}
          </cta>
        </template>
        <cta
          v-else
          :class="$style.MobileOverlaymore"
          @click.native="handleMobileOverlayCb"
        >
          more
        </cta>
      </div>
    </div>
  </section>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex'
import CtaButton from '@/components/UnityScene/CtaButton'
import CtaOverlay from '@/components/UnityScene/CtaOverlay'
import Cta from '@/components/Cta'

export default {
  name: 'UnityOverlay',
  components: {
    CtaButton,
    CtaOverlay,
    Cta,
  },
  props: {
    unityInstance: {
      type: [Object, Boolean],
      default: false,
    },
  },
  data() {
    return {
      isMobile: true,
    }
  },
  computed: {
    ...mapState([
      'activeScene',
      'allScenes',
      'ctasVisible',
      'mobileOverlayVisible',
      'mobileOverlayContent',
      'mobileOverlayCb',
      'mobileOverlayParams',
      'lang',
      'activeCtas',
    ]),

    ...mapGetters(['overlayActive', 'startUnity']),
    linkList() {
      return Array.isArray(this.mobileOverlayParams)
    },
    mobileOverlayLinks() {
      if (Array.isArray(this.mobileOverlayParams)) {
        return this.mobileOverlayParams
      }
      return false
    },
  },
  mounted() {
    const width = window.innerWidth
    this.isMobile = width <= 960
    this.$root.$on('sceneChange', this.handleSceneChange)
  },
  methods: {
    ...mapActions([
      'setActiveScene',
      'setCtaVisibility',
      'setMobileOverlay',
      'closeMobileOverlay',
    ]),

    handleMobileOverlayCb(param) {
      console.log(param)
      this.$nextTick(() => {
        param && typeof param === 'number'
          ? this.mobileOverlayCb(param)
          : this.mobileOverlayCb(this.mobileOverlayParams)
        this.closeMobileOverlay()
      })
    },
    handleSceneChange(id) {
      // Get the new scene
      const scene = this.allScenes.find((item) => {
        return item.scene_id === id
      })

      // Set the new scene
      if (scene.scene_name !== this.activeScene.scene_name) {
        this.setActiveScene(scene)

        // If Unity is running then send changeScene message
        if (this.startUnity)
          this.unityInstance.SendMessage('SceneMgmt', 'changeScene', id)
      }
    },
    getTranslation(content, field) {
      if (!content?.translations) return
      const translations = content.translations.find(
        (item) => item.language === this.lang
      )
      return translations[field]
    },
  },
}
</script>
<style module lang="postcss">
.Cta {
  pointer-events: auto;
}

.MobileOverlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  z-index: 20;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  align-content: center;
  @media (--lg) {
    display: none;
  }
  & h2 {
    width: 100%;
    display: block;
    color: #fff;
    text-align: center;
  }
}

.Options {
  display: flex;
  & button {
    position: static !important;
    margin-right: 3rem;
  }
  & button:first-child {
  }
  & button:last-child {
    margin-right: 0;
  }
}

.MobileOverlaymore {
  position: static;
}
</style>
