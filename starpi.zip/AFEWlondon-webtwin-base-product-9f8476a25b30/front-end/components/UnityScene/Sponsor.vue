<template>
  <div
    v-if="sponsor"
    :class="{
      [$style.Sponsor]: true,
      [$style.SponsorPanel]: panel,
      [$style.Single]: single,
    }"
  >
    <a
      v-if="sponsorLink"
      target="_blank"
      :data-sponsor="sponsorName"
      :href="sponsorLink"
    >
      <img :src="sponsorImage" />
    </a>
    <img v-else :src="sponsorImage" />
  </div>
</template>

<script>
export default {
  name: 'Sponsor',
  props: {
    sponsor: {
      type: Object,
      default: () => {},
    },
    single: {
      type: Boolean,
      default: false,
    },
    panel: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    sponsorImage() {
      let img
      if (this.sponsor.ref) {
        img = this.sponsor.logo_path
      } else {
        img = this.sponsor?.logo?.data?.full_url || false
      }
      return img
    },
    sponsorLink() {
      return this.sponsor?.link || false
    },
    sponsorName() {
      return this.sponsor?.name || false
    },
  },
}
</script>
<style module lang="postcss">
.Sponsor {
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  transition: transform 0.5s;
  height: 100%;
  & a {
    display: block;
  }
  & img {
    object-fit: contain;
    display: block;
    width: 100%;
    height: auto;
    max-width: 70px;
    /* max-height: 30px; */
    @media (--lg) {
      /* max-width: 80px;
      max-height: 80px; */
    }
  }
}

.SponsorPanel {
  & img {
    max-width: 120px;
    max-height: 120px;
  }
}

.Single {
  & img {
    max-width: 80px;
    max-height: 80px;
    /* object-fix: */
  }
}
</style>
