<template>
  <div :class="$style.CtaContainer">
    <template v-if="externalLink">
      <a
        :href="externalLink"
        target="_blank"
        :class="{ [$style.Cta]: true, [$style.HideHitArea]: invisibleOverlay }"
        :[`data-${gtmType}`]="gtmValue"
        :style="styleObject"
      >
        <div
          :class="$style.Icon"
          :style="{
            borderRadius: ctaBorderRadius,
            background:
              appearance === 'default'
                ? mapTheme.cta_background_color
                : mapTheme.alternate_cta_background_color,
          }"
        ></div>
      </a>
    </template>
    <template v-else>
      <button
        :class="{ [$style.Cta]: true, [$style.HideHitArea]: invisibleOverlay }"
        :[`data-${gtmType}`]="gtmValue"
        :style="styleObject"
        @click="handleCtaClick(activeTranslations.cta_description, cbParams)"
      >
        <div
          :class="$style.Icon"
          :style="{
            borderRadius: ctaBorderRadius,
            background:
              appearance === 'default'
                ? mapTheme.cta_background_color
                : mapTheme.alternate_cta_background_color,
          }"
        >
          <icon-media-panel
            v-if="icon === 'product_panel'"
            :stroke-color="
                appearance === 'default'
                  ? mapTheme.cta_icon_color
                  : mapTheme.alternate_cta_icon_color,
            "
          />
          <icon-media-video
            v-if="icon === 'media-video'"
            :stroke-color="
                appearance === 'default'
                  ? mapTheme.cta_icon_color
                  : mapTheme.alternate_cta_icon_color,
            "
          />
          <icon-media-picture
            v-if="icon === 'media-picture'"
            :stroke-color="
                appearance === 'default'
                  ? mapTheme.cta_icon_color
                  : mapTheme.alternate_cta_icon_color,
            "
          />
        </div>
      </button>
    </template>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import IconMediaPanel from '@/components/_icons/IconMediaPanel'
import IconMediaVideo from '@/components/_icons/IconMediaVideo'
import IconMediaPicture from '@/components/_icons/IconMediaPicture'
export default {
  name: 'CtaOverlay',
  components: {
    IconMediaPanel,
    IconMediaVideo,
    IconMediaPicture,
  },
  props: {
    // icon: {
    //   type: [String, Boolean],
    //   default: 'video',
    // },
    item: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      showMobilePanel: true,
      type: null,
      cbParams: null,
      translations: [],
      top: null,
      left: null,
      width: null,
      height: null,
      bgImage: false,
      gtmType: null,
      gtmValue: null,
      appearance: null,
      externalLink: null,
      showHitArea: false,
      invisibleOverlay: false,
      icon: 'video',
      cb: null,
    }
  },
  mounted() {
    this.top = this.item.top
    this.left = this.item.left
    this.width = this.item.width
    this.height = this.item.height
    this.skew = this.item.skew
    this.bgImage = this.item.cta_background_image?.data?.full_url || false
    this.type = this.item.cta_type
    this.translations = this.item.translations
    this.gtmType = this.item.gtm_tag_type
    this.gtmValue = this.item.gtm_uid
    this.appearance = this.item.cta_appearance
    this.externalLink = this.item.link_url
    this.showHitArea = this.item.show_hit_area
    this.invisibleOverlay = this.item.invisible_overlay || false
    this.icon = this.item.cta_type
    this.cb = this.getCallback(this.type)
    this.cbParams = this.getCallbackParams(this.type)
  },
  computed: {
    ...mapState(['lang', 'mapTheme', 'ctaBorderRadius', 'device']),
    activeTranslations() {
      const translations = this.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
    styleObject() {
      const style = {
        top: `${this.top}%`,
        left: `${this.left}%`,
        width: `${this.width}%`,
        height: `${this.height}%`,
        transform: `skewY(${this.skew}deg)`,
      }
      if (this.bgImage) style.backgroundImage = `url(${this.bgImage})`
      return style
    },
  },
  methods: {
    ...mapActions([
      'setActiveScene',
      'setMobileOverlay',
      'startUnity',
      'unityInstance',
      'setCtaVisibility',
    ]),
    ...mapActions('videoModal', ['setActiveVideoModal']),
    ...mapActions('pictureModal', ['setPictureModal']),
    ...mapActions('infoPanel', ['setInfoPanel']),
    getCallback() {
      let ret = () => {}
      switch (this.type) {
        case 'Category':
          ret = this.handleSceneChange
          break
        case 'Web_Link':
          ret = this.handleExternalLink
          break
        case 'product_panel':
          ret = this.setInfoPanel
          break
        case 'media-video':
          ret = this.setActiveVideoModal
          break
        case 'media-picture':
          ret = this.setPictureModal
          break
      }
      return ret
    },
    getCallbackParams() {
      let ret
      switch (this.type) {
        case 'Category':
          ret = this.item?.unity_scene?.id
          break
        case 'Web_Link':
          break
        case 'product_panel':
          ret = this.item?.info_panel?.id
          break
        case 'media-video':
          ret = this.item?.video_modal?.id
          break
        case 'media-picture':
          ret = this.item?.info_modal?.id
          break
      }
      return ret
    },
    handleExternalLink() {
      window.open(this.externalLink, '_blank')
    },
    handleCtaClick(text, params) {
      if (this.device === 'mobile' && text) {
        this.setMobileOverlay({
          status: true,
          text,
          cb: this.cb,
          params,
        })
      } else {
        this.cb(params)
        this.setMobileOverlay(false)
      }
    },
    handleSceneChange() {
      const target = this.cbParams

      // Only hide CTAs is unity is enabled
      if (this.startUnity) this.setCtaVisibility(false)

      // Dont try to navigate if the target scene has not been defined in the CMS
      if (!target?.scene_url) {
        return
      }

      // Get URL params for navigation
      const projectID = this.$route.params.project_id
      const mapID = this.$route.params.map_id

      // Update URL
      projectID && mapID
        ? this.$router.push({
            path: `/${projectID}/${mapID}/${target?.scene_url}`,
          })
        : this.$router.push({ path: `/${target?.scene_url}` })

      if (this.startUnity) this.$root.$emit('sceneChange', target?.scene_id)
    },
  },
}
</script>
<style module lang="postcss">
.Cta {
  -webkit-appearance: none;
  border: none;
  margin: 0;
  padding: 0;
  cursor: pointer;
  outline: none;
  position: absolute;
  -webkit-appearance: none;
  border: none;
  margin: 0;
  padding: 0;
  opacity: 1;
  pointer-events: auto;
  z-index: 10;
  background-color: #ffffff;
  /* box-shadow: inset 1px 2px 3px rgba(0, 0, 0, 1); */
  background-size: cover;
  background-position: center;
  border: 0.25rem solid #000;
  border-radius: 4px;
  &:hover {
    z-index: 15;
  }
}

.HideHitArea {
  background: transparent;
  border: none;
  & .Icon {
    display: none;
  }
}

.Icon {
  width: 2rem;
  height: 2rem;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translateX(-50%) translateY(-50%);
  display: flex;
  justify-content: center;
  align-items: center;
  & svg {
    stroke-width: 2px;
  }
}
</style>
