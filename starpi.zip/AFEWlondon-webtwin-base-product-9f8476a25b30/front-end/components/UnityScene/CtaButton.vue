<template>
  <div
    :class="{
      [$style.CtaContainer]: true,
      [$style.RestrictWidth]: clampText,
      [$style.HaveDescription]:
        activeTranslations.cta_description || topicPanels.length,
    }"
    :style="{
      top: `${top}%`,
      left: `${left}%`,
    }"
  >
    <button
      :class="$style.Cta"
      :[`data-${gtmType}`]="gtmValue"
      :style="{
        fontFamily: `${fontFamily}`,
        color:
          appearance === 'default'
            ? mapTheme.cta_text_color
            : mapTheme.alternate_cta_text_color,
        background:
          appearance === 'default'
            ? mapTheme.cta_text_background_color
            : mapTheme.alternate_cta_text_background_color,
        borderRadius: ctaBorderRadius,
      }"
      @click.stop="
        handleCtaClick(
          activeTranslations.cta_description,
          getCallbackParams(type),
          topicPanels.length > 1
        )
      "
    >
      <div :class="$style.TruncateText">
        {{ activeTranslations.cta_text || 'no translation' }}
      </div>

      <span
        :class="$style.Icon"
        :style="{
          backgroundColor:
            appearance === 'default'
              ? mapTheme.cta_background_color
              : mapTheme.alternate_cta_background_color,
          borderTopRightRadius: ctaBorderRadius,
          borderBottomRightRadius: ctaBorderRadius,
        }"
      >
        <icon-plus
          :style="{
            stroke:
              appearance === 'default'
                ? mapTheme.cta_icon_color
                : mapTheme.alternate_cta_icon_color,
          }"
        />
      </span>
      <span
        v-if="activeTranslations.cta_description || topicPanels.length > 0"
        :class="$style.Description"
        :style="{
          color:
            appearance === 'default'
              ? mapTheme.cta_description_text_color
              : mapTheme.alternate_cta_description_text_color,
          background:
            appearance === 'default'
              ? mapTheme.cta_description_background_color
              : mapTheme.alternate_cta_description_background_color,
          borderRadius: ctaBorderRadius,
          borderBottomLeftRadius:
            mapTheme.cta_style !== 'square' ? ctaBorderRadius : 0,
          borderTopRightRadius:
            mapTheme.cta_style !== 'square' ? ctaBorderRadius : 0,
          borderBottomRightRadius:
            mapTheme.cta_style !== 'square' ? ctaBorderRadius : 0,
        }"
      >
        <template v-if="!topicPanels.length > 0">
          {{ activeTranslations.cta_description }}
        </template>
        <template v-else>
          <ul :class="$style.SecondaryCtas">
            <li
              v-for="(cta, index) in topicPanels"
              :key="`topic-panel-${index}-${item.id}`"
              role="button"
              @click.stop="handleCtaClick('this is a test', cta.id)"
            >
              {{ getTranslation(cta, 'title') }}
            </li>
          </ul>
        </template>
      </span>
    </button>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import IconPlus from '@/components/_icons/IconPlus'
export default {
  name: 'Cta',
  components: {
    IconPlus,
  },
  props: {
    item: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      showMobilePanel: true,
      top: null,
      left: null,
      cb: null,
      type: null,
      cbParams: null,
      translations: [],
      gtmType: null,
      gtmValue: null,
      appearance: null,
      externalLink: null,
      topicPanels: [],
    }
  },
  computed: {
    ...mapState([
      'lang',
      'mapTheme',
      'ctaBorderRadius',
      'device',
      'unityEnabled',
    ]),
    ...mapGetters(['fontFamily', 'startUnity']),
    activeTranslations() {
      const translations = this.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
    ctaStringLength() {
      return this.activeTranslations?.cta_text?.length || 40
    },
    clampText() {
      return this.item?.truncate_text || false
    },
  },
  mounted() {
    this.top = this.item.top
    this.left = this.item.left
    this.type = this.item.cta_type
    this.translations = this.item.translations
    this.gtmType = this.item.gtm_tag_type
    this.gtmValue = this.item.gtm_uid
    this.appearance = this.item.cta_appearance
    this.externalLink = this.item.link_url
    this.topicPanels = this.item.topic_panels.map((item) => {
      return item.panel
    })
    this.cb = this.getCallback(this.type)
    this.cbParams = this.getCallbackParams(this.type)
  },
  methods: {
    ...mapActions([
      'setActiveScene',
      'setMobileOverlay',
      'unityInstance',
      'setCtaVisibility',
    ]),
    ...mapActions('videoModal', ['setActiveVideoModal']),
    ...mapActions('pictureModal', ['setPictureModal']),
    ...mapActions('infoPanel', ['setInfoPanel']),
    getTranslation(content, field) {
      if (!content?.translations) return
      const translations = content.translations.find(
        (item) => item.language === this.lang
      )
      return translations[field]
    },
    getCallback() {
      let ret = () => {}
      switch (this.type) {
        case 'Category':
          ret = this.handleSceneChange
          break
        case 'Web_Link':
          ret = this.handleExternalLink
          break
        case 'product_panel':
        case 'product_panels':
          ret = this.setInfoPanel
          break
        case 'media-video':
          ret = this.setActiveVideoModal
          break
        case 'media-picture':
          ret = this.setPictureModal
          break
      }
      return ret
    },
    getCallbackParams() {
      let ret
      switch (this.type) {
        case 'Category':
          ret = this.item?.unity_scene
          break
        case 'Web_Link':
          break
        case 'product_panel':
          ret = this.item?.info_panel?.id
          break
        case 'product_panels':
          ret =
            this.topicPanels.length === 1
              ? this.topicPanels[0].id
              : this.topicPanels
          break
        case 'media-video':
          ret = this.item?.video_modal?.id
          break
        case 'media-picture':
          ret = this.item?.info_modal?.id
          break
      }
      return ret
    },
    handleExternalLink() {
      window.open(this.externalLink, 'WebTwin')
    },
    handleCtaClick(content, params, haveTopics) {
      if (
        (this.device === 'mobile' && content) ||
        (this.device === 'mobile' && haveTopics)
      ) {
        this.setMobileOverlay({
          status: true,
          content,
          cb: this.cb,
          params,
        })
      } else if (!haveTopics) {
        this.cb(params)
        this.setMobileOverlay(false)
      }
      if (this.device !== 'mobile' && !haveTopics) {
        this.cb(params)
        this.setMobileOverlay(false)
      }
    },
    handleSceneChange() {
      const target = this.cbParams

      // Only hide CTAs is unity is enabled
      if (this.startUnity) this.setCtaVisibility(false)

      // Dont try to navigate if the target scene has not been defined in the CMS
      if (!target?.scene_url) {
        console.warn('NO TARGET SCENE SET')
        return
      }

      // Get URL params for navigation
      const projectID = this.$route.params.project_id
      const mapID = this.$route.params.map_id

      // Update URL
      projectID && mapID
        ? this.$router.push({
            path: `/${projectID}/${mapID}/${target?.scene_url}`,
          })
        : this.$router.push({ path: `/${target?.scene_url}` })

      this.$root.$emit('sceneChange', target?.scene_id)
    },
  },
}
</script>
<style module lang="postcss">
.CtaContainer {
  position: absolute;
  z-index: 10;
  &:hover {
    z-index: 15;
  }
}

.Cta {
  font-weight: 400;
  color: var(--c-brand);
  -webkit-appearance: none;
  border: none;
  margin: 0;
  padding: 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  font-size: 0.9rem;
  line-height: 1.2;
  padding-left: 0.5rem;
  outline: none;
  background: #fff;
  pointer-events: auto;
  border-top-left-radius: 4px;
  border-top-right-radius: 8px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 8px;
  oveflow: hidden;
  box-shadow: 0px 0px 16px 0px rgba(0, 0, 0, 0.15);
  text-decoration: none;
  text-align: left;
  white-space: nowrap;

  &:hover {
    background: #f2f2f2;
  }
  @media (--lg) {
    font-size: 1rem;
  }
}

.RestrictWidth .Cta {
  width: 100%;
  max-width: 280px;
  white-space: inherit;
}

.HaveDescription {
  @media (--lg) {
    & .Cta {
      &:hover {
        border-bottom-left-radius: 0 !important;
        & .Icon {
          border-bottom-right-radius: 0 !important;
        }
        & .Description {
          display: block;
        }
      }
    }
  }
}

.Icon {
  align-self: flex-start;
  background: var(--c-brand);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 0.5rem;
  padding: 0;
  height: 100%;
  & svg {
    stroke: #fff;
    width: 1.25rem;
    height: 1.25rem;
  }
}

.Description {
  position: absolute;
  font-size: 1rem;
  text-transform: none;
  background: #fff;
  top: 100%;
  left: 0;
  width: calc(100% + 60px);
  min-width: 180px;
  text-align: left;
  padding: 0.5rem;
  font-weight: normal;
  font-size: 0.9rem;
  display: none;
  line-height: 1.2;
  border-top-left-radius: 0 !important;
  display: none;
  white-space: initial;
}

.TruncateText {
  line-height: 1.2rem;
  position: relative;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.SecondaryCtas {
  margin: 0;
  padding: 0;
  list-style: none;
  & li {
    margin-bottom: 0.5rem;
    &:hover {
      text-decoration: underline;
    }
    &:last-child {
      margin-bottom: 0;
    }
  }
}
</style>
