<template>
  <section
    ref="fullscreen"
    :class="{
      [$style.UnityScene]: true,
      [$style.Fullscreen]: isFullscreen,
      ['u-fs']: isFullscreen,
    }"
  >
    <div
      :class="{
        [$style.UnitySceneInner]: true,
        [$style.StaticMap]: !startUnity,
      }"
    >
      <!-- Hidden div enabling scroll on Unity canvas -->
      <div :class="$style.ScrollOverlay" />

      <!-- Scene sponsors -->
      <transition name="fade">
        <sponsor-zone-scene
          v-show="!loading && !overlayActive && !mobileOverlayVisible"
          :sponsors="sponsors"
          :class="$style.SponsorZone"
        />
      </transition>

      <!-- Logo & Unity breadcrumb bar -->
      <breadcrumb
        v-show="!loading && !mobileOverlayVisible"
        :unity-instance="unityInstance"
        :class="$style.Breadcrumb"
      />

      <!-- Only render the actual Unity scene in the client -->
      <div
        v-if="unityVersion === '2020.1'"
        id="unity-container"
        :class="[$style.UnityContainer]"
      >
        <canvas id="unity-canvas" ref="unityCanvas"></canvas>
      </div>

      <unity
        v-if="
          unityJson && unityLoader && startUnity && unityVersion === '2019.2'
        "
        ref="unityInstance"
        :src="unityJson"
        :unity-loader="unityLoader"
        :external-progress="handleUnityProgress"
        :class="$style.Unity"
      />
      <div
        v-if="!startUnity"
        :class="$style.NoUnityBg"
        :style="
          staticBgImage ? { backgroundImage: `url(${staticBgImage})` } : null
        "
      >
        <template v-if="activeScene">
          {{ activeScene.scene_name }} - {{ activeScene.scene_id }}
        </template>
      </div>

      <!-- Side Panel close overlay -->
      <div
        v-if="overlayActive && !mobileOverlayVisible"
        :class="$style.UiCloser"
        @click="handleUiClose"
      />

      <!-- The HTML overlay - CTA's, hit areas etc. -->
      <overlay
        v-show="!loading"
        :unity-instance="unityInstance"
        :class="$style.Overlay"
      />

      <!-- A list of social buttons -->
      <social-links
        v-show="!loading && !mobileOverlayVisible"
        :class="$style.Social"
      />

      <!-- Generic video modal overlay -->
      <video-modal v-if="videoModal" />

      <!-- Generic video modal overlay -->
      <picture-modal v-if="pictureModal" />

      <!-- Side Panels -->
      <transition name="slide">
        <side-panel v-if="infoPanel" />
      </transition>

      <!-- External links component -->
      <transition name="fade">
        <external-links
          v-show="!loading"
          :contact-link-gtm-uid="activeMap.contact_link_gtm_uid"
          :external-link-gtm-uid="activeMap.external_link_gtm_uid"
          :class="$style.ExternalLinks"
        />
      </transition>

      <!-- Unity loading screen/panel -->
      <transition name="fade">
        <loading-screen
          v-if="loading && !showWebGlMsg"
          :progress="loadingProgress"
        />
      </transition>

      <!-- Prompt mobile users to rotate to landscape -->
      <portrait-rotate-prompt />

      <!-- Keybindings (hide UI by pressing "o") -->
      <client-only>
        <global-events @keyup.o="handleHideInterface" />
      </client-only>
    </div>
  </section>
</template>
<script>
import { mapState, mapActions, mapGetters } from 'vuex'
import Unity from 'vue-unity-webgl'
import Overlay from '@/components/UnityScene/Overlay'
import Breadcrumb from '@/components/UnityScene/Breadcrumb'
import SocialLinks from '@/components/UnityScene/SocialLinks'
import VideoModal from '@/components/UnityScene/VideoModal'
import PictureModal from '@/components/UnityScene/PictureModal'
import ExternalLinks from '@/components/UnityScene/ExternalLinks'
import LoadingScreen from '@/components/UnityScene/LoadingScreen'
import SponsorZoneScene from '@/components/UnityScene/SponsorZoneScene'
import PortraitRotatePrompt from '@/components/UnityScene/PortraitRotatePrompt'
import SidePanel from '@/components/UnityScene/SidePanel'

export default {
  name: 'UnityContainer',
  components: {
    Unity,
    Overlay,
    Breadcrumb,
    SocialLinks,
    VideoModal,
    PictureModal,
    LoadingScreen,
    ExternalLinks,
    SponsorZoneScene,
    PortraitRotatePrompt,
    SidePanel,
  },
  data() {
    return {
      unityInstance: false,
      isFullscreen: false,
      loadingProgress: 0,
      initialLoad: true,
      hideInterface: false,
      initialScene: null,
      scenes: [],
      ctas: [],
    }
  },

  computed: {
    ...mapState([
      'activeMap',
      'activeScene',
      'allScenes',
      'initialUnityScene',
      'loading',
      'activeSidePanel',
      'showWebGlMsg',
      'mapTheme',
      'unityEnabled',
      'webGlSupport',
      'mobileOverlayVisible',
    ]),
    ...mapState('pictureModal', ['pictureModal']),
    ...mapState('videoModal', ['videoModal']),
    ...mapState('infoPanel', ['infoPanel']),
    ...mapGetters(['startUnity', 'overlayActive', 'activeCtas']),
    sponsors() {
      return this.activeScene?.sponsors.map((item) => {
        return item.sponsor
      })
    },
    unityJson() {
      return this.activeMap?.unity_json?.data?.full_url || false
    },
    unityData() {
      return this.activeMap?.unity_data?.data?.full_url || false
    },
    unityLoader() {
      return this.activeMap?.unity_loader?.data?.full_url || false
    },
    unityCode() {
      return this.activeMap?.unity_wasm_code?.data?.full_url || false
    },
    unityFramework() {
      return this.activeMap?.unity_wasm_framework?.data?.full_url || false
    },
    staticBgImage() {
      return this.activeScene?.static_image?.data?.full_url
    },
    sceneID() {
      return this.$route.params?.scene_id || false
    },
    disableSceneManagement() {
      return this.activeMap?.disable_unity_scene_management || false
    },
    singleScene() {
      return this.activeMap?.unity_scenes?.length === 1
    },
    cacheBuster() {
      return `v=${Math.floor(Math.random() * 100 + 1)}`
    },
    unityVersion() {
      return this.activeMap?.unity_version || '2019.2'
    },
  },

  watch: {
    $route(to, from) {
      this.handleRouteChange(to, from)
    },
  },
  async mounted() {
    try {
      const response = await this.$client.getItems('unity_scenes', {
        fields: [
          '*',
          'scene_ctas.cta.*.*.*',
          'scene_ctas.cta.translations.*.*',
          'scene_ctas.cta.topic_panels.panel.*.*.*',
          'static_image.*',
          'sponsors.*.*.*',
        ],
        status: 'published',
        filter: {
          'maps.map.uid': this.$store.state.mapID,
        },
      })

      // Store all scenes
      const scenes = response.data
      this.setAllScenes(scenes)

      // Get the initial scene
      const initialScene = scenes.find((item) => {
        return item.is_landing_scene
      })

      // Set the initial scene
      if (initialScene) this.setInitialScene(initialScene)

      // Activate loading state
      this.handleLoadingState(true)

      const webAssemblySupported = (() => {
        try {
          if (
            typeof WebAssembly === 'object' &&
            typeof WebAssembly.instantiate === 'function'
          ) {
            const module = new WebAssembly.Module(
              // eslint-disable-next-line
              Uint8Array.of(0x0, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00)
            )
            if (module instanceof WebAssembly.Module)
              return (
                new WebAssembly.Instance(module) instanceof WebAssembly.Instance
              )
          }
        } catch (e) {}
        return false
      })()

      // Check if the browser supports WebGL and can run Unity
      const hasWebGL = (function () {
        if (!window.WebGLRenderingContext) {
          // Browser has no idea what WebGL is. Suggest they
          // get a new browser by presenting the user with link to
          // http://get.webgl.org
          return false
        }
        // Query canvas methods to figure out what the deal is
        const canvas = document.createElement('canvas')
        const gl = canvas.getContext('webgl')
        if (!gl) {
          // Browser could not initialize WebGL. User probably needs to
          // update their drivers or get a new browser. Present a link to
          // http://get.webgl.org/troubleshooting
          return false
        }
        return true
      })()

      // Set WebGL support flag
      this.setWebGlSupport(hasWebGL && webAssemblySupported)

      // if unity is switched off or not supported then dont bother with the
      // Unity events stuff
      if (!this.startUnity || !hasWebGL || !webAssemblySupported) {
        this.loadingProgress = 1
        this.$nextTick(() => {
          this.handleLoadingState(false)
          this.initStaticMap()
        })
        return
      }

      // Called on Unity scene change. Hides loading screen on initial load
      window.changeSceneCallback = (e) => {
        this.handleLoadingState(false)
        this.setCtaVisibility(true)
        this.initialLoad = false
      }

      // Called once Unity has instatiated
      // TODO: remove - dont think we need this now we're using a promise
      window.getReady = () => {
        this.unityInstance = this.$refs?.unityInstance?.gameInstance
        if (this.unityInstance) this.initUnityMap()
      }

      if (this.unityVersion === '2020.1') {
        const loaderUrl = `${this.unityLoader}`
        const config = {
          dataUrl: this.unityData,
          frameworkUrl: this.unityFramework,
          codeUrl: this.unityCode,
          streamingAssetsUrl: 'StreamingAssets',
          companyName: 'Immersionn',
          productName: 'WebTwin',
          productVersion: '1',
        }

        const canvas = this.$refs.unityCanvas

        const script = document.createElement('script')
        script.src = loaderUrl
        script.onload = () => {
          window
            .createUnityInstance(canvas, config, (progress) => {
              this.loadingProgress = progress
            })
            .then((unityInstance) => {
              this.unityInstance = unityInstance
              // TODO: maybe remove? needed in prod?
              window.gameInstance = unityInstance
              if (this.unityInstance) this.initUnityMap()

              // fullscreenButton.onclick = () => {
              //   unityInstance.SetFullscreen(1)
              // }
            })
            .catch((message) => {
              console.error('ERROR LOADING UNITY SCRIPT', message)
            })
        }
        // TODO: make sure this never gets added twice?
        // TODO: check for script ID, then remove/add if present?
        document.body.appendChild(script)
      }
    } catch (err) {
      console.error('ERROR fetching scenes', err)
    }
  },
  methods: {
    ...mapActions([
      'handleLoadingState',
      'setActiveScene',
      'closeSidePanel',
      'closeVideoPanel',
      'closeInfoPanel',
      'setWebGlSupport',
      'setInitialScene',
      'setCtaVisibility',
      'setAllScenes',
    ]),

    // Start a Unity map
    initUnityMap() {
      // Hide CTAs initially - unity callback will show them
      if (this.startUnity) this.setCtaVisibility(false)

      // If we only have once scene then the initial scene is the starting point
      if (this.singleScene && this.disableSceneManagement) {
        this.setActiveScene(this.initialUnityScene)
      }

      // If we have a URL param then try to load the relevant scene
      else if (this.sceneID) {
        const activeScene = this.allScenes.find((item) => {
          return item.scene_url === this.sceneID
        })

        // Check if we have a scene to move to before moving
        if (activeScene) {
          // Send message to Unity instance
          this.unityInstance.SendMessage(
            'SceneMgmt',
            'changeScene',
            activeScene.scene_id
          )
          // Store active scene data
          // TODO: check where this is used, then store locally if possible
          this.setActiveScene(activeScene)
        }
      }

      // No URL param and multiple scenes - load the initial scene
      else {
        this.unityInstance.SendMessage(
          'SceneMgmt',
          'changeScene',
          this.initialUnityScene.scene_id
        )
        this.setActiveScene(this.initialUnityScene)
      }
    },

    // Start a static map using just background images - no Unity
    initStaticMap() {
      // SHow CTAs
      this.setCtaVisibility(true)

      // Set the initial scene
      if (this.singleScene && this.disableSceneManagement) {
        this.setActiveScene(this.initialUnityScene)
      } else if (this.sceneID) {
        const activeScene = this.allScenes.find((item) => {
          return item.scene_url === this.sceneID
        })
        this.setActiveScene(activeScene)
      } else {
        this.setActiveScene(this.initialUnityScene)
      }
    },

    // Handle Unity loading progress
    // TODO: remove - deprecated
    handleUnityProgress(gameInstance, progress) {
      this.loadingProgress = progress
    },

    // Take the map full screen
    toggleFullscreen() {
      this.$fullscreen.toggle(this.$refs.fullscreen, {
        wrap: false,
        callback: this.fullscreenChange,
      })
    },

    // React to changes in fullscreen state
    fullscreenChange(fullscreen) {
      this.isFullscreen = fullscreen
    },

    // Generic UI overlay close handler
    handleUiClose() {
      // if (this.activeSidePanel) this.closeSidePanel()
      // if (this.activeVideoPanel) this.closeVideoPanel()
      // if (this.activeInfoPanel) this.closeInfoPanel()
    },

    // Press "o" to hide the UI overlay. Useful for screenshots
    handleHideInterface() {
      this.hideInterface = !this.hideInterface
    },

    handleRouteChange(to, from) {
      if (!to.params.scene_id) {
        if (!this.activeScene.is_landing_scene) {
          if (this.startUnity) {
            this.setCtaVisibility(false)
            this.unityInstance.SendMessage(
              'SceneMgmt',
              'changeScene',
              this.initialUnityScene.scene_id
            )
          }
          this.setActiveScene(this.initialUnityScene)
        }
      } else if (to.params.scene_id !== this.activeScene.scene_url) {
        const scene = this.allScenes.find((item) => {
          return item.scene_url === to.params.scene_id
        })
        if (this.startUnity) {
          this.setCtaVisibility(false)
          this.unityInstance.SendMessage(
            'SceneMgmt',
            'changeScene',
            scene.scene_id
          )
        }
        this.setActiveScene(scene)
      }
    },
  },
}
</script>
<style module lang="postcss">
.UnityScene {
  position: relative;
  background: transparent;
  overflow: hidden;
  & :global(.footer) {
    position: absolute;
    bottom: 0;
    right: 0;
  }
}

.UnitySceneInner {
  position: relative;
  width: 100%;
  max-width: 100vw;
  /* max-height: 100vh; */
  background: #fff;
  display: flex;
  align-items: center;
  height: 50.25vw;
  max-height: 642px;
  @media (--portrait) {
    @media (--md) {
      min-height: auto;
    }
  }
}

.UnityContainer {
  width: 100%;
  height: 100%;
  & canvas {
    width: 100%;
    height: 100%;
  }
}
.StaticMap {
  padding-bottom: 52%;
}

.Fullscreen {
  padding-bottom: 0;
  display: flex;
  align-items: center;
  & .Unity {
    height: 100%;
  }
}

.Unity {
  width: 100%;

  & > div {
    height: 100%;
  }
  & canvas {
    background: #fff;
  }
  /* Hide weird fullscreen footer */
  & :global(.footer) {
    display: none;
  }
}

.Breadcrumb {
}

.FullScreenCta {
  position: absolute;
  bottom: 0.5rem;
  right: 0.5rem;
  width: 2.5rem;
  height: 2.5rem;
  padding: 0.35rem;

  & svg {
    width: auto;
    height: auto;
    max-height: 100%;
    max-width: 100%;
    object-fit: contain;
  }
}

.ExternalLinks {
  position: absolute;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
}

.UiCloser {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  backdrop-filter: blur(3px);
}

.Overlay {
  /* position: relative; */
}

.SponsorZone {
  position: absolute;
  bottom: 0.5rem;
  right: 0.5rem;
  max-width: 30%;
  left: auto;
}

.NoUnityBg {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background: #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  background-size: cover;
  background-position: center;
}

.Unity {
  z-index: 0;
}

.ScrollOverlay {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 2;
}

.UiCloser {
  z-index: 4;
}

.ExternalLinks {
  z-index: 10;
}

.SponsorZone,
.Social,
.FullScreenCta,
.Overlay {
  z-index: 3;
}

.Breadcrumb {
  z-index: 5;
}

.HideInterface {
  & .Breadcrumb,
  & .ExternalLinks,
  & .SponsorZone,
  & .Social,
  & .FullScreenCta,
  & .Overlay {
    display: none;
  }
}
</style>
