<template>
  <nav :class="$style.SocialLinks">
    <component :is="'style'">
      .social-cta svg path { fill: {{ mapTheme.cta_icon_color }} }
    </component>
    <a
      v-if="activeTranslations.show_facebook"
      :href="activeTranslations.facebook"
      :class="[$style.Cta, 'social-cta']"
      target="_blank"
      data-cta="Facebook"
      :style="{
        background: mapTheme.cta_background_color,
        borderRadius: ctaBorderRadius,
      }"
    >
      <icon-facebook :style="{ fill: mapTheme.cta_background_color }" />
    </a>
    <a
      v-if="activeTranslations.show_twitter"
      :href="activeTranslations.twitter"
      :class="[$style.Cta, 'social-cta']"
      target="_blank"
      data-cta="Twitter"
      :style="{
        background: mapTheme.cta_background_color,
        borderRadius: ctaBorderRadius,
      }"
    >
      <icon-twitter :style="{ fill: mapTheme.cta_background_color }" />
    </a>
    <a
      v-if="activeTranslations.show_linkedin"
      :href="activeTranslations.linked_in"
      :class="[$style.Cta, 'social-cta']"
      target="_blank"
      data-cta="LinkedIn"
      :style="{
        background: mapTheme.cta_background_color,
        borderRadius: ctaBorderRadius,
      }"
    >
      <icon-linked-in :style="{ fill: mapTheme.cta_background_color }" />
    </a>
  </nav>
</template>

<script>
import { mapState } from 'vuex'
import IconFacebook from '@/components/_icons/IconFacebook'
import IconTwitter from '@/components/_icons/IconTwitter'
import IconLinkedIn from '@/components/_icons/IconLinkedIn'

export default {
  name: 'UnityScene',
  components: {
    IconFacebook,
    IconTwitter,
    IconLinkedIn,
  },
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme', 'ctaBorderRadius']),
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },
}
</script>
<style module lang="postcss">
.SocialLinks {
  position: absolute;
  bottom: 0;
  left: 0;
  padding: 0.5rem;
  display: flex;
  &:fullscreen {
    padding: 1rem;
  }
}
.Cta {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0;
  padding: 0.5rem;
  cursor: pointer;
  outline: none;
  background: transparent;
  pointer-events: auto;
  background: #fff;
  border-radius: 10px;
  margin-right: 0.5rem;
  width: 2rem;
  height: 2rem;
  &:hover {
  }
  & svg {
    display: block;
    width: auto;
    height: auto;
    max-height: 100%;
    max-width: 100%;
    object-fit: contain;
  }
}
</style>
