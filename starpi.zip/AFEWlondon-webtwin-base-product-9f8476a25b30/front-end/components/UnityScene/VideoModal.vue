<template>
  <section :class="$style.VideoModal">
    <vue-plyr
      v-if="content"
      ref="player"
      :class="{ [$style.VideoPlayer]: true, [$style.IsIframe]: true }"
    >
      <template v-if="activeTranslations.video_type === 'upload'">
        <video :src="videoURL" />
      </template>
      <template v-if="activeTranslations.video_type === 'embed'">
        <div :class="$style.VideoPlayerIframe">
          <iframe
            :src="`https://www.youtube.com/embed/${youtubeId}?origin=https://plyr.io&amp;iv_load_policy=3&amp;modestbranding=1&amp;playsinline=1&amp;autoplay=1&amp;showinfo=0&amp;rel=0&amp;enablejsapi=1`"
            allowfullscreen
            allowtransparency
            allow="autoplay"
          />
        </div>
      </template>
      <cta
        :class="$style.CloseCta"
        :icon="'close'"
        @click.native="handleCloseModal"
      />
    </vue-plyr>
    <div v-if="!content && error" :class="$style.NoContent">
      No content found
      <div>
        <cta :class="$style.CloseCtaError" @click.native="handleCloseModal">
          back
        </cta>
      </div>
    </div>
  </section>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import Cta from '@/components/Cta'

export default {
  name: 'VideoModal',
  components: {
    Cta,
  },
  data() {
    return {
      content: null,
      error: false,
    }
  },
  computed: {
    ...mapState(['lang']),
    ...mapState('videoModal', ['videoModal']),
    videoURL() {
      let ret
      if (this.activeTranslations.video_type === 'upload') {
        ret = this.activeTranslations?.video_upload?.data?.full_url || null
      }
      return ret
    },
    youtubeId() {
      let ret = false
      if (this.activeTranslations.video_type === 'embed') {
        ret = this.activeTranslations?.youtube_id || false
      }
      return ret
    },
    activeTranslations() {
      const translations = this.content.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },

  async mounted() {
    try {
      const response = await this.$client.getItems('video_modals', {
        fields: ['*', 'translations.*'],
        single: true,

        status: 'published',
        filter: {
          id: this.videoModal,
        },
      })
      this.content = response.data
      const plyr = this.$refs.player
      if (plyr && plyr.player) plyr.player.play()
    } catch (err) {
      console.error(err)
      this.error = true
    }
  },

  methods: {
    ...mapActions('videoModal', ['setActiveVideoModal']),
    handleCloseModal() {
      this.setActiveVideoModal(false)
    },
  },
}
</script>
<style module lang="postcss">
.VideoModal {
  pointer-events: auto;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #fff;
  z-index: 6;
  @media (--fullscreen) {
    background: transparent;
    padding: 0 1rem;
  }

  @media (--lg) {
    background: transparent;
  }
}

.VideoPlayer {
  width: 100%;
  height: 100%;
  pointer-events: auto;
  position: relative;
  background: #fff;
  & video,
  & iframe {
    width: 100%;
    height: 100%;
    /* object-fit: contain; */
  }
  & :global(.plyr--video .plyr__control.plyr__tab-focus),
  & :global(.plyr--video .plyr__control):hover,
  & :global(.plyr--video .plyr__control[aria-expanded='true']),
  & :global(.plyr__control--overlaid),
  & :global(.plyr__control--overlaid):hover {
    background: var(--c-brand);
  }
  & :global(.plyr--full-ui input[type='range']) {
    color: var(--c-brand);
  }
  @media (--fullscreen) {
    @media (--sm) {
      background: transparent;
      max-width: 600px;
      height: auto;
    }
  }
  @media (--lg) {
    max-width: 800px;
    height: auto;
  }
  @media (--xl) {
    max-width: 900px;
  }
}

.IsIframe {
  & .VideoPlayerIframe {
    padding-bottom: 56.25%;
    & iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  }
}

.VideoPlayerIframe {
  width: 100%;
  height: 100%;
}

.CloseCta {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  z-index: 100;
  z-index: 10;
  @media (--lg) {
    top: 0;
    right: 0;
    transform: translateX(calc(100% + 1rem));
  }
}
.NoContent {
  background: #fff;
  padding: 1rem;
}
.CloseCtaError {
  position: static;
  margin: auto;
  margin-top: 1rem;
}
</style>
