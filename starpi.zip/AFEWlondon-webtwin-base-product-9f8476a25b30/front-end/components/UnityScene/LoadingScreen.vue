<template>
  <section
    :class="{
      [$style.LoadingScreen]: true,
      [$style.WithGradient]: showGradient,
    }"
  >
    <div
      :class="$style.BackgroundImage"
      :style="
        backgroundImage
          ? {
              backgroundColor: backgroundColor,
              backgroundImage: `url(${backgroundImage})`,
            }
          : { backgroundColor: backgroundColor }
      "
    />
    <div :class="$style.Content">
      <div :class="$style.ProgressBar">
        <span
          :class="$style.ProgressInner"
          :style="{
            width: `${progress * 100}%`,
            background: mapTheme.brand_color,
          }"
        />
        <span :class="[$style.ProgressReadout, 'u-custom-font']">
          {{ Math.round(progress * 100, 2) }}%
        </span>
      </div>
      <header :class="[$style.Header, 'u-custom-font']">
        <h2 v-if="loadingIntro">{{ loadingIntro }}</h2>
      </header>
      <footer :class="$style.Footer">
        <p v-if="loadingDescription" :class="$style.LoadingDescription">
          {{ loadingDescription }}
        </p>
      </footer>
    </div>
  </section>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  name: 'LoadingScreen',
  props: {
    progress: {
      type: Number,
      default: 0,
    },
  },
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme', 'unityEnabled']),
    backgroundImage() {
      return (
        this.mapTheme?.loading_screen_background_image?.data?.full_url || false
      )
    },
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
    backgroundColor() {
      return this.mapTheme?.loading_screen_background_color || 'auto'
    },
    loadingIntro() {
      return this?.activeTranslations?.loading_screen_title || false
    },
    loadingDescription() {
      return this?.activeTranslations?.loading_screen_content || false
    },
    showGradient() {
      return this?.mapTheme?.show_loading_screen_gradient || false
    },
  },
  mounted() {},
  methods: {
    ...mapActions(['showWebGlMessage']),
  },
}
</script>

<style module lang="postcss">
.LoadingScreen {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background: #fff;
  z-index: 15;
}

.BackgroundImage {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-size: cover;
  background-position: center;
}

.Content {
  position: relative;
  z-index: 1;
  height: 100%;
  width: 65%;
  padding: 2rem 1rem;
  padding-right: 15%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  @media (--lg) {
    justify-content: flex-start;
  }
}

.WithGradient .Content {
  background: linear-gradient(
    to right,
    rgba(0, 0, 0, 0.85) 0%,
    rgba(0, 0, 0, 0) 100%
  );
}
.Header {
  color: #fff;
  & h2 {
    margin-top: 1.5rem;
    margin-bottom: 0;
    & + p {
      margin-top: 0;
    }
  }
}

.Footer {
  color: #fff;
  white-space: pre-line;
  font-size: 0.9rem;
  & p:first-child {
    margin-top: 0;
  }
}

.LoadingDescription {
  display: none;
  @media (--lg) {
    display: block;
  }
}

.ProgressBar {
  height: 1.5rem;
  background: #fff;
  position: relative;
  border-radius: 8px;
  margin-bottom: 0;
  display: flex;
  max-width: 260px;
}

.ProgressInner {
  width: 40%;
  height: 100%;
  background: var(--c-brand);
  border-radius: 8px;
  transition: width 0.2s;
}

.ProgressReadout {
  position: absolute;
  top: 50%;
  right: 0;
  transform: translateX(100%) translateY(-50%);
  padding-left: 0.5rem;
  font-size: 0.8rem;
  color: #fff;
}
</style>
