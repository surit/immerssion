<template>
  <section
    :class="{
      [$style.SponsorZone]: true,
      [$style.SingleSponsor]: sponsors.length === 1,
    }"
  >
    <template v-for="(item, index) in sponsors">
      <sponsor
        :class="$style.Sponsor"
        :key="`sponsor-${index}`"
        :sponsor="item"
        :single="sponsors.length === 1"
      />
    </template>
  </section>
</template>

<script>
import Sponsor from '@/components/UnityScene/Sponsor'
export default {
  name: 'SponsorZone',
  components: {
    Sponsor,
  },
  props: {
    sponsors: {
      type: Array,
      default: () => [],
    },
  },
}
</script>
<style module lang="postcss">
.SponsorZone {
  display: flex;
  grid-template-columns: 1fr 1fr 1rf 1rf;
  grid-auto-rows: 1fr 1fr;
  grid-gap: 1rem;
  justify-content: center;
  @media (--lg) {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-auto-rows: 1fr 1fr;
    grid-gap: 1rem;
    margin-top: 1rem;
    justify-items: end;
  }
}

.SingleSponsor {
  display: flex;
}

.Sponsor {
  margin: 0 0.5rem;
  @media (--lg) {
    margin: 0;
  }
}
</style>
