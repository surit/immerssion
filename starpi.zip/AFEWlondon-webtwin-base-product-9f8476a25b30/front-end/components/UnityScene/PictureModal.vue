<template>
  <section v-if="content" :class="$style.Modal">
    <div :class="$style.Infographic">
      <cta
        :class="$style.CloseCta"
        :icon="'close'"
        @click.native="handleCloseModal"
      />
      <img v-if="imageUrl" :src="imageUrl" />
    </div>
  </section>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import Cta from '@/components/Cta'

export default {
  name: 'PictureModal',
  components: {
    Cta,
  },
  data() {
    return {
      content: null,
    }
  },
  computed: {
    ...mapState(['lang']),
    ...mapState('pictureModal', ['pictureModal']),
    imageUrl() {
      return this.activeTranslations?.infographic?.data?.full_url || false
    },
    activeTranslations() {
      const translations = this.content.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
  },
  async mounted() {
    try {
      const response = await this.$client.getItems('info_modals', {
        fields: ['*', 'translations.*.*'],
        single: true,
        status: 'published',
        filter: {
          id: this.pictureModal,
        },
      })
      this.content = response.data
    } catch (err) {
      console.error(err)
    }
  },

  methods: {
    ...mapActions('pictureModal', ['setPictureModal']),
    handleCloseModal() {
      this.setPictureModal(false)
    },
  },
}
</script>
<style module lang="postcss">
.Modal {
  pointer-events: auto;
  width: 100%;
  height: 100%;
  position: absolute;
  z-index: 6;

  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
  background: #fff;
  @media (--fullscreen) {
    background: transparent;
    padding: 0 1rem;
  }
  @media (--lg) {
    background: transparent;
  }
}

.Infographic {
  width: 100%;
  height: 100%;
  pointer-events: auto;
  position: relative;
  padding: 1rem;
  background: #fff;
  & img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  @media (--lg) {
    & img {
      max-height: 400px;
    }
  }

  @media (--fullscreen) {
    @media (--sm) {
      max-width: 600px;
      height: auto;
    }
  }
  @media (--lg) {
    max-width: 800px;
    height: auto;
  }
  @media (--xl) {
    max-width: 900px;
  }
}

.CloseCta {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  z-index: 1;
  @media (--lg) {
    top: 0;
    right: 0;
    transform: translateX(calc(100% + 1rem));
  }
}
</style>
