<template>
  <nav :class="$style.ExternalLinks">
    <ul>
      <li
        v-if="activeMap.show_contact_link"
        :style="{
          background: mapTheme.cta_text_background_color,
        }"
      >
        <span
          :class="$style.Icon"
          :style="{
            backgroundColor: mapTheme.link_block_background_color,
            borderTopLeftRadius: ctaBorderRadius,
            borderBottomLeftRadius: ctaBorderRadius,
          }"
        >
          <img :src="contactLinkIcon" />
        </span>
        <a :href="contactLinkUrl" :data-link="contactLinkGtmUid">
          <span
            :class="$style.Label"
            :style="{
              color: mapTheme.cta_text_color,
              background: mapTheme.cta_text_background_color,
            }"
          >
            {{ contactLinkText }}
          </span>
        </a>
      </li>
      <li
        v-if="activeMap.show_external_link"
        :style="{ background: mapTheme.cta_text_background_color }"
      >
        <span
          :class="$style.Icon"
          :style="{
            backgroundColor: mapTheme.link_block_background_color,
            borderTopLeftRadius: ctaBorderRadius,
            borderBottomLeftRadius: ctaBorderRadius,
          }"
          ><img :src="externalLinkIcon"
        /></span>
        <a :href="externalLinkUrl" :data-link="externalLinkGtmUid">
          <span
            :class="$style.Label"
            :style="{
              color: mapTheme.cta_text_color,
              background: mapTheme.cta_text_background_color,
            }"
          >
            {{ externalLinkText }}
          </span>
        </a>
      </li>
    </ul>
  </nav>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'ExternalLinks',
  props: {
    contactLinkGtmUid: {
      type: String,
      default: '',
    },
    externalLinkGtmUid: {
      type: String,
      default: '',
    },
  },
  computed: {
    ...mapState(['activeMap', 'lang', 'mapTheme', 'ctaBorderRadius']),
    activeTranslations() {
      const translations = this.activeMap.translations.find(
        (item) => item.language === this.lang
      )
      return translations || false
    },
    contactLinkIcon() {
      return this.mapTheme?.contact_link_icon?.data?.full_url || false
    },
    contactLinkUrl() {
      return this.activeTranslations?.contact_link_url || false
    },
    contactLinkText() {
      return this.activeTranslations?.contact_link_text || 'no translation'
    },
    externalLinkIcon() {
      return this.mapTheme?.external_link_icon?.data?.full_url || false
    },
    externalLinkUrl() {
      return this.activeTranslations?.external_link_url || false
    },
    externalLinkText() {
      return this.activeTranslations?.external_link_text || 'no translation'
    },
  },
  mounted() {},
  methods: {},
}
</script>
<style module lang="postcss">
.ExternalLinks {
  & ul {
    margin: 0;
    padding: 0;
    & li {
      margin: 0;
      padding: 0;
      transform: translateX(100%);
      margin-bottom: 1px;
      transition: transform 0.5s ease;
      cursor: pointer;
      display: flex;
      align-items: center;
      /* background: #fff; */
      &:before {
        display: none;
      }
      & a {
        text-decoration: none;
        flex-grow: 1;
        padding: 0 1rem 0 0.5rem;
        height: 100%;
      }
      &:last-child {
        margin-bottom: 0;
      }
      &:hover {
        transform: translateX(0);
      }
    }
  }
}

.Icon {
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--c-grey);
  padding: 0.5rem;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
  margin-left: -2.5rem;
  width: 2.5rem;
  height: 2.5rem;
  padding: 0.35rem;
  & img {
    display: block;
    stroke-width: 1.5;
    width: 1.25rem;
    height: 1.25rem;
    max-height: 100%;
    max-width: 100%;
    object-fit: contain;
  }
}

.Label {
  /* padding: 0.5rem 2rem 0.5rem 0.5rem; */
  flex-grow: 1;
}
</style>
