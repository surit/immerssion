import DirectusSDK from '@directus/sdk-js'

export const client = new DirectusSDK({
  url: process.env.DIRECTUS_URL,
  project: process.env.DIRECTUS_UID,
})
