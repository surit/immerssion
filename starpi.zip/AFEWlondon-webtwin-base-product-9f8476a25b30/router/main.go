package main

import (
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/cssivision/reverseproxy"
)

func serveReverseProxy(client string, clientMap string, w http.ResponseWriter, r *http.Request) error {
	url, err := url.Parse(fmt.Sprintf("http://127.0.0.1:3000?project=%s&map=%s", client, clientMap))
	if err != nil {
		return err
	}

	proxy := reverseproxy.NewReverseProxy(url)
	proxy.ServeHTTP(w, r)

	return nil
}

func lookup(w http.ResponseWriter, r *http.Request) (string, error) {
	c, err := net.LookupCNAME(r.Host)

	if err != nil {
		return "", err
	}

	if strings.TrimRight(c, ".") == r.Host {
		return "", errors.New("Host and CNAME match")
	}

	return strings.TrimRight(c, "."), nil
}

func handler(w http.ResponseWriter, r *http.Request) {
	now := time.Now()

	cname, err := lookup(w, r)
	if err != nil {
		fmt.Printf("404(%s) %v: Took %v\n", cname, err, time.Since(now))
		w.WriteHeader(404)
		return
	}

	cnameURL, err := url.Parse(fmt.Sprintf("https://%s", strings.TrimRight(cname, ".")))
	if err != nil {
		fmt.Printf("404(%s) %v: Took %v\n", cname, err, time.Since(now))
		w.WriteHeader(404)
		return
	}

	clientMap := strings.Split(cnameURL.Hostname(), ".")[0]
	client := strings.Split(cnameURL.Hostname(), ".")[1]

	if err := serveReverseProxy(client, clientMap, w, r); err != nil {
		fmt.Printf("500(%s) %s took %v\n", r.URL.Path, err, time.Since(now))
		w.WriteHeader(500)
		return
	}

	fmt.Printf("200(%s) Success: took %v\n", r.URL.Path, time.Since(now))
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/favicon.ico", func(w http.ResponseWriter, r *http.Request) {})
	mux.HandleFunc("/", handler)

	server := &http.Server{
		ReadTimeout:  20 * time.Second,
		WriteTimeout: 20 * time.Second,
		IdleTimeout:  120 * time.Second,
		Addr:         ":8000",
		Handler:      mux,
	}
	log.Fatal(server.ListenAndServe())
}
